<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$route['default_controller'] = 'Pages';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

$route['Home'] = 'Pages/Index';
$route['Contact'] = 'Pages/contact';
$route['About'] = 'Pages/about';
$route['FAQ'] = 'Pages/FAQ';
$route['Feedback'] = 'Pages/Feedback';
$route['Terms'] = 'Pages/Terms';
$route['Privacy'] = 'Pages/Privacy';
$route['Hotel'] = 'Pages/Hotel';
$route['Login'] = 'Pages/Login';
$route['Logout'] = 'Pages/Logout';
$route['Forgot'] = 'Pages/Forgot';
$route['Registration'] = 'Pages/Registration';
$route['Flights'] = 'Pages/Flights';
$route['Airport'] = 'Pages/Airport';
$route['place'] = 'Pages/Place';
$route['favorite_place'] = 'Pages/favourite_place';
$route['favorite_hotel'] = 'Pages/favourite_hotel';
$route['Packages'] = 'Pages/Packages';
$route['change_password'] = 'Pages/change_password';
$route['profile_success'] = 'Pages/profile_success';
$route['OTP_verify'] = 'Pages/OTP_verify';
$route['payment_Failed'] = 'Pages/payment_faild';
$route['payment_Success'] = 'Pages/payment_success';
$route['Payment-Notify'] = 'Pages/payment_notify';
$route['Email_verify'] = 'Pages/Email_verify';
$route['My_Profile'] = 'Pages/My_Profile';
$route['Passport'] = 'Pages/Passport';
$route['Passport_Preview'] = 'Pages/Preview';
$route['Passport_Preview/(:any)'] = 'Pages/Preview/$2';
$route['Myreview'] = 'Pages/Myreview';

//View 
$route['View_hotel/(:any)'] = "Pages/View_hotel/$2";
//$route['View_hotel'] = "Pages/View_hotel";
$route['View_flight/(:any)'] = "Pages/View_flight/$2";
//$route['View_flight'] = "Pages/View_flight";
$route['View_place/(:any)'] = "Pages/View_place/$2";
//$route['View_place'] = "Pages/View_place";
$route['View_package/(:any)'] = "Pages/View_package/$2";
//$route['View_package'] = "Pages/View_package";
$route['Add-Package/(:any)'] = 'Pages/Packages/$2';
//Package Booking
$route['My_package_booking'] = 'Pages/Package_book';
$route['Booking/(:any)'] = "Pages/Booking_page1/$2";
$route['Booking2/(:any)'] = "Pages/Booking_page2/$2";
$route['Booking3/(:any)'] = "Pages/Booking_page3/$2";
$route['Package_invoice/(:any)'] = "Pages/Package_invoice/$2";
//Hotel Booking
$route['My_hotel_booking'] = 'Pages/Hotel_book';
$route['HotelBooking/(:any)'] = "Pages/Hotel_Booking/$2";
$route['HotelBooking2/(:any)'] = "Pages/Hotel_Booking2/$2";
$route['HotelBooking3/(:any)'] = "Pages/Hotel_Booking3/$2";
$route['Hotel_invoice/(:any)'] = "Pages/Hotel_invoice/$2";
//Flight Booking
$route['My_Flight_booking'] = 'Pages/Flight_book';
$route['FlightBooking/(:any)'] = "Pages/flight_booking/$2";
$route['FlightBooking2/(:any)'] = "Pages/flight_booking2/$2";
$route['FlightBooking3/(:any)'] = "Pages/flight_booking3/$2";
$route['Flight_invoice/(:any)'] = "Pages/Flight_invoice/$2";

//Admin Site Routes

$route['Dashboard'] = 'Authorize/Dashboard';
$route['Admin_Login'] = 'Authorize/Index';
$route['Admin_Logout'] = 'Authorize/Logout';
$route['Admin_Forgot'] = 'Authorize/Forgot';
$route['Admin_Setting'] = 'Authorize/Admin_Setting';
$route['Location_Country'] = 'Authorize/Location_Country';
$route['Location_State'] = 'Authorize/Location_State';
$route['Location_City'] = 'Authorize/Location_City';
$route['Manage_Contact'] = 'Authorize/Manage_Contact';
$route['Manage_Feedback'] = 'Authorize/Manage_Feedback';
$route['Manage_Email'] = 'Authorize/Manage_Email';
$route['Manage_User'] = 'Authorize/Manage_User';
$route['Manage_Agent'] = 'Authorize/Manage_Agent';
$route['Manage_Banner'] = 'Authorize/Manage_Banner';
$route['Active_user'] = 'Authorize/Active_user';
$route['Deactive_user'] = 'Authorize/Deactive_user';
$route['Active_agent'] = 'Authorize/Active_agent';
$route['Deactive_agent'] = 'Authorize/Deactive_agent';
$route['Manage_Airport'] = 'Authorize/Manage_Airport';
$route['Manage_Airlines'] = 'Authorize/Manage_Airlines';
$route['Manage_Plane'] = 'Authorize/Manage_Plane';
$route['Manage_Packages'] = 'Authorize/Manage_Packages';
$route['Manage_Air_schedule'] = 'Authorize/Air_schedule';
$route['Add_Air_schedule'] = 'Authorize/Add_Air_schedule';
$route['Flight_Booking'] = 'Authorize/flight_Booking';

//edit

$route['Remove/(:any)/(:any)'] = "Authorize/Delete/$2/$3";
$route['Remove-Agent/(:any)/(:any)'] = "Agent/Delete/$2/$3";
$route['Remove-User/(:any)/(:any)'] = "Pages/Delete/$2/$3";
$route['Edit-Country/(:any)'] = "Edit/country/$2";
$route['Edit-State/(:any)'] = "Edit/state/$2";
$route['Edit-City/(:any)'] = "Edit/city/$2";
$route['Edit-Package/(:any)'] = "Edit/package/$2";
$route['Edit-User/(:any)/(:any)'] = "Edit/User/$2/$3";
$route['Edit-Agent/(:any)/(:any)'] = "Edit/Agent/$2/$3";
$route['Edit-review/(:any)/(:any)'] = "Edit/review/$2/$3";
$route['Edit-place/(:any)']='Edit/edit_place/$2';
$route['Edit-facility/(:any)']='Edit/edit_facility/$2';
$route['Edit-policy/(:any)']='Edit/edit_policy/$2';
$route['Edit-package_seller/(:any)']='Edit/edit_package_seller/$2';
$route['Edit-hotel/(:any)']='Edit/edit_hotel/$2';
$route['Edit-airport/(:any)']='Edit/edit_airport/$2';
$route['Edit-schedule/(:any)']='Edit/edit_schedule/$2';
$route['Edit-airlines/(:any)']='Edit/airlines/$2';
$route['Edit-plane/(:any)']='Edit/plane/$2';

//Agent Routs
$route['Agent_Home'] = 'Agent/Dashboard';
$route['Agent_Register'] = 'Agent/Register';
$route['Agent_Login'] = 'Agent/Login';
$route['Agent_Forget'] = 'Agent/Forget';
$route['Agent_Logout'] = 'Agent/Logout';
$route['Agent_Profile'] = 'Agent/profile_success';
$route['Agent_Changepassword'] = 'Agent/Changepassword';
$route['Agent_Facility'] = 'Agent/Facility';
$route['Active_Review'] = 'Agent/Active_Review';
$route['Deactive_Review'] = 'Agent/Deactive_Review';
$route['Add_Package'] = 'Agent/Add_Package';
$route['View_Package'] = 'Agent/View_Package';
$route['Agent_Profile'] = 'Agent/Edit_Profile';
$route['Manage_place'] = 'Agent/Manage_place';
$route['Agent_Booking'] = 'Agent/Booking';
$route['Hotel_Booking'] = 'Agent/hotel_Booking';
$route['Add_hotel'] = 'Agent/Add_hotel';
$route['Manage_hotel'] = 'Agent/Manage_hotel';
$route['Agent_policy'] = 'Agent/policy';
$route['Add_bank'] = 'Agent/Add_bank';