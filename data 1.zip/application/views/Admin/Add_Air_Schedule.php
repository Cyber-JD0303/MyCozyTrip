<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Manage Air Schedule</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Add_Air_schedule'); ?>">Add Air Schedule</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <form method="post" action="" name="Airschedule" novalidate="">
                                        <?php
                                        if (!isset($schedule_edit_detail)) {
                                            ?>
                                            <div class="col-md-12">
                                                <div class="box-inn-sp">
                                                    <div class="inn-title">
                                                        <h4>Add Air Schedule</h4>
                                                    </div>
                                                    <div class="tab-inn">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>Airlines</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="airline" id="airline" onchange="set_combo('plane', this.value);">
                                                                            <option value="">Select Airline</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_airlines", "*");
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->airlines_id ?>" <?php
                                                                                if (!isset($success) && set_select('airline', $data->airlines_id)) {
                                                                                    echo set_select('airline', $data->airlines_id);
                                                                                }
                                                                                ?>><?php echo $data->airlines; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('airline')) {
                                                                                echo form_error("airline");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label>Plane</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="plane" id="plane" >
                                                                            <option value="">Select plane</option>
                                                                            <?php
                                                                            if ($this->input->post('airline') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_plane", "*", array('airlines_id' => $this->input->post("airline")));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->plane_id ?>" <?php
                                                                                    if (!isset($success) && set_select('plane', $data->plane_id)) {
                                                                                        echo set_select('plane', $data->plane_id);
                                                                                    }
                                                                                    ?>><?php echo $data->plane_name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('plane')) {
                                                                                echo form_error("plane");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>From Location</label>
                                                                <div class="row">
                                                                    <div class="col-md-4">  
                                                                        <label for="country">Country</label>
                                                                        <select name="country" id="country" onchange="set_combo('state', this.value);">
                                                                            <option value="">Select Country</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('country')) {
                                                                                echo form_error("country");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="state">State</label>
                                                                        <select name="state" id="state" onchange="set_combo('city', this.value);">
                                                                            <option value="">Select State</option>
                                                                            <?php
                                                                            if ($this->input->post('country') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                        echo set_select('state', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('state')) {
                                                                                echo form_error("state");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="city">City</label>
                                                                        <select name="city" id="city">
                                                                            <option value="">Select City</option>
                                                                            <?php
                                                                            if ($this->input->post('State') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                        echo set_select('city', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('city')) {
                                                                                echo form_error("city");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>To Location</label>
                                                                <div class="row">
                                                                    <div class="col-md-4">  
                                                                        <label for="t_country">Country</label>
                                                                        <select name="t_country" id="t_country" onchange="set_combo('t_state', this.value);">
                                                                            <option value="">Select Country</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select("t_country", $data->location_id)) {
                                                                                    set_select("t_country", $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('t_country')) {
                                                                                echo form_error("t_country");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="t_state">State</label>
                                                                        <select name="t_state" id="t_state" onchange="set_combo('t_city', this.value);">
                                                                            <option value="">Select State</option>
                                                                            <?php
                                                                            if ($this->input->post('t_country') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('t_state', $data->location_id)) {
                                                                                        echo set_select('t_state', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('t_state')) {
                                                                                echo form_error("t_state");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="t_city">City</label>
                                                                        <select name="t_city" id="t_city">
                                                                            <option value="">Select City</option>
                                                                            <?php
                                                                            if ($this->input->post('t_state') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('t_city', $data->location_id)) {
                                                                                        echo set_select('t_city', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('t_city')) {
                                                                                echo form_error("t_city");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>From Time</label>
                                                                    <div class="input-field col s12">
                                                                        <input type="time" name="ftime" class="form-control"/>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('ftime')) {
                                                                                echo form_error("ftime");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label>To Time</label>
                                                                    <div class="input-field col s12">
                                                                        <input type="time" name="ttime" class="form-control"/>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('ttime')) {
                                                                                echo form_error("ttime");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>Class</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="Class" id="Class" >
                                                                            <option value="">Select Class</option>
                                                                            <option value="1">Business Class</option>
                                                                            <option value="2">Economy Class</option>
                                                                            <option value="3">First Class</option>
                                                                        </select>
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('Class')) {
                                                                                echo form_error("Class");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label for="price" class="">Price</label>
                                                                    <div class="input-field col s12">
                                                                        <input id="price" type="text" class="validate" check_control="number" name="price" value="<?php
                                                                        if (!isset($success) && set_value("price")) {
                                                                            echo set_value("price");
                                                                        }
                                                                        ?>">
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('price')) {
                                                                                echo form_error("price");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="add" value="add">Add Schedule</button>
                                                                    <button class="btn btn-default" type="reset">Reset</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        } else {
                                            $plane = $this->md->my_select('tbl_plane', '*', array('plane_id' => $schedule_edit_detail[0]->plan_id));
                                            $airline = $this->md->my_select('tbl_airlines', '*', array('airlines_id' => $plane[0]->airlines_id));
                                            $whe['location_id'] = $schedule_edit_detail[0]->from_location;
                                            $where['location_id'] = $schedule_edit_detail[0]->to_location;
                                            $city_detail = $this->md->my_select("tbl_location", "*", $whe);
                                            $city_detail2 = $this->md->my_select("tbl_location", "*", $where);
                                            $c = $this->md->my_select('tbl_location', '*', array('location_id' => $city_detail[0]->parent_id));
                                            $c2 = $this->md->my_select('tbl_location', '*', array('location_id' => $city_detail2[0]->parent_id));
                                            $cn = $c[0]->parent_id;
                                            $cn2 = $c2[0]->parent_id;
                                            ?>
                                            <div class="col-md-12">
                                                <div class="box-inn-sp">
                                                    <div class="inn-title">
                                                        <h4>Edit Air Schedule</h4>
                                                    </div>
                                                    <div class="tab-inn">
                                                        <div class="panel-body">
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>Airlines</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="airline" id="airline" onchange="set_combo('plane', this.value);">
                                                                            <option>Select Airline</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_airlines", "*");
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->airlines_id ?>" <?php
                                                                                if (!isset($success) && set_select('airline', $data->airlines_id)) {
                                                                                    echo set_select('airline', $data->airlines_id);
                                                                                } else {
                                                                                    if ($data->airlines_id == $airline[0]->airlines_id) {
                                                                                        echo "selected";
                                                                                    }
                                                                                }
                                                                                ?>><?php echo $data->airlines; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('airline')) {
                                                                                echo form_error("airline");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                <label>Plane</label>
                                                                <div class="input-field col s12">
                                                                    <select name="plane" id="plane" >
                                                                        <option>Select plane</option>
                                                                        <?php
                                                                        if ($this->input->post('airline') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_plane", "*", array('airlines_id' => $this->input->post("airline")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->plane_id ?>" <?php
                                                                                if (!isset($success) && set_select('plane', $data->plane_id)) {
                                                                                    echo set_select('plane', $data->plane_id);
                                                                                }
                                                                                ?>><?php echo $data->plane_name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_plane", "*", array('airlines_id' => $airline[0]->airlines_id));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->plane_id ?>" <?php
                                                                                if ($plane[0]->plane_id == $data->plane_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->plane_name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('plane')) {
                                                                            echo form_error("plane");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>From Location</label>
                                                                <div class="row">
                                                                    <div class="col-md-4">  
                                                                        <label for="country">Country</label>
                                                                        <select name="country" id="country" onchange="set_combo('state', this.value);">
                                                                            <option>Select Country</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "Country"));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                    echo "selected";
                                                                                } else {
                                                                                    if ($data->location_id == $cn) {
                                                                                        echo "selected";
                                                                                    }
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('country')) {
                                                                                echo form_error("country");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="state">State</label>
                                                                        <select name="state" id="state" onchange="set_combo('city', this.value);">
                                                                            <option>Select State</option>
                                                                            <?php
                                                                            if ($this->input->post('country') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post('country')));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                        echo set_select('state', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>

                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $cn));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if ($city_detail[0]->parent_id == $data->location_id) {
                                                                                        echo "selected";
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('state')) {
                                                                                echo form_error("state");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="city">City</label>
                                                                        <select name="city" id="city">
                                                                            <option>Select City</option>
                                                                            <?php
                                                                            if ($this->input->post('state') && !isset($success)) {

                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post('state')));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                        echo set_select('city', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>

                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $c[0]->location_id));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if ($schedule_edit_detail[0]->from_location == $data->location_id) {
                                                                                        echo "selected";
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('city')) {
                                                                                echo form_error("city");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>To Location</label>
                                                                <div class="row">
                                                                    <div class="col-md-4">  
                                                                        <label for="t_country">Country</label>
                                                                        <select name="t_country" id="t_country" onchange="set_combo('t_state', this.value);">
                                                                            <option>Select Country</option>;
                                                                            <?php
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "Country"));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select("t_country", $data->location_id)) {
                                                                                    echo "selected";
                                                                                } else {
                                                                                    if ($data->location_id == $cn2) {
                                                                                        echo "selected";
                                                                                    }
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('t_country')) {
                                                                                echo form_error("t_country");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="t_state">State</label>
                                                                        <select name="t_state" id="t_state" onchange="set_combo('t_city', this.value);">
                                                                            <option>Select State</option>
                                                                            <?php
                                                                            if ($this->input->post('t_country') && !isset($success)) {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post('t_country')));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('t_state', $data->location_id)) {
                                                                                        echo set_select('t_state', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>

                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $cn2));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if ($city_detail2[0]->parent_id == $data->location_id) {
                                                                                        echo "selected";
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('t_state')) {
                                                                                echo form_error("t_state");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                    <div class="col-md-4">  
                                                                        <label for="t_city">City</label>
                                                                        <select name="t_city" id="t_city">
                                                                            <option>Select City</option>
                                                                            <?php
                                                                            if ($this->input->post('t_state') && !isset($success)) {

                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post('t_state')));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if (!isset($success) && set_select('t_city', $data->location_id)) {
                                                                                        echo set_select('t_city', $data->location_id);
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>

                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $c2[0]->location_id));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                                    if ($schedule_edit_detail[0]->to_location == $data->location_id) {
                                                                                        echo "selected";
                                                                                    }
                                                                                    ?>><?php echo $data->name; ?></option>
                                                                                            <?php
                                                                                        }
                                                                                    }
                                                                                    ?>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('t_city')) {
                                                                                echo form_error("t_city");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>From Time</label>
                                                                    <div class="input-field col s12">
                                                                        <input type="time" name="ftime" class="form-control" value="<?php
                                                                        if (!isset($success) && set_value("ftime")) {
                                                                            echo set_value("ftime");
                                                                        } else {
                                                                            echo $schedule_edit_detail[0]->from_time;
                                                                        }
                                                                        ?>"/>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('ftime')) {
                                                                                echo form_error("ftime");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label>To Time</label>
                                                                    <div class="input-field col s12">
                                                                        <input type="time" name="ttime" class="form-control" value="<?php
                                                                        if (!isset($success) && set_value("ttime")) {
                                                                            echo set_value("ttime");
                                                                        } else {
                                                                            echo $schedule_edit_detail[0]->to_time;
                                                                        }
                                                                        ?>"/>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('ttime')) {
                                                                                echo form_error("ttime");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="form-group col-md-6">
                                                                    <label>Class</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="Class" id="Class" >
                                                                            <option>Select Class</option>
                                                                            <option value="1" <?php if($schedule_edit_detail[0]->class == '1'){ echo 'selected'; }?>>Business Class</option>
                                                                            <option value="2" <?php if($schedule_edit_detail[0]->class == '2'){ echo 'selected'; }?>>Economy Class</option>
                                                                            <option value="3" <?php if($schedule_edit_detail[0]->class == '3'){ echo 'selected'; }?>>First Class</option>
                                                                        </select>
                                                                        <div class="error">
                                                                            <?php
                                                                            if (form_error('Class')) {
                                                                                echo form_error("Class");
                                                                            }
                                                                            ?>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="form-group col-md-6">
                                                                    <label for="price" class="">Price</label>
                                                                    <div class="input-field col s12">
                                                                        <input id="price" type="text" class="validate" check_control="number" name="price" value="<?php
                                                                        if (!isset($success) && set_value("price")) {
                                                                            echo set_value("price");
                                                                        } else {
                                                                            echo $schedule_edit_detail[0]->price;
                                                                        }
                                                                        ?>">
                                                                        <p class="error">
                                                                            <?php
                                                                            if (form_error('price')) {
                                                                                echo form_error("price");
                                                                            }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="update" value="Edit">Edit Schedule</button>
                                                                    <a href="<?php echo base_url('Manage_Air_schedule'); ?>" class="btn btn-default">Cancel</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                        ?>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>