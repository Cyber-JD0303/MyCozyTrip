<!--======== SCRIPT FILES =========-->
<!--<script src="<?php echo base_url(); ?>Admin_Assets/js/jquery.min.js" type="text/javascript"></script>-->
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/jquery-3.4.1.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/MyQuery.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/materialize.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/custom.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/buttons.flash.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/jszip.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/pdfmake.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/vfs_fonts.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/buttons.html5.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/Validation/buttons.print.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Admin_Assets/js/ckeditor/ckeditor.js" type="text/javascript"></script>
<!--data table start-->
<script type="text/javascript">
    $(document).ready(function () {
        $('#tbl_validation').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'pdf', 'print'
            ]
        });
    });
</script>
<!--data table end-->

<!--validation start-->
<script type="text/javascript">
    $("input[check_control]").keypress(function (e) {
        if ($(this).attr("check_control") == "alpha") {
            var regex = new RegExp("^[a-zA-Z ]+$");
        } else if ($(this).attr("check_control") == "number") {
            var regex = new RegExp("^[0-9]+$");
        } else if ($(this).attr("check_control") == "email")
        {
            var regex = new RegExp("^[a-zA-Z0-9.@_]+$");
        }

        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            $(this).removeClass("form_error").addClass("form_valid");
            return true;
        } else {
            $(this).removeClass("form_valid").addClass("form_error");
        }

        e.preventDefault();
        return false;
    });

    $("input[check_control]").blur(function () {

        var val = this.value;
        if (val == "") {
            $(this).removeClass("form_valid").addClass("form_error");
        } else {
            $(this).removeClass("form_error").addClass("form_valid");
        }
    });
</script>
<!--validation end-->
<script type="text/javascript">
    setTimeout(function () {
        $(".my_alert_success").fadeOut("slow");
    }, 3000);
    setTimeout(function () {
        $(".my_alert").fadeOut("slow");
    }, 3000);
</script>

<style type="text/css">
    .input-field{
        margin-top: 0;
    }
    .input-field select,.form-group select{
        display: block !important;
    }
    .input-field .select-dropdown,.caret,.form-group .select-dropdown{
        display: none !important;
    }
</style>