<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Location :: city</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Location_city'); ?>">Location city</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <form method="post" action="" name="addcity" novalidate="">
                                        <?php
                                        if(!isset($city_edit_detail))
                                        {
                                        ?>
                                        <div class="col-md-6">
                                            <div class="box-inn-sp">
                                                <div class="inn-title">
                                                    <h4>Add Coverage city</h4>
                                                </div>
                                                <div class="tab-inn">
                                                    <div class="panel-body">
                                                        <div class="form-group">
                                                            <label>Country</label>
                                                            <div class="input-field col s12">
                                                                <select name="country" id="country" onchange="set_combo('state',this.value);">
                                                                    <option value="">Select Country</option>;
                                                                    <?php
                                                                        $recordset = $this->md->my_select("tbl_location","*",array("label"=>"country"));
                                                                        foreach ($recordset as $data)
                                                                        {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                    if(!isset($success) && set_select("country",$data->location_id))
                                                                    {
                                                                        echo "selected";
                                                                    }
                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                ?>
                                                                </select>
                                                                <p class="error">
                                                                    <?php
                                                                    if (form_error('country')) {
                                                                        echo form_error("country");
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>State</label>
                                                            <div class="input-field col s12">
                                                                <select name="state" id="state" required="">
                                                                    <option value="">Select State</option>
                                                                    <?php
                                                                        if( $this->input->post('country') && !isset($success) )
                                                                        {
                                                                            $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$this->input->post("country")));
                                                                            foreach ($recordset as $data)
                                                                            {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                                if(!isset($success) && set_select('state', $data->location_id) )
                                                                                {
                                                                                    echo "selected";
                                                                                }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                            <?php
                                                                            }
                                                                        }
                                                                        else
                                                                        {
                                                                            $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$cn));
                                                                            foreach ($recordset as $data)
                                                                            {
                                                                        ?>
                                                                        <option value="<?php echo $data->location_id ?>" <?php
                                                                           if($city_edit_detail[0]->parent_id == $data->location_id)
                                                                           {
                                                                               echo "selected";
                                                                           }

                                                                        ?>><?php echo $data->name; ?></option>

                                                                        <?php
                                                                            }
                                                                        }
                                                                        ?>
                                                                </select>
                                                                <p class="error">
                                                                    <?php
                                                                    if (form_error('state')) {
                                                                        echo form_error('state');
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="input-field col s12">
                                                                <input id="city" autofocus="" type="text" class="validate" check_control="alpha" name="city" value="<?php
                                                                    if (!isset($success) && set_value("city")) {
                                                                        echo set_value("city");
                                                                    }
                                                                    ?>">
                                                                  <p class="error">
                                                                     <?php
                                                                     if (form_error('city'))
                                                                     {
                                                                         echo form_error("city");
                                                                     }
                                                                     ?>
                                                                 </p>
                                                                <!--<label for="city" class="">city Name</label>-->
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="input-field col s12" align="right">
                                                                <button class="btn btn-primary" type="submit" name="add" value="add">Add city</button>
                                                                <button class="btn btn-default" type="reset">Reset</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        } 
                                        else
                                        {
                                        $cn = $this->md->my_select('tbl_location','*',array('location_id'=>$city_edit_detail[0]->parent_id))[0]->parent_id;
                                        ?>
                                            <div class="col-md-6">
                                            <div class="box-inn-sp">
                                                <div class="inn-title">
                                                    <h4>Edit Coverage city</h4>
                                                </div>
                                                <div class="tab-inn">
                                                    <div class="panel-body">
                                                        <div class="form-group">
                                                            <label>Country</label>
                                                            <select class="" name="country" id="country" onchange="set_combo('state',this.value);">                                                 
                                                                <option value="">Select Country</option>
                                                                <?php
                                                                $recordset = $this->md->my_select("tbl_location","*",array("label"=>"Country"));
                                                                foreach ($recordset as $data)
                                                                {
                                                                ?>
                                                                <option value="<?php echo $data->location_id ?>" <?php

                                                                    if( !isset($success) && $this->input->post('country') )
                                                                    {
                                                                        echo set_select('country',  $data->location_id );
                                                                    }
                                                                   else 
                                                                   {
                                                                       if( $data->location_id == $cn )
                                                                       {
                                                                           echo "selected";
                                                                       }
                                                                   }

                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                ?>
                                                           </select>
                                                            <p class="error">
                                                                <?php
                                                                if (form_error('country')) {
                                                                    echo form_error("country");
                                                                }
                                                                ?>
                                                            </p>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>State</label>
                                                            <select class="" name="state" id="state">                                                 
                                                                <option value="">Select State</option>
                                                                <?php
                                                                    if( $this->input->post('country') && !isset($success) )
                                                                    {
                                                                        $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$this->input->post('country')));
                                                                        foreach ($recordset as $data)
                                                                        {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php

                                                                        if(!isset($success) && set_select('state', $data->location_id) )
                                                                        {
                                                                            echo set_select('state', $data->location_id);
                                                                        }

                                                                    ?>><?php echo $data->name; ?></option>

                                                                    <?php
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$cn));
                                                                        foreach ($recordset as $data)
                                                                        {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                       if(!isset($success) && $city_edit_detail[0]->parent_id == $data->location_id)
                                                                       {
                                                                           echo "selected";
                                                                       }

                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                        }
                                                                    }
                                                                ?>
                                                                 </select>
                                                            <p class="error">
                                                                <?php
                                                                if (form_error('state')) {
                                                                    echo form_error("state");
                                                                }
                                                                ?>
                                                            </p>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="input-field col s12">
                                                                <input id="city" type="text" class="validate" check_control="alpha" name="city" value="<?php
                                                                if (!isset($success) && set_value("city")) {
                                                                    echo set_value("city");
                                                                } 
                                                                else 
                                                                {
                                                                    echo $city_edit_detail[0]->name;
                                                                }
                                                                ?>" /> 
                                                                <p class="error">
                                                                    <?php
                                                                    if (form_error('city')) {
                                                                        echo form_error("city");
                                                                    }
                                                                    ?>
                                                                </p>
                                                                <label for="city">Edit city Name</label>
                                                            </div>
                                                        </div>
                                                            <div class="row">
                                                            <div class="input-field col s12" align="right">
                                                                <button class="btn btn-primary" type="submit" name="update" value="Edit">Edit city</button>
                                                                <a href="<?php echo base_url('Location_City'); ?>" class="btn btn-default">Cancel</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        }
                                        ?>
                                    </form>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Manage city Data</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover" id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Country</th>
                                                                <th>state</th>
                                                                <th>city</th>
                                                                <th>Edit</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                        $c=0;
                                                        foreach($city_detail as $data) {
                                                            $c++;
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $c; ?></td>
                                                                    <td><?php echo $data->country ?></td>
                                                                    <td><?php echo $data->state ?></td>
                                                                    <td><?php echo $data->name ?></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url(); ?>Edit-City/<?php echo $data->location_id; ?>"  class="btnedit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#city-del').attr('href', '<?php echo base_url(); ?>Remove/state/<?php echo $data->location_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">City</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="city-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
<?php
$this->load->view('Admin/Footer_Script');
?>
    </body>
</html>