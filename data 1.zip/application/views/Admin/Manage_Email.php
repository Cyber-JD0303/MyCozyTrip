<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Manage Email</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>

        </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Manage_Email'); ?>">Manage Email</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <form action="" name="sentemail" novalidate="" method="post">
                                        <div class="col-md-6">
                                            <div class="box-inn-sp">
                                                <div class="inn-title">
                                                    <h4>Email</h4>
                                                </div>
                                                <div class="tab-inn">
                                                    <div class="table-responsive table-desi">
                                                        <table class="table table-hover" id="tbl_validation">
                                                            <thead>
                                                                <tr>
                                                                    <th>
                                                                        <input type="checkbox" id="indeterminate-checkbox" name="all" value="all" onchange="checkAll(this)">
                                                                        <label for="indeterminate-checkbox"></label>
                                                                    </th>
                                                                    <th>Email</th>
                                                                    <th>Delete</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <?php
                                                                    $c=0;
                                                                    foreach($view as $record) 
                                                                    {
                                                                    $c++;
                                                                ?>
                                                                    <tr>
                                                                        <td><input type="checkbox" name="recieve[]" value="<?php echo $record->email; ?>" id="indeterminate-checkbox<?php echo $c; ?>">
                                                                            <label for="indeterminate-checkbox<?php echo $c; ?>"></label>
                                                                        </td>
                                                                        <td><?php echo $record->email;  ?></td>
                                                                        <td><a onclick="$('#Email-del').attr('href', '<?php echo base_url(); ?>Remove/email/<?php echo $record->eid; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a></td>
                                                                    </tr>                                                          
                                                                    <?php
                                                                }
                                                                ?>
                                                            </tbody>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="panel panel-card margin-b-30 ">
                                                <!-- Start .panel -->
                                                <div class="panel-heading">
                                                    <h4 class="panel-title">Send Email</h4>
                                                </div>
                                                <div class="panel-body">
                                                    <div class="form-group">
                                                        <div class="input-field col s12">
                                                            <input id="subject" type="text" class="validate" check_control="alpha" name="subject" autofocus="" value="<?php
                                                                if (!isset($success) && set_value("subject")) 
                                                                {
                                                                    echo set_value("subject");
                                                                }
                                                            ?>">
                                                            <label for="subject">Enter Subject</label>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <textarea id="editor1" name="message" rows="10" cols="80"><?php
                                                                if (!isset($success) && set_value("message")) 
                                                                {
                                                                    echo set_value("message");
                                                                }
                                                            ?></textarea>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="input-field col s12" align="right">
                                                            <button class="btn btn-primary" name="send" value="send" type="submit">Send Email</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Email</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Email-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div> 
        <?php
            if (isset($success)) {
                ?>
                <div class="my_alert_success animated bounceInLeft">
                    <p>
                        <i class="fa fa-check-circle" aria-hidden="true"></i>
                        <b><?php echo $success; ?></b>
                    </p>
                </div>
                <?php
            }
            if (isset($error)) {
                ?>
                <div class="my_alert animated bounceInRight">
                    <p>
                        <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                        <b><?php echo $error; ?></b>
                    </p>
                </div>
                <?php
            }
            ?>
            <?php
            $this->load->view('Admin/Footer_Script');
            ?>
            <script>
                CKEDITOR.replace('editor1');
            </script>
    </body>
</html>