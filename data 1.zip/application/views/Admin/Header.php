<!--== MAIN CONTRAINER ==-->
<?php
    $wh['email'] = $this->session->userdata('admin');
    $record=$this->md->my_select('tbl_admin','*',$wh);
	ini_set('display_errors', 0);
?>
<div class="container-fluid sb1">
    <div class="row">
        <!--== LOGO ==-->
        <div class="col-md-3 col-sm-3 col-xs-6 sb1-1">
            <a class="navbar-brand" style="padding: 0px 15px !important;" href="<?php echo base_url('Dashboard'); ?>">
                <label style="font-weight: bolder !important;font-family: serif;text-transform: uppercase !important;"><h1>Mycozy Trip</h1></label>
            </a>
        </div>
<!--
        <div class="col-md-offset-6 col-md-1 tab-hide">
            <div class="top-not-cen">
                <a class='waves-effect btn-noti' href='#'><i class="fa fa-envelope-o" aria-hidden="true"></i><span>5</span></a>
            </div>
        </div>-->
        <!--== MY ACCCOUNT ==-->
        <div class="col-md-offset-7 col-md-2 col-sm-offset-7 col-sm-2 col-xs-6 sb1-1">
            <!-- Dropdown Trigger -->
            <a class='waves-effect dropdown-button top-user-pro' href='' data-activates='top-menu'><img src="<?php echo base_url(); ?><?php echo $record[0]->profile; ?>" alt="" />My Account <i class="fa fa-angle-down" aria-hidden="true"></i></a>
            <!-- Dropdown Structure -->
            <ul id='top-menu' class='dropdown-content top-menu-sty'>
                <li><a href="<?php base_url() ?>Admin_Setting" class="waves-effect"><i class="fa fa-cogs" aria-hidden="true"></i>Admin Setting</a>
                </li>
                <li class="divider"></li>
                <li><a href="<?php base_url() ?>Admin_Logout" class="ho-dr-con-last waves-effect"><i class="fa fa-sign-in" aria-hidden="true"></i> Logout</a>
                </li>
            </ul>
        </div>
    </div>
</div>
