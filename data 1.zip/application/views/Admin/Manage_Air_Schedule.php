<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Manage Air Schedule</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Manage_Air_schedule'); ?>">Manage Air Schedule</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Manage Air Schedule</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover" id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>plane Name</th>
                                                                <th>From Location</th>
                                                                <th>To Location</th>
                                                                <th>From Time</th>
                                                                <th>To Time</th>
                                                                <th>Class</th>
                                                                <th>Price</th>
                                                                <th>Edit</th>
                                                                <th>delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                        <?php
                                                        $c=0;
                                                        foreach($view as $data) {
                                                            $c++;
                                                            $plane= $this->md->my_select("tbl_plane", "*" ,array('plane_id' => $data->plan_id));
                                                            $f_city= $this->md->my_select("tbl_location", "*" ,array('location_id' => $data->from_location));
                                                            $t_city= $this->md->my_select("tbl_location", "*" ,array('location_id' => $data->to_location));
                                                            if($data->class == '1')
                                                            {
                                                                $class = 'Business Class';
                                                            }else if($data->class == '2')
                                                            {
                                                                $class = 'Economy Class';
                                                            }else if($data->class == '3')
                                                            {
                                                                $class = 'First Class';
                                                            }
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $c; ?></td>
                                                                    <td><?php echo $plane[0]->plane_name; ?></td>
                                                                    <td><?php echo $f_city[0]->name; ?></td>
                                                                    <td><?php echo $t_city[0]->name; ?></td>
                                                                    <td><?php echo date('g:i a',strtotime($data->from_time)); ?></td>
                                                                    <td><?php echo date('g:i a', strtotime($data->to_time)); ?></td>
                                                                    <td><?php echo $class; ?></td>
                                                                    <td><?php echo $data->price; ?></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url(); ?>Edit-schedule/<?php echo $data->schedule_id; ?>" class="btnedit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#Air-del').attr('href', '<?php echo base_url(); ?>Remove/schedule/<?php echo $data->schedule_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">City</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Air-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
<?php
$this->load->view('Admin/Footer_Script');
?>
    </body>
</html>