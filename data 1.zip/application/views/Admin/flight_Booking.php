<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Flight Booking</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Flight_Booking'); ?>">Flight Booking</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>View All Booking Of Flight</h4>
                                                <!-- Dropdown Structure -->
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover" id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>User Name</th>
                                                                <th>Email</th>
                                                                <th>Contact No</th>
<!--                                                                <th>plane Name</th>
                                                                <th>Airline Name</th>
                                                                <th>Booked date</th>
                                                                <th>Price</th>
                                                                <th>person</th>-->
                                                                <th>More Details</th>
                                                                <th>Amount</th>
                                                                <th>Invoice</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $c=0;
                                                            foreach($view as $record) {
                                                                $user= $this->md->my_select('tbl_register','*',array('Rid'=>$record->Rid));
                                                                $flight= $this->md->my_select('tbl_air_schedule','*',array('schedule_id'=>$record->schedule_id));
                                                                $plane= $this->md->my_select('tbl_plane','*',array('plane_id'=>$flight[0]->plan_id));
                                                                $airline= $this->md->my_select('tbl_airlines','*',array('airlines_id'=>$plane[0]->airlines_id));
                                                                
                                                                $c++;
                                                            ?>
                                                            <tr>
                                                                <td><?php echo $c; ?></td>
                                                                <td><?php echo $user[0]->name;  ?></td>
                                                                <td><?php echo $user[0]->email;  ?></td>
                                                                <td><?php echo $user[0]->phone;  ?></td>
                                                                <td><a onclick="details('Flight',<?php echo $record->flightbook_id; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                                <td><?php echo $record->amount;  ?></td>
                                                                <td><label onclick="Bill('DivIdToPrint',<?php echo $record->flightbook_id; ?>);">Download Invoice </label></td>
                                                            </tr>
                                                            <?php
                                                                }       
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                            <div id="DivIdToPrint" class="hidden"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>                     
                        </div>
                    </div>
                </div>
            </div>
        </div>
       <div class="modal fade bs-example-modal-md1" id="Flight" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
           
       </div>
       <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Contact</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Contact-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
        <script>
            var base_url = "http://localhost/MyCozy/";
            function Bill(action, id)
            {
                $data = {action: action, id: id};
                var path = base_url + "backend/Bill3/";
                $.post(path, $data, function (data) 
                {
                    $("#" + action).html(data);
                    printDiv();
                });     
            }
            function printDiv()
            {
                var contents = $("#DivIdToPrint").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({"position": "absolute", "top": "-1000000px"});
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>Flight Booking Invoice</title>');
                //Append the external CSS file.
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/mycss.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/theme-turqoise.css" id="template-color" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/lightslider.min.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styler.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');
                frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>');
                //Append the DIV contents.
                frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();

                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 500);
            }
        </script>
    </body>
</html>