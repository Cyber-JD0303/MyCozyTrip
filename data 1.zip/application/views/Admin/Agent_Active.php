<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Active Agent</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Active_agent'); ?>">Active Agent</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Active Agent</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                   <table class="table table-hover" id="tbl_validation">
                                                       <thead>
                                                           <tr>
                                                                <th>No</th>
                                                                <th>Profile Photo</th>
                                                                <th>Company Name</th>
                                                                <th>Email</th>
                                                                <th>Phone No</th>
                                                                <th>More Details</th>
                                                                <th>deactivate</th>
                                                           </tr>
                                                       </thead>
                                                       <tbody>
                                                           <?php
                                                           $c=0;
                                                           foreach($view as $record) {
                                                           $c++;
                                                           ?>
                                                           <tr>
                                                                <td><?php echo $c; ?></td>                                                                
                                                                <td><span class="list-img"><img src="<?php echo base_url(); ?><?php echo  $record->profile_pic; ?>" alt=""></span></td>
                                                                <td><?php echo $record->company_name; ?></td>
                                                                <td><?php echo $record->email; ?></td>
                                                                <td><?php echo $record->phone; ?></td>
                                                                <td><a onclick="details('Agent',<?php echo $record->agent_id; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                                <td><a onclick="$('#Deactive-Agent').attr('href','<?php echo base_url(); ?>Edit-Agent/<?php echo $record->status; ?>/<?php echo $record->agent_id; ?>')" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btnview" title="Deactive"><i class="fa fa-toggle-on"></i></a></td>
                                                           </tr>
                                                           <?php
                                                               }       
                                                           ?>
                                                       </tbody>
                                                   </table>
                                               </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md1" id="Agent" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Agent</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Deactivate ??</p>
                        <a href="" class="btn" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Deactive-Agent" class="btn btn-primary" >Yes,Deactivate it!!</a>                               
                    </center>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html> 