<!--== FAV ICON ==-->
<link rel="shortcut icon" href="<?php echo base_url(); ?>Admin_Assets/images/fav.png">

<!-- GOOGLE FONTS -->
<link href="https://fonts.googleapis.com/css?family=Nunito+Sans:400,600,700" rel="stylesheet">

<!-- FONT-AWESOME ICON CSS -->
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/font-awesome.min.css">

<!--== ALL CSS FILES ==-->
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/MyStyle.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/mob.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/bootstrap-theme.min.css"/>
<link rel="stylesheet" href="<?php echo base_url(); ?>Admin_Assets/css/materialize.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link href="<?php echo base_url(); ?>Assets/css/Animate.css" rel="stylesheet" type="text/css"/>