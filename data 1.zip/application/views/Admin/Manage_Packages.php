<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Packages details</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Manage_Packages'); ?>">Manage Packages</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <form action="" name="Package" class="" method="post">
                                    <?php
                                    if (!isset($package_edit_detail)) {
                                        ?>
                                            <div class="col-md-6">
                                                <div class="box-inn-sp">
                                                    <div class="inn-title">
                                                        <h4>Add Package Details</h4>
                                                    </div>
                                                    <div class="tab-inn">
                                                        <div class="panel-body">
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="Packagename" maxlength="20" type="text" class="validate" check_control="alpha" name="package" autofocus="" value="<?php
                                                                    if (!isset($success) && set_value("package")) {
                                                                        echo set_value("package");
                                                                    }
                                                                        ?>">
                                                                    <p class="error">
                                                                           <?php
                                                                           if (form_error('package')) {
                                                                               echo form_error("package");
                                                                           }
                                                                           ?>
                                                                    </p>
                                                                    <label for="Packagename">Package Name</label>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="PackageDuration" maxlength="2" type="text" class="validate" check_control="number" name="duration" value="<?php
                                                                    if (!isset($success) && set_value("duration")) {
                                                                        echo set_value("duration");
                                                                    }
                                                                           ?>">
                                                                    <p class="error">
                                                                    <?php
                                                                           if (form_error('duration')) {
                                                                               echo form_error("duration");
                                                                           }
                                                                           ?>
                                                                    </p>
                                                                    <label for="PackageDuration">Package Duration <p style="color: red;font-size: 12px;font-weight: bold; display: inline-block;">* in Month</p></label>
                                                                    <!--<label for="PackageDuration">Package Duration</label>-->
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="PackagePrice" type="text" maxlength="10" class="validate" check_control="number" name="price" value="<?php
                                                                    if (!isset($success) && set_value("price")) {
                                                                        echo set_value("price");
                                                                    }
                                                                           ?>">
                                                                    <p class="error">
                                                                    <?php
                                                                           if (form_error('price')) {
                                                                               echo form_error("price");
                                                                           }
                                                                           ?>
                                                                    </p>
                                                                    <label for="PackagePrice">Package price</label>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Package Discription</label>
                                                                <div class="input-field col s12">
                                                                    <textarea name="description" id="editor1"><?php
                                                                    if (!isset($success) && set_value("description")) {
                                                                        echo set_value("description");
                                                                    }
                                                                           ?></textarea>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('description')) {
                                                                            echo form_error("description");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="add" value="add">Add Package</button>
                                                                    <button class="btn btn-default" type="reset" name="reset">Reset</button>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            } 
                                            else 
                                            {
                                            ?>
                                            <div class="col-md-6">
                                                <div class="box-inn-sp">
                                                    <div class="inn-title">
                                                        <h4>Edit Package Details</h4>
                                                    </div>
                                                    <div class="tab-inn">
                                                        <div class="panel-body">
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="Packagename" maxlength="20" type="text" class="validate" check_control="alpha" name="package" autofocus="" value="<?php
                                                                        if (!isset($success) && set_value("package")) {
                                                                            echo set_value("package");
                                                                        }
                                                                        else
                                                                        {
                                                                            echo $package_edit_detail[0]->package_name;
                                                                        }
                                                                        ?>">
                                                                    <p class="error">
                                                                    <?php
                                                                    if (form_error('package')) {
                                                                        echo form_error("package");
                                                                    }
                                                                    ?>
                                                                    </p>
                                                                    <label for="Packagename">Package Name</label>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="PackageDuration" type="text" class="validate" check_control="number" name="duration" value="<?php
                                                                        if (!isset($success) && set_value("duration")) {
                                                                            echo set_value("duration");
                                                                        }
                                                                        else
                                                                        {
                                                                            echo $package_edit_detail[0]->duration;
                                                                        }
                                                                        ?>">
                                                                    <p class="error">
                                                                    <?php
                                                                    if (form_error('duration')) {
                                                                        echo form_error("duration");
                                                                    }
                                                                    ?>
                                                                    </p>
                                                                    <label for="PackageDuration">Package Duration <p style="color: red;font-size: 12px;font-weight: bold; display: inline-block;">* in Month</p></label>
                                                                    <!--<label for="PackageDuration">Package Duration</label>-->
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="PackagePrice" type="text" class="validate" check_control="number" name="price" value="<?php
                                                                        if (!isset($success) && set_value("price")) {
                                                                            echo set_value("price");
                                                                        }
                                                                        else
                                                                        {
                                                                            echo $package_edit_detail[0]->price;
                                                                        }
                                                                        ?>">
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('price')) {
                                                                            echo form_error("price");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                    <label for="PackagePrice">Package price</label>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Package Discription</label>
                                                                <div class="input-field col s12">
                                                                    <textarea name="description" id="editor1"><?php
                                                                    if (!isset($success) && set_value("description")) {
                                                                        echo set_value("description");
                                                                    }
                                                                    else
                                                                    {
                                                                        echo $package_edit_detail[0]->description;
                                                                    }
                                                                    ?></textarea>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('description')) {
                                                                            echo form_error("description");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="update" value="Edit">Edit Package</button>
                                                                    <a href="<?php echo base_url('Manage_Packages'); ?>" class="btn btn-default">Cancel</a>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            }
                                            ?>
                                        </form>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Manage Package data</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover"id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>Package Name</th>
                                                                <th>Duration</th>
                                                                <th>Price</th>
                                                                <th>Discription</th>
                                                                <th>Edit</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            foreach ($package_detail as $data) {
                                                                ?>
                                                                <tr>
                                                                    <td><?php echo $data->package_name; ?></td>
                                                                    <td><?php echo $data->duration; ?></td>
                                                                    <td><?php echo $data->price; ?></td>
                                                                    <td><?php echo $data->description; ?></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url(); ?>Edit-Package/<?php echo $data->package_id; ?>" class="btnedit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#package-del').attr('href', '<?php echo base_url(); ?>Remove/Package/<?php echo $data->package_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr> 
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Packages</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="package-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
    <?php
    if (isset($success)) {
        ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
        <script>
            CKEDITOR.replace('editor1');
        </script>
    </body>
</html>