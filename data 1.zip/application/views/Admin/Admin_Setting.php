<?php
    $admin = $this->md->my_select('tbl_admin','*',array('email'=>$this->session->userdata('admin')));
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Admin - Setting</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <!--== BODY INNER CONTAINER ==-->
                <div class="sb2-2">
                    <!--== breadcrumbs ==-->
                    <div class="sb2-2-2">
                        <ul>
                            <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                            </li>
                            <li class="active-bre"><a href="<?php echo base_url('Admin_Setting'); ?>"> Admin Setting </a>
                            </li>
                            <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                            </li>
                        </ul>
                    </div>

                    <div class="row">
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Change Profile Photo</h4>
                                </div>
                                <div class="tab-inn">
                                    <form method="post" action="" name="ChangeProfile" enctype="multipart/form-data">
                                        <div class="row">
                                            <div class="input-field col s6">
                                                <img src="<?php base_url() ?><?php echo $admin[0]->profile; ?>" width="200px">
                                            </div>
                                            <div class="input-field col s6">
                                                <img id="previewHolder" width="200px" hidden/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <div class="form-group">
                                                    <div class="tab-inn">
                                                        <div class="file-field input-field">
                                                            <div class="btn">
                                                                <span>File</span>
                                                                <input type="file" name="Photo" id="filePhoto" class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg"/>
                                                            </div>
                                                            <div class="file-path-wrapper">
                                                                <input class="file-path validate" name="Photo" type="text" />
                                                            </div>
                                                            <p class="error">
                                                                <?php
                                                                    if (form_error('Photo')) {
                                                                        echo form_error("Photo");
                                                                    }
                                                                ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div> 
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top: 20px;">
                                            <div class="input-field col s12">
                                                <button class="waves-effect waves-light btn-large btn-log-in" name="update_profile" value="update_profile">Change Profile</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h4>Change password</h4>
                                </div>
                                <div class="tab-inn">
                                    <form method="post" action="" name="Changepassword" class="">
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <label for="Password">Old Password</label>
                                                <input id="password-field" type="password" class="form-control" name="old_pass" autofocus value="<?Php
                                                if (!isset($success) && set_value('old_pass')) {
                                                    echo set_value("old_pass");
                                                }
                                                ?>"/>
                                                <p class="error">
                                                    <?php
                                                    if (form_error('old_pass')) {
                                                        echo form_error("old_pass");
                                                    }
                                                    ?>
                                                </p>
                                                <span toggle="#password-field" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <label for="Password">New Password</label>
                                                <input id="password-field1" type="password" class="form-control" name="new_pass" value="<?Php
                                                if (!isset($success) && set_value('new_pass')) {
                                                    echo set_value("new_pass");
                                                }
                                                ?>"/>
                                                <p class="error">
                                                    <?php
                                                    if (form_error('new_pass')) {
                                                        echo form_error("new_pass");
                                                    }
                                                    ?>
                                                </p>
                                                <span toggle="#password-field1" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="input-field col s12">
                                                <label for="Password">Confirm Password</label>
                                                <input id="password-field2" type="password" class="form-control" name="confirm_pass" value="<?Php
                                                if (!isset($success) && set_value('confirm_pass')) {
                                                    echo set_value("confirm_pass");
                                                }
                                                ?>"/>
                                                <p class="error">
                                                    <?php
                                                    if (form_error('confirm_pass')) {
                                                        echo form_error("confirm_pass");
                                                    }
                                                    ?>
                                                </p>
                                                <span toggle="#password-field2" class="fa fa-fw fa-eye-slash field-icon toggle-password"></span>
                                            </div>
                                        </div>
                                        <div class="row" style="padding-top: 20px;">
                                            <div class="input-field col s12">
                                                <button class="waves-effect waves-light btn-large btn-log-in" name="update" value="update">Change Password</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><small><?php echo $success; ?></small></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><small><?php echo $error; ?></small></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>