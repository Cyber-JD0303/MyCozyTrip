<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Admin - Home</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
        <style>
            .ad-v2-hom-info ul li a{
                color: black !important;
            }    
        </style>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <!--== BODY INNER CONTAINER ==-->
                <div class="sb2-2">
                    <!--== breadcrumbs ==-->
                    <div class="sb2-2-2">
                        <ul>
                            <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                            </li>
                            <li class="active-bre"><a href="<?php echo base_url('Dashboard'); ?>"> Dashboard</a>
                            </li>
                        </ul>
                    </div>
                    <!--== DASHBOARD INFO ==-->
                    <div class="ad-v2-hom-info">
                        <div class="ad-v2-hom-info-inn">
                            <ul>
                                <li>
                                    <a href="<?php echo base_url('Location_Country'); ?>">
                                        <div class="ad-hom-box ad-hom-box-1">
                                            <span class="ad-hom-col-com ad-hom-col-1"><i class="fa fa-building-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Country</p>
                                                <h3><?php echo $Country ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Location_State'); ?>">
                                        <div class="ad-hom-box ad-hom-box-2">
                                            <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-building-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>State</p>
                                                <h3><?php echo $State ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Location_City'); ?>">
                                        <div class="ad-hom-box ad-hom-box-3">
                                            <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-building-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>City</p>
                                                <h3><?php echo $City ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Contact'); ?>">
                                        <div class="ad-hom-box ad-hom-box-4">
                                            <span class="ad-hom-col-com ad-hom-col-4"><i class="fa fa-address-book"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Contact</p>
                                                <h3><?php echo $Contact ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Feedback'); ?>">
                                        <div class="ad-hom-box ad-hom-box-1">
                                            <span class="ad-hom-col-com ad-hom-col-1"><i class="fa fa-comment-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Feedback</p>
                                                <h3><?php echo $Feedback ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Email'); ?>">
                                        <div class="ad-hom-box ad-hom-box-2">
                                            <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-envelope-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Email</p>
                                                <h3><?php echo $Email ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Banner'); ?>">
                                        <div class="ad-hom-box ad-hom-box-3">
                                            <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-flag-checkered"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Banner</p>
                                                <h3><?php echo $Banner ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Packages'); ?>">
                                        <div class="ad-hom-box ad-hom-box-4">
                                            <span class="ad-hom-col-com ad-hom-col-4"><i class="fa fa-gift"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Package</p>
                                                <h3><?php echo $Package ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>

                                <li>
                                    <a href="<?php echo base_url('Manage_User'); ?>">
                                        <div class="ad-hom-box ad-hom-box-1">
                                            <span class="ad-hom-col-com ad-hom-col-1"><i class="fa fa-users"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Users</p>
                                                <h3><?php echo $User ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Agent'); ?>">
                                        <div class="ad-hom-box ad-hom-box-2">
                                            <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-user-secret"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Agent</p>
                                                <h3><?php echo $Agent ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Active_user'); ?>">
                                        <div class="ad-hom-box ad-hom-box-3">
                                            <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-user-circle"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Active User</p>
                                                <h3><?php echo $A_user ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Deactive_user'); ?>">
                                        <div class="ad-hom-box ad-hom-box-4">
                                            <span class="ad-hom-col-com ad-hom-col-4"><i class="fa fa-user-circle-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Deactive User</p>
                                                <h3><?php echo $D_user ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Active_agent'); ?>">
                                        <div class="ad-hom-box ad-hom-box-1">
                                            <span class="ad-hom-col-com ad-hom-col-1"><i class="fa fa-user-secret"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Active Agent</p>
                                                <h3><?php echo $A_agent ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Deactive_agent'); ?>">
                                        <div class="ad-hom-box ad-hom-box-2">
                                            <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-user-secret"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Deactive Agent</p>
                                                <h3><?php echo $D_agent ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Airport'); ?>">
                                        <div class="ad-hom-box ad-hom-box-3">
                                            <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-plane"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Airport</p>
                                                <h3><?php echo $Airport ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                
                                <li>
                                    <a href="<?php echo base_url('Manage_Airlines'); ?>">
                                        <div class="ad-hom-box ad-hom-box-4">
                                            <span class="ad-hom-col-com ad-hom-col-4"><i class="fa fa-paper-plane"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Airline</p>
                                                <h3><?php echo $Airline ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Plane'); ?>">
                                        <div class="ad-hom-box ad-hom-box-1">
                                            <span class="ad-hom-col-com ad-hom-col-1"><i class="fa fa-paper-plane-o"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Plane</p>
                                                <h3><?php echo $Plane ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Manage_Air_schedule'); ?>">
                                        <div class="ad-hom-box ad-hom-box-2">
                                            <span class="ad-hom-col-com ad-hom-col-2"><i class="fa fa-fighter-jet"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Air Schedule</p>
                                                <h3><?php echo $schedule ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo base_url('Flight_Booking'); ?>">
                                        <div class="ad-hom-box ad-hom-box-3">
                                            <span class="ad-hom-col-com ad-hom-col-3"><i class="fa fa-file-text"></i></span>
                                            <div class="ad-hom-view-com">
                                                <p>Flights Booking</p>
                                                <h3><?php echo $F_book; ?></h3>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>