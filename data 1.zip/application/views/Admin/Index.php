<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Login</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <div class="blog-login">
            <div class="blog-login-in">
                <form action="" method="post" name="Adminlogin">
                    <img src="<?php echo base_url(); ?>Admin_Assets/images/logo1.png" alt="" style="width: 300px;"/>
                    <div class="row">
                        <div class="input-field col s12">
                            <label for="email">User Name</label>
                            <input id="email" type="text" class="validate" name="email" autofocus="" value="<?php
                            if ($this->input->cookie('admin_email')) {
                                echo $this->input->cookie('admin_email');
                            } else if (!isset($success) && set_value("email")) {
                                echo set_value("email");
                            }
                            ?>">
                        </div>
                        <p class="error">
                            <?php
                            if (form_error('email')) {
                                echo form_error("email");
                            }
                            ?>
                        </p>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <label for="password">Password</label>
                            <input id="password-field" type="password" id="password" class="form-control" name="ps" value="<?php
                            if ($this->input->cookie('admin_pass')) {
                                echo $this->input->cookie('admin_pass');
                            } else if (!isset($success) && set_value("ps")) {
                                echo set_value("ps");
                            }
                            ?>">
                            <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                            <p class="error">
                                <?php
                                if (form_error('ps')) {
                                    echo form_error("ps");
                                }
                                ?>
                            </p>
                        </div>
                    </div>
                    <div class="error_p" style="margin: 10px !important;">
                        <?php
                        if (isset($error)) {
                            ?>
                            <b style="text-transform: capitalize;"><i class="fa fa-exclamation-triangle"></i> <?php echo $error; ?></b>
                            <?php
                        }
                        ?>
                    </div>
                    <div>
                        <input type="checkbox" id="indeterminate-checkbox" name="svp" value="yes" <?php
                        if ($this->input->cookie('admin_email')) {
                            echo "checked";
                        }
                        ?> /><label for="indeterminate-checkbox"><p> remember me.</p></label>

                    </div>
                    <div class="row">
                        <div class="col-md-12 col" style="text-align: right">
                            <button class="waves-effect waves-light btn-large btn-log-in cust_btn" name="login" value="login">login</button>
                        </div>
                    </div>
                    <a href="<?php echo base_url('Admin_Forgot'); ?>" class="for-pass">Forgot Password?</a>
                </form>
            </div>
        </div>
        <?php
        if ($this->session->userdata('forget')) {
            if ($this->session->userdata('forget') == '1') {
                ?>
                <div class="my_alert_success animated bounceInLeft">
                    <p>
                        <i class="fa fa-check-circle" aria-hidden="true"></i>
                        <b><?php echo 'Check Your Mail Box'; ?></b>
                    </p>
                </div>
                <?php
            }
            if ($this->session->userdata('forget') == '2') {
                ?>
                <div class="my_alert animated bounceInRight">
                    <p>
                        <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                        <b><?php echo 'Check Your Internet Connection Or Internet Speed'; ?></b>
                    </p>
                </div>
                <?php
            }
            $this->session->unset_userdata('forget');
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>