<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Plane details</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">   
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Manage_Plane'); ?>">Manage Plane</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <?php
                                    if (!isset($plane_edit_detail)) {
                                    ?>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Insert Plane Details</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="panel-body">
                                                    <form role="form" action="" method="post">
                                                        <div class="form-group">
                                                            <label>Enter Plane Name</label>
                                                            <div class="input-field col s12">
                                                                <input id="Planename" type="text" class="validate" maxlength="20" check_control="email" name="Planename" autofocus="" value="<?php
                                                                if (!isset($success) && set_value("Planename")) {
                                                                    echo set_value("Planename");
                                                                }
                                                                ?>">
                                                            </div>
                                                            <p class="error">
                                                                <?php
                                                                if (form_error('Planename')) {
                                                                    echo form_error("Planename");
                                                                }
                                                                ?>
                                                            </p>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-12 form-group">
                                                                    <label>Select Airline</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="Airline">
                                                                            <option value="">Select Airline</option>
                                                                            <?php
                                                                                $view_data = $this->md->my_select('tbl_airlines','*');
                                                                                foreach ($view_data as $data)
                                                                                {
                                                                                ?>
                                                                                <option value="<?php echo $data->airlines_id; ?>"<?php
                                                                                    if (!isset($success) && set_select('Airline', $data->airlines_id)) {
                                                                                        echo set_select('Airline', $data->airlines_id);
                                                                                    }
                                                                                    ?>><?php echo $data->airlines; ?></option>
                                                                                <?php
                                                                                }
                                                                                ?>
                                                                        </select>
                                                                    </div>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('Airline')) {
                                                                            echo form_error("Airline");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                                <div class="col-md-12 form-group">
                                                                    <label>Pattern</label>
                                                                    <textarea class="form-control" name="pattern" id="add_seat" placeholder="Enter Seating Pattern" style="height: 150px;"></textarea>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('pattern')) {
                                                                            echo form_error("pattern");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                    <label class="font-bold" style="color: red;"><i class="fa fa-info-circle animated flash infinite" style="font-size: 15px;"></i> 0 - Add Seat || 1 - Add Space  || 2 - Break Line </label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="input-field col s12" align="right">
                                                                <button class="btn btn-primary" name="add" value="add">Add Plane</button>
                                                                <button class="btn btn-default" name="reset" type="reset">Reset</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Seating Arrangement</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="panel-body">
                                                    <div id="seat_arrangement">

                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    else
                                    {
                                    ?>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Edit Plane Details</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="panel-body">
                                                    <form role="form" action="" method="post">
                                                        <div class="form-group">
                                                            <label>Enter Plane Name</label>
                                                            <div class="input-field col s12">
                                                                <input id="Planename" type="text" class="validate" maxlength="20" check_control="email" name="Planename" autofocus="" value="<?php
                                                                if (!isset($success) && set_value("Planename")) {
                                                                    echo set_value("Planename");
                                                                }else
                                                                {
                                                                    echo $plane_edit_detail[0]->plane_name;
                                                                }
                                                                ?>">
                                                            </div>
                                                            <p class="error">
                                                                <?php
                                                                if (form_error('Planename')) {
                                                                    echo form_error("Planename");
                                                                }
                                                                ?>
                                                            </p>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-12 form-group">
                                                                    <label>Select Airline</label>
                                                                    <div class="input-field col s12">
                                                                        <select name="Airline">
                                                                            <option value="">Select Airline</option>
                                                                            <?php
                                                                                $view_data = $this->md->my_select('tbl_airlines','*');
                                                                                foreach ($view_data as $data)
                                                                                {
                                                                                ?>
                                                                                    <option value="<?php echo $data->airlines_id; ?>"<?php
                                                                                        if (!isset($success) && set_select('Airline', $data->airlines_id)) {
                                                                                            echo set_select('Airline', $data->airlines_id);
                                                                                        }
                                                                                        else 
                                                                                        {
                                                                                            if ($data->airlines_id == $plane_edit_detail[0]->airlines_id) {
                                                                                                echo "selected";
                                                                                            }
                                                                                        }
                                                                                        ?>><?php echo $data->airlines; ?></option>
                                                                                <?php
                                                                                }
                                                                                ?>
                                                                        </select>
                                                                    </div>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('Airline')) {
                                                                            echo form_error("Airline");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                                <div class="col-md-12 form-group">
                                                                    <label>Pattern</label>
                                                                    <textarea class="form-control" name="pattern" id="add_seat" placeholder="Enter Seating Pattern" style="height: 150px;"><?php echo $plane_edit_detail[0]->pattern; ?></textarea>
                                                                    <label class="font-bold" style="color: red;"><i class="fa fa-info-circle animated flash infinite" style="font-size: 15px;"></i> 0 - Add Seat || 1 - Add Space  || 2 - Break Line </label>
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('pattern')) {
                                                                            echo form_error("pattern");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="input-field col s12" align="right">
                                                                <button class="btn btn-primary" type="submit" name="update" value="Edit">Edit Plane</button>
                                                                <a href="<?php echo base_url('Manage_Plane'); ?>" class="btn btn-default">Cancel</a>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Seating Arrangement</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="panel-body">
                                                    <div id="seat_arrangement">
                                                        <?php
                                                        $p = str_split($plane_edit_detail[0]->pattern);
                                                        foreach ($p as $data)
                                                        {
                                                            if($data == 1)
                                                            {
                                                                echo '&nbsp; &nbsp;';
                                                            }
                                                            elseif ($data == 2) 
                                                            {
                                                                echo '<br/ >';
                                                            }
                                                            else
                                                            {
                                                            ?>
                                                                <img src="<?php echo base_url() ?>Admin_Assets/images/seat.jpg" width='16' />
                                                            <?php
                                                            }
                                                        }
                                                        ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php
                                    }
                                    ?>
                                    <div style="margin-top: 3%" class="col-md-12">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Manage Plane data</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover"id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No.</th>
                                                                <th>Plane Name</th>
                                                                <th>Airline Name</th>
                                                                <th>More details</th>
                                                                <th>Edit</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $c = 0;
                                                            foreach ($view as $data) 
                                                            {
                                                                $airline=$this->md->my_select("tbl_airlines","airlines ",array('airlines_id' => $data->airlines_id));
                                                                $c++;
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $c; ?></td>
                                                                    <td><?php echo $data->plane_name; ?></td>
                                                                    <td><?php echo $airline[0]->airlines; ?></td>
                                                                    <td><a onclick="details('plane',<?php echo $data->plane_id; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url(); ?>Edit-plane/<?php echo $data->plane_id; ?>" class="btnedit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#Plane-del').attr('href', '<?php echo base_url(); ?>Remove/plane/<?php echo $data->plane_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md1" id="plane" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Plane</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Plane-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>