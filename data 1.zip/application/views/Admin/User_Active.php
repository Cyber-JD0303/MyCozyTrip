<?php
$status = 'y';
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Active User</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Active_user'); ?>">Active User</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Active User</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                   <table class="table table-hover" id="tbl_validation">
                                                       <thead>
                                                           <tr>
                                                               <th>No</th>
                                                               <th>Profile</th>
                                                               <th>Name</th>
                                                               <th>Email</th>
                                                               <th>Phone No</th>
                                                               <th>More Details</th>
                                                               <th>Deactivate</th>
                                                           </tr>
                                                       </thead>
                                                       <tbody>
                                                           <?php
                                                           $c=0;
                                                           foreach($view as $record) {
                                                           $c++;
                                                           ?>
                                                           <tr>
                                                               <td><?php echo $c; ?></td>                                                                
                                                               <td><span class="list-img"><img src="<?php echo base_url(); ?><?php echo $record->profile; ?>" alt=""></span></td>
                                                               <td><?php echo $record->name; ?></td>
                                                               <td><?php echo $record->email; ?></td>
                                                               <td><?php echo $record->phone; ?></td>
                                                               <td><a onclick="details('User',<?php echo $record->Rid; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                               <td><a onclick="$('#Deactive-User').attr('href','<?php echo base_url(); ?>Edit-User/<?php echo $record->status; ?>/<?php echo $record->Rid;  ?>')" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btnview" title="Deactive"><i class="fa fa-toggle-on"></i></a></td>
                                                            </tr>
                                                           <?php
                                                               }       
                                                           ?>
                                                       </tbody>
                                                   </table>
                                               </div>
                                            </div>
                                         </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">User</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Deactivate??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Deactive-User" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Deactivate it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md1" id="User" style="overflow-y: hidden !important;" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            
        </div>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>