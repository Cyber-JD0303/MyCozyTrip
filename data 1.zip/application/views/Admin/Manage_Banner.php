<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Manage Banner</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Manage_Banner'); ?>">Manage Banner</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Banner</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-desi">
                                                    <div class="panel-body">
                                                        <form action="" method="post" enctype="multipart/form-data">
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="Lable" type="text" class="validate" check_control="alpha" name="name" autofocus="">
                                                                    <label for="Lable" class="">Banner Name</label>
                                                                    <p class="error">
                                                                        <?php
                                                                            if (form_error('name')) {
                                                                                echo form_error("name");
                                                                            }
                                                                        ?>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Upload photo</label>
                                                                <div class="tab-inn">
                                                                    <div class="file-field input-field">
                                                                        <div class="btn">
                                                                            <span>File</span>
                                                                            <input type="file" name="Photo" id="filePhoto" class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg"/>
                                                                        </div>
                                                                        <div class="file-path-wrapper">
                                                                            <input class="file-path validate" name="Photo" type="text" />
                                                                        </div>
                                                                        <p class="error">
                                                                            <?php
                                                                                if (form_error('Photo')) {
                                                                                    echo form_error("Photo");
                                                                                }
                                                                            ?>
                                                                        </p>
                                                                    </div>
                                                                    <img id="previewHolder" width="200px" hidden/>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" name="add" value="add">Add Banner</button>
                                                                    <button class="btn btn-default" name="reset" type="reset">Reset</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Banner Data</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover" id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Banner name</th>
                                                                <th>Image</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $c = 0;
                                                            foreach ($view as $data) 
                                                            {
                                                            $c++;
                                                            ?>
                                                                <tr>
                                                                    <td><?php echo $c; ?></td>
                                                                    <td><?php echo $data->Banner_name; ?></td>
                                                                    <td>
                                                                        <span class="list-img"><img src="<?php echo base_url(); ?><?php echo $data->photo; ?>" ></span>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#Banner-del').attr('href', '<?php echo base_url(); ?>Remove/Banner/<?php echo $data->banner_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                </tr>
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Banner</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Banner-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body></html>