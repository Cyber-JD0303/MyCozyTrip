<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Location :: State</title>
        <!--== META TAGS ==-->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
        <?php
        $this->load->view('Admin/Head');
        ?>
    </head>

    <body>
        <?php
        $this->load->view('Admin/Header');
        ?>
        <!--== BODY CONTNAINER ==-->
        <div class="container-fluid sb2">
            <div class="row">
                <?php
                $this->load->view('Admin/Menu');
                ?>
                <div class="container-fluid">
                    <div class="row">
                        <div class="sb2-2">
                            <div class="sb2-2-2">
                                <ul>
                                    <li><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a>
                                    </li>
                                    <li class="active-bre"><a href="<?php echo base_url('Location_State'); ?>">Location State</a>
                                    </li>
                                    <li class="page-back"><a href="<?php echo base_url('Dashboard'); ?>"><i class="fa fa-backward" aria-hidden="true"></i> Back</a>
                                    </li>
                                </ul>
                            </div>
                            <div class="sb2-2-3">
                                <div class="row">
                                    <?php
                                    if (!isset($state_edit_detail)) {
                                        ?> 
                                        <div class="col-md-6">
                                            <div class="box-inn-sp">
                                                <div class="inn-title">
                                                    <h4>Add Coverage State</h4>
                                                </div>
                                                <div class="tab-inn">
                                                    <div class="panel-body">
                                                        <form name="insertstate" class="" method="post" action="" novalidate="">
                                                            <div class="form-group">
                                                                <label>Country</label>
                                                                <select class="" name="country" required="">                                                 
                                                                    <option value="">Select Country</option>
                                                                    <?php
                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "Country"));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->location_id ?>" <?php
                                                                        if (!isset($success) && set_select("country", $data->location_id)) {
                                                                            echo "selected";
                                                                        }
                                                                        ?> ><?php echo $data->name; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <p class="error">
                                                                    <?php
                                                                    if (form_error('country')) {
                                                                        echo form_error("country");
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="State" type="text" maxlength="30" class="validate" check_control="alpha"  name="state" value="<?php
                                                                if (!isset($success) && set_value("state")) {
                                                                    echo set_value("state");
                                                                }
                                                                ?>" />
                                                                <p class="error">
                                                                <?php
                                                                if (form_error('state')) {
                                                                    echo form_error("state");
                                                                }
                                                                ?>
                                                                </p>
                                                                <label for="state">State Name</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="add" value="add">Add State</button>
                                                                    <button class="btn btn-default" type="reset" name="reset" value="reset">Reset</button>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    } else {
                                        ?>
                                        <div class="col-md-6">
                                            <div class="box-inn-sp">
                                                <div class="inn-title">
                                                    <h4>Edit State</h4>
                                                </div>
                                                <div class="tab-inn">
                                                    <div class="panel-body">
                                                        <form name="editstate" method="post" action="" class="" novalidate="">
                                                            <div class="form-group">
                                                                <label>Country</label>
                                                                <select class="" name="country" required="" autofocus="">                                                 
                                                                    <option value="">Select Country</option>
                                                                    <?php
                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "Country"));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->location_id ?>" <?php
                                                                        if ($state_edit_detail[0]->parent_id == $data->location_id) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>><?php echo $data->name; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <p class="error">
                                                                    <?php
                                                                    if (form_error('country')) {
                                                                        echo form_error("country");
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                            <div class="form-group">
                                                                <div class="input-field col s12">
                                                                    <input id="State" type="text"  maxlength="30" class="validate" check_control="alpha" placeholder="Ex.Gujarat" name="state" value="<?php
                                                                    if (!isset($success) && set_value("state")) {
                                                                        echo set_value("state");
                                                                    } else {
                                                                        echo $state_edit_detail[0]->name;
                                                                    }
                                                                    ?>" /> 
                                                                    <p class="error">
                                                                        <?php
                                                                        if (form_error('state')) {
                                                                            echo form_error("state");
                                                                        }
                                                                        ?>
                                                                    </p>
                                                                    <label for="State">Edit State Name</label>
                                                                </div>
                                                            </div>
                                                            <div class="row">
                                                                <div class="input-field col s12" align="right">
                                                                    <button class="btn btn-primary" type="submit" name="update" value="Edit">Edit State</button>
                                                                    <a href="<?php echo base_url('Location_State'); ?>" class="btn btn-default">Cancel</a>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <div class="col-md-6">
                                        <div class="box-inn-sp">
                                            <div class="inn-title">
                                                <h4>Manage State Data</h4>
                                            </div>
                                            <div class="tab-inn">
                                                <div class="table-responsive table-desi">
                                                    <table class="table table-hover" id="tbl_validation">
                                                        <thead>
                                                            <tr>
                                                                <th>No</th>
                                                                <th>Country</th>
                                                                <th>State</th>
                                                                <th>Edit</th>
                                                                <th>Delete</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $c = 0;
                                                            foreach ($state_detail as $data) {
                                                                $c++;
                                                                ?>
                                                                <tr>
                                                                    <th><?php echo $c; ?></th>
                                                                    <td><?php echo $data->country; ?></td>
                                                                    <td><?php echo $data->name; ?></td>
                                                                    <td>
                                                                        <a href="<?php echo base_url(); ?>Edit-State/<?php echo $data->location_id; ?>" class="btnedit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                                                    </td>
                                                                    <td>
                                                                        <a onclick="$('#State-del').attr('href', '<?php echo base_url(); ?>Remove/state/<?php echo $data->location_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                                    </td></tr>
                                                                <?php
                                                            }
                                                            ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">State</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="State-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Admin/Footer_Script');
        ?>
    </body>
</html>