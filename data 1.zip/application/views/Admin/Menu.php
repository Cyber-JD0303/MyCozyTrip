<?php
    $wh['email'] = $this->session->userdata('admin');
    $record=$this->md->my_select('tbl_admin','*',$wh);
?>
<div class="sb2-1">
    <!--== USER INFO ==-->
    <div class="sb2-12">
        <ul>
            <li><img src="<?php echo base_url(); ?><?php echo $record[0]->profile; ?>" alt="">
            </li>
            <li>
                <h5>Welcome Admin <span>Last Login : <?php echo $record[0]->last_login; ?> </span></h5>
            </li>
        </ul>
    </div>
    <!--== LEFT MENU ==-->
    <div class="sb2-13">
        <ul class="collapsible" data-collapsible="accordion">
            <li>
                <a href="<?php echo base_url('Dashboard'); ?>" class="collapsible-header"><i class="fa fa-dashboard" aria-hidden="true"></i> Dashboard</a>
            </li>
            <li>
                <a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-map-marker" aria-hidden="true"></i>Location</a>
                <div class="collapsible-body left-sub-menu">
                    <ul>
                        <li><a href="<?php echo base_url('Location_Country'); ?>"><i class="fa fa-building"></i>Country</a>
                        </li>
                        <li><a href="<?php echo base_url('Location_State'); ?>"><i class="fa fa-building-o"></i>State</a>
                        </li>
                        <li><a href="<?php echo base_url('Location_City'); ?>"><i class="fa fa-building-o"></i>City</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-file" aria-hidden="true"></i>Pages</a>
                <div class="collapsible-body left-sub-menu">
                    <ul>
                        <li><a href="<?php echo base_url('Manage_Contact'); ?>"><i class="fa fa-phone"></i>Contact</a>
                        </li>
                        <li><a href="<?php echo base_url('Manage_Feedback'); ?>"><i class="fa fa-comments-o"></i>Feedback</a>
                        </li>
                        <li><a href="<?php echo base_url('Manage_Email'); ?>"><i class="fa fa-envelope-open"></i>Email Subscriber</a>
                        </li>
                        <li><a href="<?php echo base_url('Manage_Banner'); ?>"><i class="fa fa-flag-checkered"></i>Banner</a>
                        </li>
                        <li><a href="<?php echo base_url('Manage_Packages'); ?>"><i class="fa fa-gift"></i>Package</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-user" aria-hidden="true"></i>User</a>
                <div class="collapsible-body left-sub-menu">
                    <ul>
                        <li><a href="<?php echo base_url('Manage_User'); ?>"><i class="fa fa-user"></i>User</a>
                        </li>
                        <li><a href="<?php echo base_url('Active_user'); ?>"><i class="fa fas fa-toggle-on"></i>Active User</a>
                        </li>
                        <li><a href="<?php echo base_url('Deactive_user'); ?>"><i class="fa fas fa-toggle-off"></i>Deactive User</a>
                        </li>
                        </ul>
                </div>
            </li>
            <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-user-secret" aria-hidden="true"></i>Agent</a>
                <div class="collapsible-body left-sub-menu">
                    <ul>
                        <li><a href="<?php echo base_url('Manage_Agent'); ?>"><i class="fa fa-user-secret"></i>Agent</a>
                        </li>
                        <li><a href="<?php echo base_url('Active_agent'); ?>"><i class="fa fas fa-toggle-on"></i>Active Agent</a>
                        </li>
                        <li><a href="<?php echo base_url('Deactive_agent'); ?>"><i class="fa fas fa-toggle-off"></i>Deactive Agent</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li><a href="<?php echo base_url('Manage_Airport'); ?>"><i class="fa fa-paper-plane" aria-hidden="true"></i>Manage Airport</a>
            </li>
            <li><a href="<?php echo base_url('Manage_Airlines'); ?>"><i class="fa fa-fighter-jet" aria-hidden="true"></i>Manage Airlines</a>
            </li>
            <li><a href="<?php echo base_url('Manage_Plane'); ?>"><i class="fa fa-plane" aria-hidden="true"></i>Manage Plane</a>
            </li>
            <li><a href="javascript:void(0)" class="collapsible-header"><i class="fa fa-fighter-jet" aria-hidden="true"></i>Air Schedule</a>
                <div class="collapsible-body left-sub-menu">
                    <ul>
                        <li><a href="<?php echo base_url('Add_Air_schedule'); ?>"><i class="fa fa-fighter-jet" aria-hidden="true"></i>Add Air Schedule</a>
                        </li>
                        <li><a href="<?php echo base_url('Manage_Air_schedule'); ?>"><i class="fa fa-fighter-jet" aria-hidden="true"></i>Manage Air Schedule</a>
                        </li>
                    </ul>
                </div>
            </li>
            <li>
                <a href="<?php echo base_url('Flight_Booking'); ?>"><i class="fa fa-plane" aria-hidden="true"></i>Flight Booking</a>
            </li>
            <li><a href="<?php echo base_url('Admin_Logout'); ?>"><i class="fa fa-sign-in" aria-hidden="true"></i>Logout</a>
            </li>
        </ul>
    </div>
</div>
