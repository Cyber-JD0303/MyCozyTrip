<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agent Registration</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
        <style>
            body
            {
                background: url(<?php echo base_url(); ?>Agent_Assets/images/AGENTLOG.jpg) no-repeat;
                background-size: cover;
                width: 100%;
                height: 100%;
                position: absolute; 

            }
            .container
            {
                margin-left: 30px;
                margin-top: 50px;
                margin-bottom: 10px;
            }
            .reg
            {
                background: white;
                border-radius: 15px;
                box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.40);
                margin-bottom: 25px;
            }
            .box-inn-sp {
                padding-bottom: 25px;
            }
        </style>
    </head>
    <body>
        <div class="content-wrapper container" >
            <div class="row ">
                <div class="col-md-offset-7 col-md-4 reg box-inn-sp">
                    <div class="account-col text-center"  >
                        <div>
                            <img src="<?php echo base_url(''); ?>Assets/images/txt/logo.png" alt="" style="width: 250px; padding-left: 0px; margin: 10px;">
                        </div>
                        <form class="m-t" role="form" action="" method="post" name="sellerRegister" novalidate="">
                            <div class="form-group">
                                <input type="text" name="Name" class="form-control" check_control="alpha" autofocus Placeholder="Enter Name" value="<?Php
                                if (!isset($success) && set_value('Name')) {
                                    echo set_value("Name");
                                }
                                ?>"/>
                                <div class="error">
                                    <?php
                                    if (form_error('Name')) {
                                        echo form_error("Name");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="Email" name="Email" class="form-control" Placeholder="Enter Email" value="<?Php
                                if (!isset($success) && set_value('Email')) {
                                    echo set_value("Email");
                                }
                                ?>" />
                                <div class="error">
                                    <?php
                                    if (form_error('Email')) {
                                        echo form_error("Email");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" name="Phone" check_control="number" Placeholder="Enter Phone Number" value="<?Php
                                if (!isset($success) && set_value('Phone')) {
                                    echo set_value("Phone");
                                }
                                ?>" />
                                <div class="error">
                                    <?php
                                    if (form_error('Phone')) {
                                        echo form_error("Phone");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input id="password-field" class="form-control" type="Password" name="ps"  Placeholder="Enter Password" value="<?Php
                                if (!isset($success) && set_value('ps')) {
                                    echo set_value("ps");
                                }
                                ?>" />
                                <i toggle="#password-field" class="fa fa-fw fa-eye-slash field-icon toggle-password"></i>
                                <div class="error">
                                    <?php
                                    if (form_error('ps')) {
                                        echo form_error("ps");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input id="password-field1" class="form-control" type="Password" name="cps" Placeholder="Enter confirm Password" value="" />
                                <i toggle="#password-field1" class="fa fa-fw fa-eye-slash field-icon toggle-password"></i>
                                <div class="error">
                                    <?php
                                    if (form_error('cps')) {
                                        echo form_error("cps");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="checkbox" name="Check" <?php
                                if (!isset($success) && set_value('Check')) {
                                    echo "Checked";
                                }
                                ?>
                                       <p class="error">
                                I accept all <a href="<?php echo base_url('Terms'); ?>">terms & conditions</a>
                                and <a href="<?php echo base_url('Privacy'); ?>">privacy policy</a>
                                </p>  
                                <div class="error">
                                    <?php
                                    if (form_error('Check')) {
                                        echo form_error("Check");
                                    }
                                    ?>
                                </div>
                            </div>
                            <div class="form-group" style="margin-bottom: 10px !important;">
                                <button type="submit" value="Register" name="Register" class="btn btn-primary">Signup</button>
                                <button type="reset" value="reset" name="Reset" class="btn btn-primary">Reset</button>
                            </div>
                            <hr style="margin-bottom: 10px !important;margin-top: 10px !important;"/>
                            <a style="margin-bottom:-2px !important;" href="<?php echo base_url('Agent_Login'); ?>">Already have an account?</a>                                   
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?></b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
