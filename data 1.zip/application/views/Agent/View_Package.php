<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>View Package</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>View Package<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">View Package</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Manage Package</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <table id="example" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Package Name</th>
                                                    <th>From location</th>
                                                    <th>To location</th>
                                                    <th>price</th>
                                                    <th>More Details</th>
                                                    <th>Edit</th>
                                                    <th>Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $c = 0;
                                                foreach ($view as $data) 
                                                {
                                                    $f_city = $this->md->my_select("tbl_location","*",array('location_id'=>$data->From_location));
                                                    $t_city = $this->md->my_select("tbl_location","*",array('location_id'=>$data->To_location));

                                                $c++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $c; ?></td>
                                                    <td><?php echo $data->name; ?></td>
                                                    <td><?php echo $f_city[0]->name ?></td>
                                                    <td><?php echo $t_city[0]->name ?></td>
                                                    <td><?php echo $data->price; ?></td>
                                                    <td><a onclick="details('package',<?php echo $data->package_id; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                    <td>
                                                        <a href="<?php echo base_url(); ?>Edit-package_seller/<?php echo $data->package_id; ?>" name="edit" class="sb2-2-1-edit"><i class="fa fa-pencil-square-o"style="color: blue" aria-hidden="true"></i></a>
                                                    </td>
                                                    <td>
                                                        <a onclick="$('#package-del').attr('href', '<?php echo base_url(); ?>Remove-Agent/package/<?php echo $data->package_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div> 
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade bs-example-modal-md1" id="package" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            
        </div>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">place</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:6px 40px; ">Cancel</a>
                        <a id="package-del" class="btn  btn-hover-shine" style="padding:6px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
