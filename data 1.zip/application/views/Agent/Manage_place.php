<?php // echo validation_errors(); die;?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Manage Place</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Manage Place</h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i> Home</a></li>
                                    <li class="active"><a href="<?php echo base_url('Manage_place'); ?>">Manage Place</a></li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-6">
                            <?php
                            if (!isset($editdata)) 
                            {
                            ?>
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Add Coverage Place</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <form method="post" novalidate="" action="" enctype="multipart/form-data">
                                            <!-- Start .panel -->
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-md-4">  
                                                        <label for="country">Country</label>
                                                        <select name="country" required="" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                            <option value="">Select Country</option>
                                                            <?php
                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                            foreach ($recordset as $data) {
                                                                ?>
                                                                <option value="<?php echo $data->location_id; ?>" <?php
                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                echo "selected";
                                                            }
                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                    ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                                if (form_error("country")) 
                                                                {
                                                                    echo form_error("country");
                                                                }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  
                                                        <label for="state">State</label>
                                                        <select name="state" required="" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                            <option value="">Select State</option>
                                                            <?php
                                                            if ($this->input->post('country') && !isset($success)) {
                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                foreach ($recordset as $data) {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id; ?>" <?php
                                                                    if (!isset($success) && set_select('state', $data->location_id)) {
                                                                        echo set_select('state', $data->location_id);
                                                                    }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('state')) {
                                                                echo form_error("state");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  
                                                        <label for="city">City</label>
                                                        <select name="city" id="city" required="" class="fancy-select form-control">
                                                            <option value="">Select City</option>
                                                            <?php
                                                            if ($this->input->post('state') && !isset($success)) {
                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                foreach ($recordset as $data) {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                    if (!isset($success) && set_select('city', $data->location_id)) {
                                                                        echo set_select('city', $data->location_id);
                                                                    }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('city')) {
                                                                echo form_error("city");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label> 
                                                <textarea name="disp" class="form-control" rows="5"><?php
                                                    if(!isset($success) && set_value("disp"))
                                                    {
                                                        echo set_value("disp");
                                                    }?></textarea>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('disp')) {
                                                        echo form_error("disp");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Select Place photo</label> 
                                                <input type="file" name="Photo[]" class="form-control" accept='.jpg,.jpeg,.png' id="filePhoto" multiple="" />
                                                <div class="preview"></div>  
                                                <div class="error">
                                                    <p>
                                                        <?php
                                                        if (isset($p_error)) {
                                                            echo $p_error;
                                                        }
                                                        ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="input-field col s12" align="Right">
                                                <button class="btn btn-primary" name="add" value="add">Add Place</button>
                                                <button class="btn btn-default" type="reset" name="reset">Reset</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php
                            }else{
                                $whe['location_id'] = $editdata[0]->name;
                                $city_detail=$this->md->my_select("tbl_location", "*", $whe);
                                $c = $this->md->my_select('tbl_location','*',array('location_id'=>$city_detail[0]->parent_id));
                                $cn=$c[0]->parent_id;
                            ?>
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Edit Coverage Place</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <form role="form" method="post" action="" enctype="multipart/form-data">
                                            <!-- Start .panel -->
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-md-4">  
                                                        <label for="country">Country</label>
                                                        <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                            <option value="">Select Country</option>;
                                                            <?php
                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                            foreach ($recordset as $data) {
                                                                ?>
                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                echo "selected";
                                                            }
                                                            else
                                                            {
                                                                if( $data->location_id == $cn )
                                                                {
                                                                     echo "selected";
                                                                }
                                                            }
                                                            ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                    ?>
                                                        </select>
                                                        <div class="error">
                                                        <?php
                                                        if (form_error('country')) {
                                                            echo form_error("country");
                                                        }
                                                        ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  
                                                        <label for="state">State</label>
                                                        <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                            <option value="">Select State</option>
                                                            <?php
                                                            if ($this->input->post('country') && !isset($success)) {
                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                foreach ($recordset as $data) {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                    if (!isset($success) && set_select('state', $data->location_id)) {
                                                                        echo set_select('state', $data->location_id);
                                                                    }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$cn));
                                                                foreach ($recordset as $data)
                                                                {
                                                            ?>
                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                               if($city_detail[0]->parent_id == $data->location_id)
                                                               {
                                                                   echo "selected";
                                                               }
                                                            ?>><?php echo $data->name; ?></option>
                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('state')) {
                                                                echo form_error("state");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  
                                                        <label for="city">City</label>
                                                        <select name="city" id="city" class="fancy-select form-control">
                                                            <option value="">Select City</option>
                                                            <?php
                                                            if ($this->input->post('state') && !isset($success)) {
                                                                $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                foreach ($recordset as $data) {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                    if (!isset($success) && set_select('city', $data->location_id)) {
                                                                        echo set_select('city', $data->location_id);
                                                                    }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $recordset = $this->md->my_select("tbl_location","*",array("label"=>"city",'parent_id'=>$c[0]->location_id));
                                                                foreach ($recordset as $data)
                                                                {
                                                            ?>
                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                               if($editdata[0]->name == $data->location_id)
                                                               {
                                                                   echo "selected";
                                                               }
                                                            ?>><?php echo $data->name; ?></option>
                                                            <?php
                                                                }
                                                            }
                                                            ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('city')) {
                                                                echo form_error("city");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Description</label> 
                                                <textarea name="disp" class="form-control" rows="5"><?php
                                                    if(!isset($success) && set_value("disp"))
                                                    {
                                                        echo set_value("disp");
                                                    }
                                                    else
                                                    {
                                                        echo $editdata[0]->description;
                                                    }?></textarea>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('disp')) {
                                                        echo form_error("disp");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Select Place photo</label> 
                                                <input type="file" name="Photo[]" class="form-control" accept='.jpg,.jpeg,.png' id="filePhoto" multiple="" />
                                                <div class="preview"></div>  
                                                <div class="error">
                                                    <p>
                                                        <?php
                                                        if (isset($p_error)) {
                                                            echo $p_error;
                                                        }
                                                        ?>
                                                    </p>
                                                </div>
                                            </div>
                                            <div class="input-field col s12" align="right">
                                                <button class="btn btn-primary" name="update" value="update" type="submit">Edit Country</button>
                                                <a href="<?php echo base_url('Manage_place'); ?>" class="btn btn-default">Cancel</a>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php
                            }
                            ?>
                        </div>
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>View Place</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <table id="example" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>No.</th>
                                                    <th>Name</th>
                                                    <th>More Details</th>
                                                    <th>Edit</th>
                                                    <th>Delete</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $c = 0;
                                                foreach ($view as $data) 
                                                {
                                                $c++;
                                                ?>
                                                <tr>
                                                    <td><?php echo $c; ?></td>
                                                    <td><?php echo $data->city; ?></td>
                                                    <td><a onclick="details('Place',<?php echo $data->place_id; ?>)" data-toggle="modal" data-target=".bs-example-modal-md1" style="cursor: pointer;" class="" title="Read More">Read More</a></td>
                                                    <td>
                                                        <a href="<?php echo base_url(); ?>Edit-place/<?php echo $data->place_id; ?>" class="btnedit" title="Edit"><i class="fa fa-pencil-square-o" style="color: blue;" aria-hidden="true"></i></a>
                                                    </td>
                                                    <td>
                                                        <a onclick="$('#place-del').attr('href', '<?php echo base_url(); ?>Remove-Agent/place/<?php echo $data->place_id; ?>')" title="Delete" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                    </td>
                                                </tr>
                                                <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">place</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:6px 40px; ">Cancel</a>
                        <a id="place-del" class="btn  btn-hover-shine" style="padding:6px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <div class="modal fade bs-example-modal-md1" id="Place" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
