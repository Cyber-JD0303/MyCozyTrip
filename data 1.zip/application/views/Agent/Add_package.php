<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Package</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
        <script src="<?php echo base_url(); ?>Agent_Assets/js/ckeditor/ckeditor.js" type="text/javascript"></script>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
            <?php
            $this->load->view('Agent/Menu');
            ?>

        <section class="page">
            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Package</h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i> Home</a></li>
                                    <li class="active"><a href="<?php echo base_url('Add_Package'); ?>">Add Package</a></li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <?php
                        if (!isset($editdata)) {
                            ?>
                            <div class="col-md-12">
                                <div class="box-inn-sp">
                                    <div class="inn-title">
                                        <h2>Add Package</h2>
                                    </div>
                                    <div class="tab-inn">
                                        <div class="panel-body">
                                            <div class="panel panel-card margin-b-30">
                                                <form method="post" action="" enctype="multipart/form-data" class="" novalidate="" name="AddPacakge">
                                                    <div class="form-group">
                                                        <!-- Start .panel -->
                                                        <div class="form-group">
                                                            <label>Package Name</label> 
                                                            <input name="Package" type="text" placeholder="Enter Package Name" class="form-control" value="<?php
                                                            if (!isset($success) && set_value("Package")) {
                                                                echo set_value("Package");
                                                            }
                                                            ?>">
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('Package')) {
                                                                    echo form_error("Package");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <label>From Location</label>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="country">Country</label>
                                                                    <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                echo "selected";
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('country')) {
                                                                            echo form_error("country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label for="state">State </label>
                                                                    <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                    echo set_select('state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('state')) {
                                                                            echo form_error("state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label>City </label>
                                                                    <select name="city" id="city" class="fancy-select form-control">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                    echo set_select('city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error("city")) {
                                                                            echo form_error("city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <label>To Location</label>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="t_country">Country</label>
                                                                    <select name="t_country" id="t_country" class="fancy-select form-control" onchange="set_combo('t_state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("t_country", $data->location_id)) {
                                                                                echo "selected";
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_country')) {
                                                                            echo form_error("t_country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  <label for="t_state">State </label>
                                                                    <select name="t_state" id="t_state" class="fancy-select form-control" onchange="set_combo('t_city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('t_country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("t_country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('t_state', $data->location_id)) {
                                                                                    echo set_select('t_state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_state')) {
                                                                            echo form_error("t_state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label for="t_city">City</label>
                                                                    <select name="t_city" id="t_city" class="fancy-select form-control" onchange="set_combo('hotel', this.value);">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('t_state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("t_state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('t_city', $data->location_id)) {
                                                                                    echo set_select('t_city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_city')) {
                                                                            echo form_error("t_city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Price</label>
                                                                <p style="font-size: 9px;text-transform: capitalize;margin-bottom : 0px !important;display: inline-block;color: red;">* Per Person</p>
                                                                <input type="number" name="Price" placeholder="Enter Price" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("Price")) {
                                                                    echo set_value("Price");
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Price')) {
                                                                        echo form_error("Price");
                                                                    }
                                                                    ?>
                                                                </div>

                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label for="hotel">Hotel</label>
                                                                <select name="hotel" id="hotel" multiple size="2" tabindex="-1" class="fancy-select form-control">
                                                                    <?php
                                                                    if ($this->input->post('t_city') && !isset($success)) {
                                                                        $wh['email'] = $this->session->userdata('agent');
                                                                        $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                        $agent = $record[0]->agent_id;
                                                                        $recordset = $this->md->my_select("tbl_hotel", "*", array('agent_id' => $agent, 'location_id' => $this->input->post('t_city')));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->hotel_id ?>" <?php
                                                                            if (!isset($success) && set_select('hotel', $data->hotel_id)) {
                                                                                echo set_select('hotel', $data->hotel_id);
                                                                            }
                                                                            ?>><?php echo $data->hotel_name; ?></option>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                            ?>
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('hotel[]')) {
                                                                        echo form_error("hotel[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Discription</label>
                                                            <textarea id="editor1" name="disp"><?php
                                                                if (!isset($success) && set_value("disp")) {
                                                                    echo set_value("disp");
                                                                }
                                                                ?></textarea>
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('disp')) {
                                                                    echo form_error("disp");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group" style="margin-bottom: 0px !important;">
                                                            <label>traveler type</label> <br/>
                                                            <label><input type="radio" name="Type" value="Flight" <?php
                                                                if (!isset($success) && set_radio('Type', 'Flight')) {
                                                                    echo set_radio('Type', 'Flight');
                                                                }
                                                                ?> onclick="set_air('Travel', city.value, t_city.value);"/> flight</label>&nbsp;&nbsp;
                                                            <label><input type="radio" name="Type" value="Train" <?php
                                                                if (!isset($success) && set_radio('Type', 'Train')) {
                                                                    echo set_radio('Type', 'Train');
                                                                }
                                                                ?> onclick="Hide()"/> train</label>&nbsp;&nbsp;
                                                            <label><input type="radio" name="Type" value="Bus" <?php
                                                                if (!isset($success) && set_radio('Type', 'Bus')) {
                                                                    echo set_radio('Type', 'Bus');
                                                                }
                                                                ?> onclick="Hide()"/> bus</label>&nbsp;&nbsp;
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('Type')) {
                                                                    echo form_error("Type");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="row" id="Travel" style="margin: 10px;"></div>
                                                        <div class="row">                                               
                                                            <div class="form-group col-md-6">
                                                                <label for="facility">Facility</label> 
                                                                <select class="form-control fancy-select" id="facility" name="Facility[]" multiple="" tabindex="-1" size="5">
                                                                    <?php
                                                                    $wh['email'] = $this->session->userdata('agent');
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_facility", "*", array("type" => "Package", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->facility_id ?>" <?php
                                                                        if (!isset($success) && set_select('Facility', $data->facility_id)) {
                                                                            echo set_select('Facility', $data->facility_id);
                                                                        }
                                                                        ?>><?php echo $data->facility; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Facility[]')) {
                                                                        echo form_error("Facility[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>       
                                                            <div class="form-group col-md-6">
                                                                <label for="policy">Policy</label> 
                                                                <select class="form-control fancy-select" id="policy" name="Policy[]" multiple="" tabindex="-1" size="5">
                                                                    <?php
                                                                    $wh['email'] = $this->session->userdata('agent');
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_policy", "*", array("type" => "Package", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->policy_id ?>" <?php
                                                                        if (!isset($success) && set_select('Policy', $data->policy_id)) {
                                                                            echo set_select('Policy', $data->policy_id);
                                                                        }
                                                                        ?>><?php echo $data->policy; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Policy[]')) {
                                                                        echo form_error("Policy[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>       
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Select Package Photos</label> 
                                                            <input type="file" name="package_pic[]" class="form-control" id="filePhoto" accept='.jpg,.jpeg,.png' multiple="" />
                                                            <div class="preview"></div>
                                                            <div class="error">
                                                                <p>    
                                                                    <?php
                                                                    if (isset($p_error)) {
                                                                        echo $p_error;
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="input-field col s12" align="Right">
                                                            <button class="btn btn-primary" name="add" value="add">Add Package</button>
                                                            <button class="btn btn-default" type="reset" name="reset" value="Reset">Reset</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } else {
                            $whe['location_id'] = $editdata[0]->From_location;
                            $where['location_id'] = $editdata[0]->To_location;
                            $city_detail = $this->md->my_select("tbl_location", "*", $whe);
                            $city_detail2 = $this->md->my_select("tbl_location", "*", $where);
                            $c = $this->md->my_select('tbl_location', '*', array('location_id' => $city_detail[0]->parent_id));
                            $c2 = $this->md->my_select('tbl_location', '*', array('location_id' => $city_detail2[0]->parent_id));
                            $cn = $c[0]->parent_id;
                            $cn2 = $c2[0]->parent_id;
                            ?>
                            <div class="col-md-12">
                                <div class="box-inn-sp">
                                    <div class="inn-title">
                                        <h2>Edit Package</h2>
                                    </div>
                                    <div class="tab-inn">
                                        <div class="panel-body">
                                            <div class="panel panel-card margin-b-30">
                                                <form method="post" action="" enctype="multipart/form-data" class="" novalidate="" name="AddPacakge">
                                                    <div class="form-group">
                                                        <!-- Start .panel -->
                                                        <div class="form-group">
                                                            <label>Package Name</label> 
                                                            <input name="Package" type="text" placeholder="Enter Package Name" class="form-control" value="<?php
                                                            if (!isset($success) && set_value("Package")) {
                                                                echo set_value("Package");
                                                            } else {
                                                                echo $editdata[0]->name;
                                                            }
                                                            ?>">
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('Package')) {
                                                                    echo form_error("Package");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <label>From Location</label>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="country">Country</label>
                                                                    <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                echo "selected";
                                                                            } else {
                                                                                if ($data->location_id == $cn) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('country')) {
                                                                            echo form_error("country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4"> 
                                                                    <label>State </label>
                                                                    <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                    echo set_select('state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $cn));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($city_detail[0]->parent_id == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('state')) {
                                                                            echo form_error("state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label>City </label>
                                                                    <select name="city" id="city" class="fancy-select form-control">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                    echo set_select('city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $c[0]->location_id));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($editdata[0]->From_location == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('city')) {
                                                                            echo form_error("city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <label>To Location</label>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="t_country">Country</label>
                                                                    <select name="t_country" id="t_country" class="fancy-select form-control" onchange="set_combo('t_state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("t_country", $data->location_id)) {
                                                                                echo "selected";
                                                                            } else {
                                                                                if ($data->location_id == $cn2) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_country')) {
                                                                            echo form_error("t_country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  <label for="t_state">State </label>
                                                                    <select name="t_state" id="t_state" class="fancy-select form-control" onchange="set_combo('t_city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('t_country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("t_country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('t_state', $data->location_id)) {
                                                                                    echo set_select('t_state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $cn2));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($city_detail2[0]->parent_id == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_state')) {
                                                                            echo form_error("t_state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label for="t_city">City</label>
                                                                    <select name="t_city" id="t_city" class="fancy-select form-control" onchange="set_combo('hotel', this.value);">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('t_state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("t_state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('t_city', $data->location_id)) {
                                                                                    echo set_select('t_city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $c2[0]->location_id));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($editdata[0]->To_location == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('t_city')) {
                                                                            echo form_error("t_city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Price</label>
                                                                <p style="font-size: 9px;text-transform: capitalize;margin-bottom : 0px !important;display: inline-block;color: red;">* Per Person</p>
                                                                <input type="text" name="Price" placeholder="Enter Price" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("Price")) {
                                                                    echo set_value("Price");
                                                                } else {
                                                                    echo $editdata[0]->price;
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Price')) {
                                                                        echo form_error("Price");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Hotel</label>
                                                                <select name="hotel[]" id="hotel" multiple size="2" class="fancy-select form-control">
                                                                    <?php
                                                                    if ($this->input->post('t_city') && !isset($success)) {
                                                                        $wh['email'] = $this->session->userdata('agent');
                                                                        $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                        $agent = $record[0]->agent_id;
                                                                        $recordset = $this->md->my_select("tbl_hotel", "*", array('agent_id' => $agent, 'location_id' => $this->input->post('t_city')));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->hotel_id ?>" <?php
                                                                            if (!isset($success) && set_select('hotel', $data->hotel_id)) {
                                                                                echo set_select('hotel', $data->hotel_id);
                                                                            }
                                                                            ?>><?php echo $data->hotel_name; ?></option>
                                                                                    <?php
                                                                                }
                                                                            } else {
                                                                                $wh['email'] = $this->session->userdata('agent');
                                                                                $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                                $agent = $record[0]->agent_id;
                                                                                $recordset = $this->md->my_select("tbl_hotel", "*", array('location_id' => $editdata[0]->To_location, 'agent_id' => $agent));
                                                                                foreach ($recordset as $data) {
                                                                                    ?>
                                                                            <option value="<?php echo $data->hotel_id ?>" <?php
                                                                            if ($editdata[0]->hotel_id == $data->hotel_id) {
                                                                                echo "selected";
                                                                            } else {
                                                                                $hotel = explode(',', $editdata[0]->hotel_id);
                                                                                foreach ($hotel as $h) {
                                                                                    if ($data->hotel_id == $h) {
                                                                                        echo "selected";
                                                                                    }
                                                                                }
                                                                            }
                                                                            ?>><?php echo $data->hotel_name; ?></option>
                                                                                    <?php
                                                                                }
                                                                            }
                                                                            ?>
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('hotel')) {
                                                                        echo form_error("hotel");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Discription</label>
                                                            <textarea id="editor1" name="disp"><?php
                                                                if (!isset($success) && set_value("disp")) {
                                                                    echo set_value("disp");
                                                                } else {
                                                                    echo $editdata[0]->description;
                                                                }
                                                                ?></textarea>
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('disp')) {
                                                                    echo form_error("disp");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group" style="margin-bottom: 0px !important;">
                                                            <label>traveler type</label> <br/>
                                                            <label><input type="radio" name="Type" value="Flight" <?php
                                                                echo set_value('Type', $editdata[0]->travel_type) == 'Flight' ? "checked" : "";
                                                                ?> onchange="set_air('Travel', city.value, t_city.value);"/> flight</label>&nbsp;&nbsp;
                                                            <label><input type="radio" name="Type" value="Train" <?php
                                                                echo set_value('Type', $editdata[0]->travel_type) == 'Train' ? "checked" : "";
                                                                ?> onclick="Hide()"/> train</label>&nbsp;&nbsp;
                                                            <label><input type="radio" name="Type" value="Bus" <?php
                                                                echo set_value('Type', $editdata[0]->travel_type) == 'Bus' ? "checked" : "";
                                                                ?> onclick="Hide()"/> bus</label>&nbsp;&nbsp;
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('Type')) {
                                                                    echo form_error("Type");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="row" id="Travel" style="margin: 10px;">
                                                            <?php
                                                            if ($editdata[0]->travel_type == 'Flight') {
                                                                $recordset = $this->md->my_select('tbl_air_schedule', '*', array('from_location' => $editdata[0]->From_location, 'to_location' => $editdata[0]->To_location));
                                                                foreach ($recordset as $data) {
                                                                    $plane = $this->md->my_select('tbl_plane', '*', array('plane_id' => $data->plan_id));
                                                                    $Airline = $this->md->my_select('tbl_airlines', 'airlines', array('airlines_id' => $plane[0]->airlines_id));
                                                                    ?>
                                                                    <div class="col-md-4">
                                                                        <div style="padding: 20px;background: #f5f5f5">
                                                                            <label>
                                                                                <input type="radio" name="Air" style="zoom: 1.4;vertical-align: sub" value="<?php echo $data->schedule_id; ?>" <?php
                                                                                echo set_value('Air', $editdata[0]->travel_id) == "$data->schedule_id" ? "checked" : "";
                                                                                ?>/>
                                                                                Select Plane
                                                                            </label>
                                                                            <br />
                                                                            <table>
                                                                                <tr>
                                                                                    <th>Plane :&nbsp;&nbsp;</th> 
                                                                                    <td><?php echo $plane[0]->plane_name; ?></td> 
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Airline :&nbsp;&nbsp;</th> 
                                                                                    <td><?php echo $Airline[0]->airlines; ?></td> 
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>Price :&nbsp;&nbsp;</th> 
                                                                                    <td><?php echo $data->price; ?></td> 
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>From Time :&nbsp;&nbsp;</th> 
                                                                                    <td><?php echo $data->from_time; ?></td> 
                                                                                </tr>
                                                                                <tr>
                                                                                    <th>To Time :&nbsp;&nbsp;</th> 
                                                                                    <td><?php echo $data->to_time; ?></td> 
                                                                                </tr>
                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                    <?php
                                                                }
                                                            }
                                                            ?>
                                                        </div>
                                                        <div class="row">                                               
                                                            <div class="col-md-6 form-group">
                                                                <label>Facility</label> 
                                                                <select class="form-control select2" name="Facility[]" multiple="" tabindex="-1" size="5">
                                                                    <?php
                                                                    $wh['email'] = $this->session->userdata('agent');
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_facility", "*", array("type" => "Package", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->facility_id ?>" <?php
                                                                        if (!isset($success) && set_select('Facility', $data->facility_id)) {
                                                                            echo set_select('Facility', $data->facility_id);
                                                                        } else {
                                                                            $Facility = explode(',', $editdata[0]->facility_id);
                                                                            foreach ($Facility as $f) {
                                                                                if ($data->facility_id == $f) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>><?php echo $data->facility; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Facility')) {
                                                                        echo form_error("Facility");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>       
                                                            <div class="col-md-6 form-group">
                                                                <label>Policy</label> 
                                                                <select class="form-control select2" name="Policy[]" multiple="" tabindex="-1" size="5">
                                                                    <?php
                                                                    $wh['email'] = $this->session->userdata('agent');
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_policy", "*", array("type" => "Package", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->policy_id ?>" <?php
                                                                        if (!isset($success) && set_select('Policy', $data->policy_id)) {
                                                                            echo set_select('Policy', $data->policy_id);
                                                                        } else {
                                                                            $Policy = explode(',', $editdata[0]->policy_id);
                                                                            foreach ($Policy as $p) {
                                                                                if ($data->policy_id == $p) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>><?php echo $data->policy; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Policy')) {
                                                                        echo form_error("Policy");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>       
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Select Package Photos</label> 
                                                            <input type="file" name="package_pic[]" class="form-control" id="filePhoto" accept='.jpg,.jpeg,.png' multiple="" />
                                                            <div class="preview"></div>
                                                            <div class="error">
                                                                <p>    
                                                                    <?php
                                                                    if (isset($p_error)) {
                                                                        echo $p_error;
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="input-field col s12" align="right">
                                                            <button class="btn btn-primary" name="edit" value="update" type="submit">Edit Package</button>
                                                            <a href="<?php echo base_url('View_Package'); ?>" class="btn btn-default">Cancel</a>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div>
            </div>
        </section>
        <script type="text/javascript">
            CKEDITOR.replace('editor1');
        </script>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
