<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Deactive Review</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Deactive Review</h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Deactive Review</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">      
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Deactive Review</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <table id="example" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>NO</th>
                                                    <th>name</th>
                                                    <th>type</th>
                                                    <th>Review</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $c = 0;
                                                foreach ($package_detail as $data) {
                                                    $c++;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $c; ?></td>
                                                        <td><?php echo $data->name; ?></td>
                                                        <td><?php echo $data->type; ?></td>
                                                        <td><?Php echo $data->review; ?></td>
                                                        <td>
                                                            <a onclick="$('#review-active').attr('href', '<?php echo base_url(); ?>Edit-review/<?php echo $data->status; ?>/<?php echo $data->review_id; ?>')" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btnview" title="Deactive"><i class="glyphicon glyphicon-thumbs-up" style="color: blue !important;"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                                <?php
                                                foreach ($hotel_detail as $data) {
                                                    $c++;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $c; ?></td>
                                                        <td><?php echo $data->name; ?></td>
                                                        <td><?php echo $data->type; ?></td>
                                                        <td><?Php echo $data->review; ?></td>
                                                        <td>
                                                            <a onclick="$('#review-active').attr('href', '<?php echo base_url(); ?>Edit-review/<?php echo $data->status; ?>/<?php echo $data->review_id; ?>')" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btnview" title="Deactive"><i class="glyphicon glyphicon-thumbs-up" style="color: blue !important;"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                                <?php
                                                foreach ($place_detail as $data) {
                                                    $c++;
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $c; ?></td>
                                                        <td><?php echo $data->name; ?></td>
                                                        <td><?php echo $data->type; ?></td>
                                                        <td><?Php echo $data->review; ?></td>
                                                        <td>
                                                            <a onclick="$('#review-active').attr('href', '<?php echo base_url(); ?>Edit-review/<?php echo $data->status; ?>/<?php echo $data->review_id; ?>')" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer;" class="btnview" title="Deactive"><i class="glyphicon glyphicon-thumbs-up" style="color: blue !important;"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div> 
                </div>
            </div>
        </section>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">active Review</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Active Review ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="review-active" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,active it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
