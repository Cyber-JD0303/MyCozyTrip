<script src="<?php echo base_url(); ?>Agent_Assets/js/jquery.min.js"  type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>Agent_Assets/bootstrap/js/bootstrap.min.js" type="text/javascript" ></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/metisMenu.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/jquery.nanoscroller.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/jquery-jvectormap-1.2.2.min.js"></script>
<!-- Flot -->
<script src="<?php echo base_url(); ?>Agent_Assets/js/flot/jquery.flot.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/flot/jquery.flot.tooltip.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/flot/jquery.flot.resize.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/flot/jquery.flot.pie.js"></script>
<!--<script src="<?php echo base_url(); ?>Agent_Assets/js/chartjs/Chart.min.js"></script>-->
<script src="<?php echo base_url(); ?>Agent_Assets/js/pace.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/waves.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/morris_chart/raphael-2.1.0.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/morris_chart/morris.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/jquery.sparkline.min.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/jquery-jvectormap-world-mill-en.js"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/myjs.js"></script>
<!--        <script src="js/jquery.nanoscroller.min.js"></script>-->
<script src="<?php echo base_url(); ?>Agent_Assets/js/custom.js" type="text/javascript" ></script>
<!-- ChartJS-->
<script src="<?php echo base_url(); ?>Agent_Assets/js/chartjs/Chart.min.js"></script>

<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/jquery.dataTables.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/dataTables.buttons.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/buttons.flash.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/jszip.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/pdfmake.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/vfs_fonts.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/buttons.html5.min.js" type="text/javascript"></script>
<script src="<?php echo base_url(); ?>Agent_Assets/js/Validation/buttons.print.min.js" type="text/javascript"></script>

<!--data table start-->
<script type="text/javascript">
    $(document).ready(function () {
        $('#example').DataTable({
            dom: 'Bfrtip',
            buttons: [
                 'excel', 'pdf', 'print'
            ]
        });
    });
</script>
<!--data table end-->

<!--validation start-->

<script type="text/javascript">
    $("input[check_control]").keypress(function (e) {
        if ($(this).attr("check_control") == "alpha") {
            var regex = new RegExp("^[a-zA-Z ]+$");
        } else if ($(this).attr("check_control") == "number") {
            var regex = new RegExp("^[0-9]+$");
        } else if ($(this).attr("check_control") == "email")
        {
            var regex = new RegExp("^[a-zA-Z0-9.@_]+$");
        }

        var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
        if (regex.test(str)) {
            $(this).removeClass("form_error").addClass("form_valid");
            return true;
        } else {
            $(this).removeClass("form_valid").addClass("form_error");
        }

        e.preventDefault();
        return false;
    });

    $("input[check_control]").blur(function () {

        var val = this.value;
        if (val == "") {
            $(this).removeClass("form_valid").addClass("form_error");
        } else {
            $(this).removeClass("form_error").addClass("form_valid");
        }
    });
</script>

<!--validation end-->
<script>
    setTimeout(function () {
    $(".my_alert_success").fadeOut("slow");
    }, 3000);
    setTimeout(function () {
    $(".my_alert").fadeOut("slow");
    }, 3000);
</script>