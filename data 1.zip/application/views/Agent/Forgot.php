<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agent - Forget</title>

        <?php
            $this->load->view('Agent/head');
        ?>
        <style>
            body
            {
                background: url(<?php echo base_url(); ?>Agent_Assets/images/AGENTLOG.jpg) no-repeat;
                background-size: cover;
                width: 100%;
                height: 100%;
                position: absolute; 
                
            }
            .container
            {
                margin-left: 150px;
                margin-top: 150px;
            }
            .reg
            {
                background: white;
                border-radius: 10px;
                box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.40);
                margin-bottom: 25px;
            }
            .box-inn-sp {
                padding-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="content-wrapper container">
            <div class="row">
                <div class="col-md-offset-6 col-md-4 box-inn-sp reg" >
                <div class="account-col text-center"  >
                <div><img src="<?php echo base_url(''); ?>Assets/images/txt/logo.png" alt="" style="width: 200px; padding-left: 0px; margin: 10px;"></div>
                <form class="m-t" name="forgotpassword" action="" method="post" novalidate="">
                        <div class="form-group">
                            <input type="Email" class="form-control" placeholder="Enter Email" required="" id="email" name="Email" autofocus="" value="<?Php
                            if (!isset($success) && set_value('Email')) 
                            {
                                echo set_value("Email");
                            }
                            ?>" />
                            <div class="error">
                                <?php
                                if (form_error('Email')) 
                                {
                                    echo form_error("Email");
                                }
                                ?>
                            </div>
                        </div>
                    <button type="submit" class="btn btn-primary  " name="Forgot" value="Forgot" style="margin: 5px;padding: 10px 30px;font-weight: bolder;">Forgot</button>
                      <hr style="margin-top: 2px" />
                          <a  href="<?php echo base_url('Agent_Login'); ?>">Back to Login</a>
                     </form>
                </div>
             </div>
        </div>
      </div>
      
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
            $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
