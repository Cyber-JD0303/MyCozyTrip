 <!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agent - Hotel Booking</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Hotel Booking<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Hotel Booking</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Hotel Booking</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                     <table id="example" class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>NO</th>
                                                <th>Name</th>
                                                <th>phone No</th>
                                                <th>email</th>
                                                <th>Hotel Name</th>
                                                <th>Check In date</th>
                                                <th>Amount</th>
                                                <th>Invoice</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $c=0;
                                                foreach($view as $data)
                                                {
                                                    $user = $this->md->my_select('tbl_register','*',array('Rid' => $data->Rid));
                                                    $hotel = $this->md->my_select('tbl_hotel','*',array('hotel_id' => $data->hotel_id));
                                            $c++;
                                            ?>
                                            <tr>
                                                <td><?php echo $c; ?></td>
                                                <td><?php echo $user[0]->name; ?></td>
                                                <td><?php echo $user[0]->phone; ?></td>
                                                <td><?php echo $user[0]->email; ?></td>
                                                <td><?php echo $hotel[0]->hotel_name; ?></td>
                                                <td><?php echo date('d-m-Y',strtotime($data->checking_date)); ?></td>
                                                <td><?php echo $data->amount; ?></td>
                                                <td><a onclick="Bill('DivIdToPrint',<?php echo $data->booking_id; ?>);" style="cursor: pointer;">Download Invoice</a></td>
                                            </tr>
                                            <?php
                                                }
                                            ?>
                                        </tbody>
                                    </table>
                                    </div>
                                </div>
                            </div>
                            <div id="DivIdToPrint" class="hidden"></div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
        <script>
            var base_url = "http://localhost/MyCozy/";
            function Bill(action, id)
            {
                $data = {action: action, id: id};
                var path = base_url + "backend/Bill2/";
                $.post(path, $data, function (data) 
                {
                    $("#" + action).html(data);
                    printDiv();
                });     
            }
            function printDiv()
            {
                var contents = $("#DivIdToPrint").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({"position": "absolute", "top": "-1000000px"});
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>Hotel Booking Invoice</title>');
                //Append the external CSS file.
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/mycss.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/theme-turqoise.css" id="template-color" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/lightslider.min.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styler.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');
                frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>');
                //Append the DIV contents.
                frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();

                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 500);
            }
        </script>
    </body>
</html>


