<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agent - login</title>

        <?php
        $this->load->view('Agent/head');
        ?>
        <style>

            body
            {
                background: url(<?php base_url(); ?>Agent_Assets/images/AGENTLOG.jpg) !important ;
                background-repeat: no-repeat !important;
                height: 100% !important;
                width : 100% !important;
                background-position: top !important;
                background-attachment: fixed !important;
                background-size: 1550px 800px !important;
            }
            .container
            {
                margin-top : 120px;
            }
            .reg
            {
                background: white;
                border-radius: 10px;
                box-shadow: 0 8px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.40);
                margin-bottom: 25px;           
            }
            .box-inn-sp {
                padding-bottom: 25px;
            }
        </style>

    </head>
    <body>
        <div class="content-wrapper container">
            <div class="row">
                <div class="col-md-offset-7 col-md-4 reg box-inn-sp">
                    <div class="account-col text-center">
                        <div>
                            <img src="<?php echo base_url(''); ?>Agent_Assets/images/logo.png" alt="" style="width: 230px; padding-left: 0px; margin: 10px;">
                        </div>
                        <form action="" name="agentlogin" method="post" novalidate="">
                            <div class="form-group">
                                <input type="Email" name="email" id="email" class="form-control" check_control="email" Placeholder="Enter Email" autofocus="" value="<?php
                                if ($this->input->cookie('agent_email')) {
                                    echo $this->input->cookie('agent_email');
                                } else if (!isset($success) && set_value("email")) {
                                    echo set_value("email");
                                }
                                ?>"/>
                            </div>
                            <div class="form-group">
                                <input id="password-field" class="form-control" type="password" name="ps" Placeholder="Enter Password" value="<?php
                                if ($this->input->cookie('agent_pass')) {
                                    echo $this->input->cookie('agent_pass');
                                } else if (!isset($success) && set_value("ps")) {
                                    echo set_value("ps");
                                }
                                ?>"/>
                                <i class="fa fa-eye-slash field-icon toggle-password"  toggle="#password-field"></i>
                            </div>
                            <div class="form-group">
                                <div class="i-checks" align=left>
                                    <label><input type="checkbox" name="svp" name="svp" <?php
                                        if ($this->input->cookie('agent_email')) {
                                            echo "checked";
                                        }
                                        ?> /> Remember me 
                                    </label>
                                </div>
                            </div>
                            <div style="margin: 10px !important; color: red;">
                                <?php
                                if (isset($error)) {
                                    ?>
                                    <b style="text-transform: capitalize;"><i class="fa fa-exclamation-triangle"></i> <?php echo $error; ?></b>
                                    <?php
                                }
                                ?>
                            </div>
                            <div>
                                <p align="Right" style="margin:5px">
                                    <a href="<?php echo base_url('Agent_Forget'); ?>"><small>Forgot password?</small></a>
                                </p>
                            </div>
                            <div class="form-group">
                                <button type="submit" value="login" id="submit" name="login" class="btn btn-primary btn-block" >Login</button>
                            </div>
                            <hr />
                            <a  href="<?php echo base_url('Agent_Register'); ?>">Do not have an account?</a>                              
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
