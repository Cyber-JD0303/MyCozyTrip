<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Hotel</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            $wh['email'] = $this->session->userdata('agent');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Add Hotel<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Add Hotel</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <?php
                        if (!isset($editdata)) {
                            ?>
                            <div class="col-md-12">
                                <div class="box-inn-sp">
                                    <div class="inn-title">
                                        <h2>Add Hotel</h2>
                                    </div>
                                    <div class="tab-inn">
                                        <div class="panel-body">
                                            <form method="post" action="" enctype="multipart/form-data" novalidate="">
                                                <div class="form-group">
                                                    <div class="panel panel-card margin-b-30">
                                                        <!-- Start .panel -->
                                                        <div class="form-group">
                                                            <label>Hotel Name</label> 
                                                            <input name="name" placeholder="Enter Hotel" class="form-control" value="<?php
                                                            if (!isset($success) && set_value("name")) {
                                                                echo set_value("name");
                                                            }
                                                            ?>">
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('name')) {
                                                                    echo form_error("name");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="country">Country</label>
                                                                    <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                echo "selected";
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('country')) {
                                                                            echo form_error("country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  <label>State </label>
                                                                    <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                    echo set_select('state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('state')) {
                                                                            echo form_error("state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label>City </label>
                                                                    <select name="city" id="city" class="fancy-select form-control">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                    echo set_select('city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('city')) {
                                                                            echo form_error("city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label for="star">Star</label> 
                                                                <select class="form-control fancy-select" name="star" id="star">
                                                                    <option value="">Select Star</option>
                                                                    <?php
                                                                    for ($i = 1; $i <= 5; $i++) {
                                                                        ?>
                                                                        <option <?php
                                                                        if (!isset($success) && set_select("star", $i)) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>><?php echo $i; ?></option>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('star')) {
                                                                        echo form_error("star");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Contact No</label> 
                                                                <input type="text" name="contact" class="form-control" placeholder="Enter Contact Number" value="<?php
                                                                if (!isset($success) && set_value("contact")) {
                                                                    echo set_value("contact");
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('contact')) {
                                                                        echo form_error("contact");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-md-6 form-group">
                                                                <label>Website</label> 
                                                                <input  type="email" placeholder="Enter Hotel Website" name="website" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("website")) {
                                                                    echo set_value("website");
                                                                }
                                                                ?>">
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('website')) {
                                                                        echo form_error("website");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Price</label>
                                                                <p style="font-size: 9px;text-transform: capitalize;margin-bottom : 0px !important;display: inline-block;color: red;">* Per Room</p>
                                                                <input type="number" name="Price" placeholder="Enter Price" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("Price")) {
                                                                    echo set_value("Price");
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Price')) {
                                                                        echo form_error("Price");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Facility</label> 
                                                                <select class="form-control select2" name="Facility[]" multiple="" tabindex="-1" size="10">
                                                                    <?php
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_facility", "*", array("type" => "Hotel", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->facility_id ?>" <?php
                                                                        if (!isset($success) && set_select("Facility", $data->facility_id)) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>><?php echo $data->facility; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Facility[]')) {
                                                                        echo form_error("Facility[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Policy</label> 
                                                                <select class="form-control select2" name="policy[]" multiple="" tabindex="-1" size="10">
                                                                    <?php
                                                                    $precord = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $pagent = $precord[0]->agent_id;
                                                                    $precordset = $this->md->my_select("tbl_policy", "*", array("type" => "Hotel", "agent_id" => $agent));
                                                                    foreach ($precordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->policy_id; ?>" <?php
                                                                        if (!isset($success) && set_select("policy", $data->policy_id)) {
                                                                            echo "selected";
                                                                        }
                                                                        ?>><?php echo $data->policy; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('policy[]')) {
                                                                        echo form_error("policy[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Address</label> 
                                                                <textarea name="address" class="form-control" placeholder="Enter Hotel Address" rows="4"><?php
                                                                    if (!isset($success) && set_value("address")) {
                                                                        echo set_value("address");
                                                                    }
                                                                    ?></textarea>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('address')) {
                                                                        echo form_error("address");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Location</label> 
                                                                <textarea name="map" class="form-control" rows="4" placeholder="Enter Hotel Map Location"><?php
                                                                    if (!isset($success) && set_value("map")) {
                                                                        echo set_value("map");
                                                                    }
                                                                    ?></textarea>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('map')) {
                                                                        echo form_error("map");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Discription</label> 
                                                            <textarea name="disp" class="form-control" rows="5" placeholder="Enter Hotel Discription" ><?php
                                                                if (!isset($success) && set_value("disp")) {
                                                                    echo set_value("disp");
                                                                }
                                                                ?></textarea>
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('disp')) {
                                                                    echo form_error("disp");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Select Hotel photo</label> 
                                                            <input type="file" name="hotel_pic[]" class="form-control" accept='.jpg,.jpeg,.png' id="filePhoto" multiple="" />
                                                            <div class="preview"></div>  
                                                            <div class="error">
                                                                <p>
                                                                    <?php
                                                                    if (isset($p_error)) {
                                                                        echo $p_error;
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="">
                                                            <div class="input-field col s12" align="Right">
                                                                <button class="btn btn-primary" name="add" value="add">Add Hotel</button>
                                                                <button class="btn btn-default" type="reset" name="reset">Reset</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>  
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        } else {
                            $whe['location_id'] = $editdata[0]->location_id;
                            $city_detail = $this->md->my_select("tbl_location", "*", $whe);
                            $c = $this->md->my_select('tbl_location', '*', array('location_id' => $city_detail[0]->parent_id));
                            $cn = $c[0]->parent_id;
                            ?>
                            <div class="col-md-12">
                                <div class="box-inn-sp">
                                    <div class="inn-title">
                                        <h2>Add Hotel</h2>
                                    </div>
                                    <div class="tab-inn">
                                        <div class="panel-body">
                                            <div class="panel panel-card margin-b-30">
                                                <form method="post" action="" enctype="multipart/form-data" novalidate="">
                                                    <div class="form-group">
                                                        <!-- Start .panel -->
                                                        <div class="form-group">
                                                            <label>Hotel Name</label> 
                                                            <input name="name" placeholder="Enter Hotel" class="form-control" value="<?php
                                                            if (!isset($success) && set_value("name")) {
                                                                echo set_value("name");
                                                            } else {
                                                                echo $editdata[0]->hotel_name;
                                                            }
                                                            ?>">
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('name')) {
                                                                    echo form_error("name");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-md-4">  
                                                                    <label for="country">Country</label>
                                                                    <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                                        <option value="">Select Country</option>;
                                                                        <?php
                                                                        $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                                        foreach ($recordset as $data) {
                                                                            ?>
                                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                                echo "selected";
                                                                            } else {
                                                                                if ($data->location_id == $cn) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                            ?>><?php echo $data->name; ?></option>
                                                                                    <?php
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('country')) {
                                                                            echo form_error("country");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4"> 
                                                                    <label>State </label>
                                                                    <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                                        <option value="">Select State</option>
                                                                        <?php
                                                                        if ($this->input->post('country') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $this->input->post("country")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('state', $data->location_id)) {
                                                                                    echo set_select('state', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "state", 'parent_id' => $cn));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($city_detail[0]->parent_id == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('state')) {
                                                                            echo form_error("state");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="col-md-4">  
                                                                    <label>City </label>
                                                                    <select name="city" id="city" class="fancy-select form-control">
                                                                        <option value="">Select City</option>
                                                                        <?php
                                                                        if ($this->input->post('state') && !isset($success)) {
                                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $this->input->post("state")));
                                                                            foreach ($recordset as $data) {
                                                                                ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if (!isset($success) && set_select('city', $data->location_id)) {
                                                                                    echo set_select('city', $data->location_id);
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                } else {
                                                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "city", 'parent_id' => $c[0]->location_id));
                                                                                    foreach ($recordset as $data) {
                                                                                        ?>
                                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                                if ($editdata[0]->location_id == $data->location_id) {
                                                                                    echo "selected";
                                                                                }
                                                                                ?>><?php echo $data->name; ?></option>
                                                                                        <?php
                                                                                    }
                                                                                }
                                                                                ?>
                                                                    </select>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('city')) {
                                                                            echo form_error("city");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label for="star">Star</label> 
                                                                <select class="form-control fancy-select" name="star" id="star">
                                                                    <option value="">Select Star</option>
                                                                    <?php
                                                                    for ($i = 1; $i <= 5; $i++) {
                                                                        ?>
                                                                        <option <?php
                                                                        if (!isset($success) && set_select("star", $i)) {
                                                                            echo "selected";
                                                                        } else {
                                                                            if ($editdata[0]->star == $i) {
                                                                                echo "selected";
                                                                            }
                                                                        }
                                                                        ?>><?php echo $i; ?></option>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('star')) {
                                                                        echo form_error("star");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Contact No</label> 
                                                                <input type="text" name="contact" class="form-control" placeholder="Enter Contact Number" value="<?php
                                                                if (!isset($success) && set_value("contact")) {
                                                                    echo set_value("contact");
                                                                } else {
                                                                    echo $editdata[0]->contact;
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('contact')) {
                                                                        echo form_error("contact");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Website</label> 
                                                                <input  type="email" placeholder="Enter Hotel Website" name="website" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("website")) {
                                                                    echo set_value("website");
                                                                } else {
                                                                    echo $editdata[0]->website;
                                                                }
                                                                ?>">
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('website')) {
                                                                        echo form_error("website");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Price</label>
                                                                <p style="font-size: 9px;text-transform: capitalize;margin-bottom : 0px !important;display: inline-block;color: red;">* Per Person</p>
                                                                <input type="text" name="Price" placeholder="Enter Price" class="form-control" value="<?php
                                                                if (!isset($success) && set_value("Price")) {
                                                                    echo set_value("Price");
                                                                } else {
                                                                    echo $editdata[0]->price;
                                                                }
                                                                ?>"/>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Price')) {
                                                                        echo form_error("Price");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Facility</label> 
                                                                <select class="form-control select2" name="Facility[]" multiple="" tabindex="-1" size="10">
                                                                    <?php
                                                                    $record = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $agent = $record[0]->agent_id;
                                                                    $recordset = $this->md->my_select("tbl_facility", "*", array("type" => "hotel", "agent_id" => $agent));
                                                                    foreach ($recordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->facility_id ?>" <?php
                                                                        if (!isset($success) && set_select('Facility', $data->facility_id)) {
                                                                            echo set_select('Facility', $data->facility_id);
                                                                        } else {
                                                                            $facility = explode(',', $editdata[0]->facility);
                                                                            foreach ($facility as $f) {
                                                                                if ($data->facility_id == $f) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>><?php echo $data->facility; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('Facility[]')) {
                                                                        echo form_error("Facility[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Policy</label> 
                                                                <select class="form-control select2" name="policy[]" multiple="" tabindex="-1" size="10">
                                                                    <?php
                                                                    $precord = $this->md->my_select('tbl_agent', 'agent_id', $wh);
                                                                    $pagent = $precord[0]->agent_id;
                                                                    $precordset = $this->md->my_select("tbl_policy", "*", array("type" => "Hotel", "agent_id" => $agent));
                                                                    foreach ($precordset as $data) {
                                                                        ?>
                                                                        <option value="<?php echo $data->policy_id; ?>" <?php
                                                                        if (!isset($success) && set_select("policy", $data->policy_id)) {
                                                                            echo "selected";
                                                                        } else {
                                                                            $Policy = explode(',', $editdata[0]->policy);
                                                                            foreach ($Policy as $p) {
                                                                                if ($data->policy_id == $p) {
                                                                                    echo "selected";
                                                                                }
                                                                            }
                                                                        }
                                                                        ?>><?php echo $data->policy; ?></option>
                                                                                <?php
                                                                            }
                                                                            ?>  
                                                                </select>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('policy[]')) {
                                                                        echo form_error("policy[]");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="form-group col-md-6">
                                                                <label>Address</label> 
                                                                <textarea name="address" class="form-control" placeholder="Enter Hotel Address" rows="4"><?php
                                                                    if (!isset($success) && set_value("address")) {
                                                                        echo set_value("address");
                                                                    } else {
                                                                        echo $editdata[0]->address;
                                                                    }
                                                                    ?></textarea>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('address')) {
                                                                        echo form_error("address");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                            <div class="form-group col-md-6">
                                                                <label>Location</label> 
                                                                <textarea name="map" class="form-control" rows="4" placeholder="Enter Hotel Map Location"><?php
                                                                    if (!isset($success) && set_value("map")) {
                                                                        echo set_value("map");
                                                                    } else {
                                                                        echo $editdata[0]->iframe;
                                                                    }
                                                                    ?></textarea>
                                                                <div class="error">
                                                                    <?php
                                                                    if (form_error('map')) {
                                                                        echo form_error("map");
                                                                    }
                                                                    ?>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Discription</label> 
                                                            <textarea name="disp" class="form-control" rows="5" placeholder="Enter Hotel Discription" ><?php
                                                                if (!isset($success) && set_value("disp")) {
                                                                    echo set_value("disp");
                                                                } else {
                                                                    echo $editdata[0]->Discription;
                                                                }
                                                                ?></textarea>
                                                            <div class="error">
                                                                <?php
                                                                if (form_error('disp')) {
                                                                    echo form_error("disp");
                                                                }
                                                                ?>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Select Hotel photo</label> 
                                                            <input type="file" name="hotel_pic[]" class="form-control" accept='.jpg,.jpeg,.png' id="filePhoto" multiple="" />
                                                            <div class="preview"></div>  
                                                            <div class="error">
                                                                <p>
                                                                    <?php
                                                                    if (isset($p_error)) {
                                                                        echo $p_error;
                                                                    }
                                                                    ?>
                                                                </p>
                                                            </div>
                                                        </div>
                                                        <div class="">
                                                            <div class="input-field col s12" align="Right">
                                                                <button class="btn btn-primary" name="edit" value="update" type="submit">Edit Hotel</button>
                                                                <a href="<?php echo base_url('Manage_hotel'); ?>" class="btn btn-default">Cancel</a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>  
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                        ?>
                    </div>
                </div> 
            </div>
        </section>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
