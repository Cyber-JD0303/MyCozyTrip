<?php
if($view[0]->location_id !=0)
{
$whe['location_id'] = $view[0]->location_id;
$city_detail=$this->md->my_select("tbl_location", "*", $whe);
$c = $this->md->my_select('tbl_location','*',array('location_id'=>$city_detail[0]->parent_id));
$cn=$c[0]->parent_id;
}
else
{
    $cn=0;
}
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Edit Profile</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>
            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Edit Profile<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Edit Profile</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Edit Profile</h2>
                                </div>
                                <div class="tab-inn">
                                    <form method="post" action="" class="">
                                        <div class="panel-body">
                                            <!-- Start .panel -->
                                            <div class="form-group">
                                                <label>Name</label> 
                                                <input type="text" name="name" placeholder="Enter Company Name" autofocus="" check_control="alpha" class="form-control" value="<?php echo $view[0]->company_name; ?>"/>
                                                <div class="error">
                                                <?php
                                                if (form_error('name')) {
                                                    echo form_error("name");
                                                }
                                                ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Email</label> 
                                                <input type="email" name="email" check_control="email" class="form-control" readonly="" value="<?php echo $view[0]->email; ?>"/>
                                                <div class="error">
                                                <?php
                                                if (form_error('email')) {
                                                    echo form_error("email");
                                                }
                                                ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Contact No</label> 
                                                <input type="text" name="phone" check_control="number" class="form-control" readonly="" value="<?php echo $view[0]->phone; ?>"/>
                                                <div class="error">
                                                <?php
                                                    if (form_error('phone')) {
                                                        echo form_error("phone");
                                                    }
                                                ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>PinCode</label> 
                                                <input type="text" name="pincode" check_control="number" class="form-control" value="<?php echo $view[0]->pincode; ?>"/>
                                                <div class="error">
                                                <?php
                                                if (form_error('pincode')) {
                                                    echo form_error("pincode");
                                                }
                                                ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <div class="row">
                                                    <div class="col-md-4">  
                                                        <label for="country">Country</label>
                                                        <select name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                            <option>Select Country</option>
                                                            <?php
                                                            $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                            foreach ($recordset as $data) {
                                                                ?>
                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                            if (!isset($success) && set_select("country", $data->location_id)) {
                                                                echo "selected";
                                                            }
                                                            else 
                                                            {
                                                                if( $data->location_id == $cn )
                                                                {
                                                                    echo "selected";
                                                                }
                                                            }
                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                    ?>
                                                        </select>
                                                        <div class="error">
                                                        <?php
                                                        if (form_error('country')) {
                                                            echo form_error("country");
                                                        }
                                                        ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  <label>State </label>
                                                        <select name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                            <option value="">Select State</option>
                                                                <?php
                                                                    if( $this->input->post('country') && !isset($success) )
                                                                    {
                                                                        $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$this->input->post('country')));
                                                                        foreach ($recordset as $data)
                                                                        {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php

                                                                        if(!isset($success) && set_select('state', $data->location_id) )
                                                                        {
                                                                            echo set_select('state', $data->location_id);
                                                                        }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                        }
                                                                    }
                                                                    else
                                                                    {
                                                                        $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$cn));
                                                                        foreach ($recordset as $data)
                                                                        {
                                                                    ?>
                                                                    <option value="<?php echo $data->location_id ?>" <?php
                                                                       if($city_detail[0]->parent_id == $data->location_id)
                                                                       {
                                                                           echo "selected";
                                                                       }
                                                                    ?>><?php echo $data->name; ?></option>
                                                                    <?php
                                                                        }
                                                                    }
                                                                ?>
                                                        </select>
                                                        <div class="error">
                                                        <?php
                                                        if (form_error('state')) {
                                                            echo form_error("state");
                                                        }
                                                        ?>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">  <label>City </label>
                                                        <select name="city" id="city" class="fancy-select form-control">
                                                            <option>Select City</option>
                                                            <?php
                                                                if( $this->input->post('state') && !isset($success) )
                                                                {
                                                                    $recordset = $this->md->my_select("tbl_location","*",array("label"=>"city",'parent_id'=>$this->input->post('state')));
                                                                    foreach ($recordset as $data)
                                                                    {
                                                                ?>
                                                                <option value="<?php echo $data->location_id ?>" <?php

                                                                    if(!isset($success) && set_select('city', $data->location_id) )
                                                                    {
                                                                        echo set_select('city', $data->location_id);
                                                                    }
                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                }
                                                                else
                                                                {
                                                                    $recordset = $this->md->my_select("tbl_location","*",array("label"=>"city",'parent_id'=>$c[0]->location_id));
                                                                    foreach ($recordset as $data)
                                                                    {
                                                                ?>
                                                                <option value="<?php echo $data->location_id ?>" <?php
                                                                   if($view[0]->location_id == $data->location_id)
                                                                   {
                                                                       echo "selected";
                                                                   }
                                                                ?>><?php echo $data->name; ?></option>
                                                                <?php
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('city')) {
                                                                echo form_error("city");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Address</label> 
                                                <textarea name="address" class="form-control" rows="5"><?php echo $view[0]->address; ?></textarea>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('address')) {
                                                        echo form_error("address");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="input-field col s12" align="Right">
                                                <button class="btn btn-primary" name="add" value="add">Edit Profile</button>
                                                <button class="btn btn-default" type="reset" name="reset">Reset</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <form method="post" action="" class="" enctype="multipart/form-data">
                                    <div class="inn-title">
                                        <h2>Edit Profile Photo</h2>
                                    </div>
                                    <div class="tab-inn">
                                        <div class="panel-body">
                                            <div>
                                                <h3 align="">Profile picture</h3>
                                                <img src="<?php echo base_url(); ?><?php echo $view[0]->profile_pic; ?>" id="previewHolder" alt="<?php echo $view[0]->company_name; ?>" style="width:150px; height:180px;  border-radius: 5px; box-shadow: 0 8px 4px 0 rgba(0, 0, 0, 0.2), 0 4px 8px 0 rgba(0, 0, 0, 0.20) ">
                                                <h3 align="" style="padding-top: 10px;"><?php echo $view[0]->company_name; ?></h3>
                                            </div>
                                            <div class="form-group">
                                                <label>Select a file </label> 
                                                <input type="file" name="profile_image" data-errormsg="PhotoUploadErrorMsg" id="filePhoto" class="form-control">
                                            </div>
                                            <div class="input-field col s12" align="right">
                                                <button class="btn btn-primary" type="submit" name="upload" value="upload">Upload Profile Photo</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($p_error)) {
            ?>
            <div class="my_alert animated bounceInRight photoerror">
                <span class="fa fa-exclamation-triangle"></span> <?php echo $p_error; ?>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
