<link href="<?php echo base_url(); ?>Agent_Assets/images/favicon.png" rel="shortcut icon"/>
<link href="<?php echo base_url(); ?>Agent_Assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/css/waves.min.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/css/nanoscroller.css" rel="stylesheet" >
<link href="<?php echo base_url(); ?>Agent_Assets/images/fav.png" rel="shortcut icon" />
<link href="<?php echo base_url(); ?>Agent_Assets/css/morris-0.4.3.min.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/css/menu-light.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/css/style.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/css/Mystyle.css" type="text/css" rel="stylesheet">
<link href="<?php echo base_url(); ?>Agent_Assets/font-awesome/css/font-awesome.min.css" rel="stylesheet">
<script src="<?php echo base_url(); ?>Admin_Assets/js/ckeditor/ckeditor.js" type="text/javascript"></script>
    