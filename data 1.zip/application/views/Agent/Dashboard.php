<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Agent - Home</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Dashboard <small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="#"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Dashboard</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Manage_place'); ?>">
                                <div class="widget-box clearfix">
                                    <div class="pull-left">
                                        <h4>Manage Place</h4>
                                        <h2><?php echo $Place; ?><i class="fa fa-university" style="padding-left: 150px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Agent_Facility'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Facility</h4>
                                        <h2><?php echo $Facility; ?><i class="glyphicon glyphicon-equalizer" style="padding-left: 160px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Agent_policy'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Policy</h4>
                                        <h2><?php echo $Policy; ?><i class="glyphicon glyphicon-list-alt" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Agent_Booking'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Package Booking</h4>
                                        <h2><?php echo $Booking; ?><i class="glyphicon glyphicon-book" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Hotel_Booking'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Hotel Booking</h4>
                                        <h2><?php echo $h_Booking; ?><i class="glyphicon glyphicon-book" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('View_Package'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Manage Package</h4>
                                        <h2><?php echo $Packages; ?><i class="glyphicon glyphicon-file" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Active_Review'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Active Review</h4>
                                        <h2><?php echo $A_review; ?><i class="glyphicon glyphicon-thumbs-up" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Deactive_Review'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Deactive Review</h4>
                                        <h2><?php echo $D_review; ?><i class="glyphicon glyphicon-thumbs-down" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="<?php echo base_url('Manage_hotel'); ?>">
                                <div class="widget-box clearfix">
                                    <div>
                                        <h4>Manage Hotel</h4>
                                        <h2><?php echo $Hotel; ?><i class="glyphicon glyphicon-user" style="padding-left: 165px;"></i></h2>
                                    </div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
