<?php
	ini_set('display_errors', 0);
?>
<!-- Static navbar -->

<nav class="navbar navbar-default yamm navbar-fixed-top" style="background: #f58634 !important;">
            <div class="container-fluid">
                <button type="button" class="navbar-minimalize minimalize-styl-2  pull-left "><i class="fa fa-bars"></i></button>
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span> 
                    </button>
                    <a class="navbar-brand" href="#"><label>My Cozy Trip</label></a>
                </div>
                <!--/.nav-collapse -->
            </div><!--/.container-fluid -->
        </nav>
        