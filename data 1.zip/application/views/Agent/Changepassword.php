<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Change Password</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Change Password<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Change Password</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-offset-md-1 col-md-7">
                            <div class="panel panel-card recent-activites">
                                <div class="inn-title">
                                    <h2 align="center">Change Password</h2>
                                </div>
                                <form method="post" action="" class="" name="changepassword">
                                    <div class="form-group">
                                        <label>Old Password :</label>
                                        <input type="password" name="old_pass" placeholder="Old Password" class="form-control" id="password-field" value="<?Php
                                        if (!isset($success) && set_value('old_pass')) {
                                            echo set_value("old_pass");
                                        }
                                        ?>"/>
                                        <i class="fa fa-eye-slash field-icon toggle-password"  toggle="#password-field"></i>
                                        <div class="error">
                                            <?php
                                            if (form_error('old_pass')) {
                                                echo form_error("old_pass");
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>New Password :</label>
                                        <input type="password" name="new_pass" placeholder="New Password" class="form-control" id="password-field1" value="<?Php
                                        if (!isset($success) && set_value('new_pass')) {
                                            echo set_value("new_pass");
                                        }
                                        ?>"/>
                                        <i class="fa fa-eye-slash field-icon toggle-password"  toggle="#password-field1"></i>
                                        <div class="error">
                                            <?php
                                            if (form_error('new_pass')) {
                                                echo form_error("new_pass");
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <label>Confirm Password :</label>
                                        <input type="password" name="confirm_pass" placeholder="Confirm Password" class="form-control" id="password-field2" value="<?Php
                                        if (!isset($success) && set_value('confirm_pass')) {
                                            echo set_value("confirm_pass");
                                        }
                                        ?>"/>
                                        <i class="fa fa-eye-slash field-icon toggle-password" toggle="#password-field2"></i>
                                        <div class="error">
                                            <?php
                                            if (form_error('confirm_pass')) {
                                                echo form_error("confirm_pass");
                                            }
                                            ?>
                                        </div>
                                    </div>
                                    <button type="submit" value="Change_password" class="btn btn-primary" name="update">Change Password</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>