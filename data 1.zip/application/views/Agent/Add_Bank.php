<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Add Bank Details</title>
        <?php
        $this->load->view('Agent/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('Agent/Header');
        ?>
        <section class="page">
            <?php
            $this->load->view('Agent/Menu');
            ?>

            <div id="wrapper">
                <div class="content-wrapper container">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="page-title">
                                <h1>Add Bank<small></small></h1>
                                <ol class="breadcrumb">
                                    <li><a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-home"></i></a></li>
                                    <li class="active">Add Bank</li>
                                </ol>
                            </div>
                        </div>
                    </div> 
                    <!--end .page title-->
                    <div class="row">
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>Add Coverage Bank</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <form class="" method="post" action="">
                                            <!-- Start .panel -->
                                            <div class="form-group">
                                                <label>Account Holder Name</label> 
                                                <input type="text" name="name" placeholder="Enter Company Name" autofocus="" check_control="alpha" class="form-control" value="<?php
                                                if (!isset($success) && set_value('name')) {
                                                    echo set_value("name");
                                                }
                                                ?>"/>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('name')) {
                                                        echo form_error("name");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Bank Name</label> 
                                                <input type="text" name="bank" placeholder="Enter Bank Name" check_control="alpha" class="form-control" value="<?php
                                                if (!isset($success) && set_value('bank')) {
                                                    echo set_value("bank");
                                                }
                                                ?>"/>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('bank')) {
                                                        echo form_error("bank");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Branch Name</label> 
                                                <input type="text" name="branch" placeholder="Enter Branch Name" check_control="alpha" class="form-control" value="<?php
                                                if (!isset($success) && set_value('branch')) {
                                                    echo set_value("branch");
                                                }
                                                ?>"/>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('branch')) {
                                                        echo form_error("branch");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Bank IFSC</label> 
                                                <input type="text" name="ifsc" placeholder="Enter Bank IFSC Code" check_control="" class="form-control" value="<?php
                                                if (!isset($success) && set_value('ifsc')) {
                                                    echo set_value("ifsc");
                                                }
                                                ?>"/>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('ifsc')) {
                                                        echo form_error("ifsc");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Account Number</label> 
                                                <input type="text" name="Account" placeholder="Enter Account Number" check_control="number" class="form-control" value="<?php
                                                if (!isset($success) && set_value('Account')) {
                                                    echo set_value("Account");
                                                }
                                                ?>"/>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('Account')) {
                                                        echo form_error("Account");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="input-field col s12" align="right">
                                                <button class="btn btn-primary" name="add" value="add" type="submit">Add Bank</button>
                                                <button class="btn btn-default" type="reset" name="reset">Reset</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="box-inn-sp">
                                <div class="inn-title">
                                    <h2>View Bank</h2>
                                </div>
                                <div class="tab-inn">
                                    <div class="panel-body">
                                        <table id="example" class="table table-striped">
                                            <thead>
                                                <tr>
                                                    <th>NO</th>
                                                    <th>Name</th>
                                                    <th>Bank Name</th>
                                                    <th>Branch Name</th>
                                                    <th>Bank IFSC</th>
                                                    <th>Account Number</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $c = 0;
                                                foreach ($view as $data) {
                                                    $c++;
                                                    ?>
                                                <td><?php echo $c; ?></td>
                                                <td><?php echo $data->bank_benificiary_name; ?></td>
                                                <td><?php echo $data->bank_name; ?></td>
                                                <td><?php echo $data->branch_name; ?></td>
                                                <td><?php echo $data->IFSC_code; ?></td>
                                                <td><?php echo $data->AC_no; ?></td>    
                                                <?php
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Peta Category</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Delete ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:0px 40px; ">Cancel</a>
                        <a id="Bank-del" class="btn  btn-hover-shine" style="padding:0px 25px;background-color: #b30000;color: white;">Yes,Delete it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><?php echo $success; ?></b>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><?php echo $error; ?>,</b>
                </p>
            </div>
            <?php
        }
        ?>
        <?php
        $this->load->view('Agent/Footer_Script');
        ?>
    </body>
</html>
