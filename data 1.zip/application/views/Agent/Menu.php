<?php
    $wh['email'] = $this->session->userdata('agent');
    $record=$this->md->my_select('tbl_agent','*',$wh);
?>
<nav class="navbar-aside navbar-static-side" role="navigation">
    <div class="sidebar-collapse nano">
        <div class="nano-content">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                    <div class="dropdown side-profile text-left"> 
                        <span style="display: block;">
                            <img alt="image" class="img-circle" src="<?php echo base_url(); ?><?php echo $record[0]->profile_pic; ?>" width="60" >
                        </span>

                        <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear" style="display: block;"> <span class="block m-t-xs"><strong class="font-bold">Wellcome <?php echo $record[0]->company_name; ?><b class="caret"></b></strong></span></span>
                            <ul class="dropdown-menu animated fadeInRight m-t-xs">
                                <li><a href="<?php echo base_url('Agent_Profile'); ?>"><i class="fa fa-user"></i>Edit Profile</a></li>
                                <li><a href="<?php echo base_url('Agent_Changepassword'); ?>"><i class="glyphicon glyphicon-refresh"></i>Change Password</a></li>                         
                                <li class="divider"></li>
                                <li><a href="<?php echo base_url('Agent_Logout'); ?>"><i class="fa fa-key"></i>Logout</a></li>
                            </ul>
                        </a>
                    </div>
                </li>
                <li>
                    <a href="<?php echo base_url('Agent_Home'); ?>"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard </span></a>
                </li>
                <li>
                    <a href="<?php echo base_url('Manage_place'); ?>"><i class="fa fa-university"></i><span class="nav-label">Manage Place</span></a>
                </li>
                <li>
                    <a href="<?php echo base_url('Agent_Facility'); ?>"><i class="glyphicon glyphicon-equalizer"></i><span class="nav-label">Facility</span></a>
                </li>

                <li>
                    <a href="<?php echo base_url('Agent_policy'); ?>"><i class="glyphicon glyphicon-list-alt"></i><span class="nav-label">Policy</span></a>
                </li>
                <li>
                    <a href=""><i class="fa fa-hotel"></i><span class="nav-label">Hotel</span><span class="fa arrow"></span> </a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="<?php echo base_url('Add_hotel'); ?>"><i class="glyphicon glyphicon-pencil"></i>Add Hotel</a></li>
                        <li><a href="<?php echo base_url('Manage_hotel'); ?>"><i class="glyphicon glyphicon-user"></i>manage hotel</a></li>
                    </ul>
                </li>
                <li>
                    <a><i class="glyphicon glyphicon-user"></i><span class="nav-label">Manage Package</span><span class="fa arrow"></span> </a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="<?php echo base_url('Add_Package'); ?>"><i class="glyphicon glyphicon-pencil"></i>Add Package</a></li>
                        <li><a href="<?php echo base_url('View_Package'); ?>"><i class="glyphicon glyphicon-file"></i>View Package</a></li>
                    </ul>
                </li>
                <li>
                    <a href=""><i class="glyphicon glyphicon-check"></i><span class="nav-label">Review</span><span class="fa arrow"></span> </a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="<?php echo base_url('Active_Review'); ?>"><i class="glyphicon glyphicon-thumbs-up"></i>Active Review</a></li>
                        <li><a href="<?php echo base_url('Deactive_Review'); ?>"><i class="glyphicon glyphicon-thumbs-down"></i>Deactive Review</a></li>
                    </ul>
                </li>
                <li>
                    <a><i class="glyphicon glyphicon-book"></i><span class="nav-label">Booking</span><span class="fa arrow"></span> </a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="<?php echo base_url('Agent_Booking'); ?>"><i class="glyphicon glyphicon-bookmark"></i><span class="nav-label">Package Book</span></a></li>
                        <li><a href="<?php echo base_url('Hotel_Booking'); ?>"><i class="glyphicon glyphicon-bookmark"></i>Hotel Book</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo base_url(''); ?>"><i class="glyphicon glyphicon-cog"></i><span class="nav-label">Setting</span><span class="fa arrow"></span> </a>
                    <ul class="nav nav-second-level collapse">
                        <li><a href="<?php echo base_url('Agent_Profile'); ?>"><i class="fa fa-user"></i>Edit Profile</a></li>
                        <li><a href="<?php echo base_url('Add_bank'); ?>"><i class="fa fa-university"></i>Add Bank</a></li>
                        <li><a href="<?php echo base_url('Agent_Changepassword'); ?>"><i class="glyphicon glyphicon-refresh"></i>Change Password</a></li>
                    </ul>
                </li>
                <li>
                    <a href="<?php echo base_url('Agent_Logout'); ?>"><i class="fa fa-power-off"></i><span class="nav-label">Log Out</span></a>
                </li>
            </ul>
        </div>
    </div>
</nav>
