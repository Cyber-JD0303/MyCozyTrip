﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - FAQ</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body onload="initialize()">

        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <a href="FAQ.php"></a>
        <!--- //loading animation -->

        <?php
        $this->load->view('User/Header');
        ?>


        <!--main-->

        <main class="main">
        </br>   
        <div class="wrap">   
            <nav class="breadcrumbs">
                <!--crumbs-->
                <ul>
                    <li><a href="#" title="Home">Home</a></li> 
                    <li>FAQ</li>                                       
                </ul>
                <!--//crumbs-->
            </nav>
        </div>

        <br />

         <div class="panel-group container faqs_marg" id="accordion" role="tablist" aria-multiselectable="true">
                   <br />  <h2 class="text-left">Frquently Asked Questions</h2>
     
            <div class="panel panel-default">
                
                <div class="panel-heading" role="tab" id="headingOne">
                    <h4  class="panel-title faqs_title collaps text-left" id="icon">
                        <p role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> 
                            Q.1: How do I make a flight booking on My Cozy Trip? 
                        </p>   
                    </h4>
                </div>

                <div id="collapseOne" class="panel-collapse collapse text-left" role="tabpanel" aria-labelledby="headingOne">
                    <div class="panel-body faqs_body ">
                        <b> Ans : </b>You can book a flight ticket onMy Cozy Trip in three easy steps: Download the My Cozy Trip app on your mobile phone. Enter your air travel details i.e. date of journey, destinations and travel class you wish to avail, and then choose flights from the list as per your convenience.           </div>
                </div>
            </div>
            <br />
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingTwo">
                    <h4 class="panel-title faqs_title text-left">
                        <p role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                            Q.2:How can I avail cheap air tickets on My Cozy Trip?
                        </p>
                    </h4>
                </div>
                <div id="collapseTwo" class="panel-collapse collapse text-left" role="tabpanel" aria-labelledby="headingTwo">
                    <div class="panel-body faqs_body">
                        <b> Ans : </b>Go to the ‘Price’ filter on the My Cozy Trip app when the flight options crop up on your screen. Then select the downward arrow which will then show the lowest airfares towards the top, thus facilitating cheap flight booking.               </div>
                </div>
            </div>
            <br />

            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingThree">
                    <h4 class="panel-title faqs_title text-left">
                        <p role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                            Q.3:elected the cheap flights on My Cozy Trip, however, I find other sites offering even cheaper rates on air ticket booking. Why can’t I avail the same airfare on My Cozy Trip?
                        </p>
                    </h4>
                </div>
                <div id="collapseThree" class="panel-collapse collapse text-left" role="tabpanel" aria-labelledby="headingThree">
                    <div class="panel-body faqs_body">
                        <b> Ans : </b> This can occur due to multiple reasons. Airlines generally have a limited number of air tickets which can be sold at a discounted fare. It is possible that the quota was over by the time you accessed the system. Also, most cheap flight tickets carry specific travel restrictions which might have not fit with your selected criteria, hence were trimmed out. Airlines keep updating the flight tickets prices in real-time, which might be another reason for the change in flight ticket offers.               </div>
                </div>
            </div>
            <br />
                <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingFour">
                    <h4 class="panel-title faqs_title text-left">
                        <p role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
                            Q.4: Why could I not avail the flight booking offers at the time of checkout?
                        </p>
                    </h4>
                </div>
                <div id="collapseFour" class="panel-collapse collapse text-left" role="tabpanel" aria-labelledby="headingFour">
                    <div class="panel-body faqs_body">
                        <b> Ans : </b>MakeMyTrip uses a real-time reservation database used worldwide to list flight tickets prices and availability. As airline tickets are sold or fares are changed dynamically, the flight ticket booking database gets updated to immediately reflect those changes. Hence, always make sure to double-check online flight booking prices when purchasing plane tickets, as the airfare may have changed since you first searched for fares or created your itinerary.                  </div>
                </div>
            </div>
<br />
            <div class="panel panel-default">
                <div class="panel-heading" role="tab" id="headingFive">
                    <h4 class="panel-title faqs_titlet ext-left text-left">
                        <p role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
                            Q.5 :Can I avail domestic flight offers on MakeMyTrip?
                        </p>
                    </h4>
                </div>
                <div id="collapseFive" class="panel-collapse collapse text-left" role="tabpanel" aria-labelledby="headingFive">
                    <div class="panel-body faqs_body">
                        <b> Ans : </b>Yes, you can. While booking domestic flights, you can avail any special offer that is active at that time. Accordingly, a flight menu would come up, from where you have to select the price filter in downward direction, and the cheapest flights availing that specific offer would be displayed at the top.
                    </div>
                </div>
            </div>

            
        </div>


</main>


        <!--//main-->
        <?php
        $this->load->view('User/Footer');
        $this->load->view('User/Footer_Script');
        ?>
    </body>

</html>