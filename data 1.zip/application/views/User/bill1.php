<?php
$package = $this->md->my_select('tbl_trip_package', '*', array('package_id' => $view[0]->package_id));
$agent = $this->md->my_select('tbl_agent', '*', array('agent_id' => $package[0]->agent_id));
$f_city = $this->md->my_select('tbl_location', '*', array('location_id' => $package[0]->From_location));
$t_city = $this->md->my_select('tbl_location', '*', array('location_id' => $package[0]->To_location));
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Package Invoice</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('User/Header');
        ?>
        <main class="main" >
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>My Account</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <div class="col-md-5">
                        <h3 class="text-left">My Account</h3>
                    </div>
                    <div class="col-md-7">
                        <input type='button' class="gradient-button right print" id='btn' value='Print' onclick='printDiv();'>
                    </div>
                    <!--three-col content-->
                    <section class="three-col">
                        <!--inner navigation-->
                        <?php
                        $this->load->view('User/Profile_menu');
                        ?>

                        <!--//inner navigation-->
                        <!--Contain-->

                        <section id="" class="tab-content">
                            <article class="myreviews">
                                <div id="DivIdToPrint">
                                    <div class="row" style="margin : 0px !important;">
                                        <div class="col-md-6">
                                            <div class="logo">
                                                <a href="" title="Book Your Travel">
                                                    <img src="<?php echo base_url(); ?>Assets/images/txt/logo.png" alt="Book Your Travel" />
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="contact"  >
                                                <p class="" style="padding: 15px; ">
                                                    <span  style="padding-left: 30px;">24/7 Support number</span>
                                                    <span  style="padding-left: 30px;" class="number"><a style="color: #A58585 !important;">+91 8980776898</a></span>
                                                </p>
                                            </div>
                                            <!--//contact-->

                                            <!--Email-->
                                            <div class="contact"> 
                                                <p class="" style="padding: 15px;  ">
                                                    <span style="padding-left: 30px;">Email</span>
                                                    <span style="padding-left: 30px; color: #B8ADA8 !important;"><a style="color: #A58585 !important;">mycozytrip@gmail.com</a></span>
                                                </p>
                                            </div>
                                        </div>
                                        <hr/> 
                                        <div align="right">
                                            <h1 style="margin-bottom: 20px !important;padding : 20px 0 20px 0 !important;font-weight: bolder"><font style="color: #0277b7;">TOURS AND</font> TRAVEL INVOICE</h1>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-5">
                                                <table width="100%" border="1" class="table table-striped">
                                                    <tr>
                                                        <td class="heder" style="background-color: #0277b7;color: #fff;" colspan="2">
                                                            <div align="center">
                                                                <strong style="font-size: 25px;">TO</strong>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr style="border: none;">
                                                        <td style="text-align: center;" colspan="2"><h3 style="font-size: 20px;margin-top: 10px !important;  "><?php echo $agent[0]->company_name; ?></h3></td>
                                                    </tr>
                                                    <tr style="border: none;">
                                                        <th colspan="2" >A : 
                                                            <p style="display: inline-block"><?php echo $agent[0]->address; ?></p>
                                                        </th>
                                                    </tr>
                                                    <tr style="border: none;">
                                                        <th>P : 
                                                            <p style="display: inline-block"><?php echo $agent[0]->phone; ?></p>
                                                        </th>
                                                        <th>M : <p style="display: inline-block"><?php echo $agent[0]->email; ?></p></th>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-3">
                                                <table width="50%" border="1">
                                                    <tr>
                                                        <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>DATE</strong></div></td>
                                                    </tr>
                                                    <tr>
                                                        <td> 
                                                            <div style="margin: 5px !important; text-align: center;"><center><h3 style=" font-size: 30px !important;"><?php echo date('d/M/Y', strtotime($view[0]->booked_date)); ?></h3></center></div> 
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                            <div class="col-md-3" style="padding-left: 25px !important;">
                                                <table width="50%" border="1">
                                                    <tr>
                                                        <td  class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>INVOICE</strong></div></td>
                                                    </tr>
                                                    <tr>
                                                        <td>
                                                            <div style="margin: 5px !important; text-align: center;"><center><h3 style=" font-size: 30px !important;"><?php echo $view[0]->booking_id; ?></h3></center></div> 
                                                        </td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <div>
                                            <h3><p style="text-align: center;margin-bottom: 20px;"><font style="color: #0277b7;font-weight: bold;">Travel</font> Details</p></h3>
                                        </div>
                                        <table width="100%" border="1" class="table table-striped">
                                            <tr>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Source-Destination</strong></div></td>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Travelling Date </strong></div></td>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>No.of Travelers </strong></div></td>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Charges</strong></div></td>
                                            </tr>
                                            <tr>
                                                <td align="center"><?php echo $f_city[0]->name; ?> - <?php echo $t_city[0]->name; ?></td>
                                                <td align="center"><?php echo date('d/M/Y', strtotime($view[0]->booked_date)); ?></td>
                                                <td><div align="center"><?php echo $view[0]->person; ?></div></td>
                                                <td><div align="center" style="color: #0277b7; font-weight: bold;">&#8377; <?php echo $package[0]->price; ?></div></td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2" rowspan="2"></td>
                                                <td style="font-weight: bold;color: #666; padding-left: 20px;">Sub Total</td>
                                                <td>
                                                    <div align="" style="color: #0277b7; font-weight: bold;">
                                                        <table>
                                                            <tr>
                                                                <td><p style="float : right; display: inline-block;">&#8377; <?php echo $package[0]->price; ?> </p></td>
                                                            </tr>
                                                            <tr>
                                                                <td> * <p style="float : right; display: inline-block;"><?php echo $view[0]->person; ?> </p></td>
                                                            </tr>
                                                            <tr>
                                                                <td>= <p style="float : right; display: inline-block;">&#8377; <?php echo $view[0]->amount; ?> </p></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td style="font-weight: bold;color: #666; padding-left: 20px;">Tax <p style="display: inline-block;float: right;padding-right: 20px;margin: 0px 0px 5px !important;color: #0277b7;">8.5%</p></td>
                                                <td><div align="center" style="color: #0277b7; font-weight: bold;">&#8377; 00</div></td>
                                            </tr>
                                            <tr>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;font-weight: bold;text-align: center">Payment Method</td>
                                                <td></td>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;font-weight: bold;"><div align="center">Total Charges </div></td>
                                                <td style="color: #fff; font-weight: bold;background-color: #3b3b1f;"><div align="center">&#8377; <?php echo $view[0]->amount; ?></div></td>
                                            </tr>
                                        </table>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <table width="30%" class="table table-striped">
                                                    <tr>
                                                        <th>Bank name </th>
                                                        <td>:&nbsp;&nbsp; Your Bank Name </td>
                                                    </tr>
                                                    <tr>
                                                        <th>Account No </th>
                                                        <td>:&nbsp;&nbsp; 33658224</td>
                                                    </tr>
                                                    <tr>
                                                        <th>IFSC Code </th>
                                                        <td>:&nbsp;&nbsp; RJF0214517</td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <hr align="right" width="15%"  style="size:30%;"/>
                                        <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
                                        <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
                                        <table border="1" style="width: 100%;" class="table table-striped">
                                            <tr>
                                                <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong><span style="color: #FFFFFF">T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
                                            </tr>
                                            <tr>
                                                <td bgcolor="#333333"> 
                                                    <div class="row" style="color: #777;font-weight: bold;">
                                                        <span class="col-md-4" style="text-align: left;">   <b style="color:black"> A: &nbsp;</b> <p style="display: inline;"><?php echo $agent[0]->address; ?></p></span>
                                                        <span class="col-md-4" style="text-align: center;"> <b style="color:black"> P: &nbsp;</b> <p style="display: inline"><?php echo $agent[0]->phone; ?></p></span>
                                                        <span class="col-md-4" style="text-align: right;">  <b style="color:black"> E: &nbsp;</b> <p style="display: inline"><?php echo $agent[0]->email; ?></p></span>
                                                    </div>
                                                </td>
                                            </tr>
                                        </table>    
                                    </div>
                                </div>
                            </article>
                        </section>
                    </section>
                </div>
            </div>
        </main>
        <script src="<?php echo base_url(); ?>Assets/js/jquery-3.4.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script>
            function printDiv()
            {
                var contents = $("#DivIdToPrint").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({"position": "absolute", "top": "-1000000px"});
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>Package Booking Invoice</title>');
                //Append the external CSS file.
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/mycss.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/theme-turqoise.css" id="template-color" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/lightslider.min.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styler.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');
                frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>');
                //Append the DIV contents.
                frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();

                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 500);
            }
        </script>

        <?php
        $this->load->view('User/Footer');
        ?>
    </body>
</html>
