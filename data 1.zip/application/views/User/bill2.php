<?php
$hotel = $this->md->my_select('tbl_hotel', '*', array('hotel_id' => $view[0]->hotel_id));
$agent = $this->md->my_select('tbl_agent', '*', array('agent_id' => $hotel[0]->agent_id));
$user = $this->md->my_select('tbl_register', '*', array('Rid' => $view[0]->Rid));
$city = $this->md->my_select('tbl_location', '*', array('location_id' => $user[0]->location_id));
?>
<!DOCTYPE html>
<html>
    <head>
        <link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css"/>
        <link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>
        <link rel="shortcut icon" href="<?php echo base_url(); ?>Assets/images/favicon.png" />
        <title>Hotel Invoice</title>
        <style type="text/css">
            .style4 {
                color: #FFFFFF;
                background: #666;
                text-align: center;
                padding: 10px;
            }
        </style>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('User/Header');
        ?>
        <main class="main" >
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>My Account</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <div class="col-md-5">
                        <h3 class="text-left">My Account</h3>
                    </div>
                    <div class="col-md-7">
                        <input type='button' class="gradient-button right print" id='btn' value='Print' onclick='printDiv();'>
                    </div>
                    <!--three-col content-->
                    <section class="three-col">
                        <!--inner navigation-->
                        <?php
                        $this->load->view('User/Profile_menu');
                        ?>

                        <!--//inner navigation-->
                        <!--Contain-->

                        <section id="" class="tab-content">
                            <article class="myreviews">
                                <div id="DivIdToPrint">
                                    <div class="row" style="margin : 0px !important;">
                                        <div class="col-md-8">
                                            <span>
                                                <h1><label><?php echo $hotel[0]->hotel_name; ?></label></h1>
                                            </span>
                                            <div align="left">
                                                <?php echo $hotel[0]->address; ?><br />
                                                <?php echo $hotel[0]->contact; ?><br />
                                                <?php echo $hotel[0]->website; ?><br />
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div align="right" style="margin-top: 20px;margin-bottom: 10px;">
                                                <h3><label style="background: #777;color: #fff;padding: 20px;text-transform: uppercase;">Hotel Invoice</label></h3>
                                                <table width="50%" align="right">
                                                    <tr>
                                                        <td>Invoice No </td>
                                                        <td> : <?php echo $view[0]->booking_id; ?></td>
                                                    </tr>
                                                    <tr>
                                                        <td>Date </td>
                                                        <td> : <?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>    
                                    </div>
                                    <hr/>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <table width="100%" class="table table-striped">
                                                <tr>
                                                    <th colspan="2"><h2 align="center">Bill To </h2> </th>
                                                </tr>
                                                <tr>
                                                    <td>Name</td>
                                                    <td class="border"><?php echo $user[0]->name; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>City</td>
                                                    <td class="border"><?php echo $city[0]->name; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Phone NO</td>
                                                    <td class="border"><?php echo $user[0]->phone; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>email</td>
                                                    <td class="border"><?php echo $user[0]->email; ?></td>
                                                </tr>
                                                <tr>
                                                    <td></td>
                                                    <td class="border">&nbsp;</td>
                                                </tr>
                                                <tr>
                                                    <td></td>
                                                    <td class="border">&nbsp;</td>
                                                </tr>
                                            </table>
                                        </div>
                                        <div class="col-md-6">
                                            <table width="100%" class="table table-striped">
                                                <tr>
                                                    <th colspan="2"><h2 align="center">Other Information</h2> </th>
                                                </tr>
                                                <tr>
                                                    <td>Check In Date </td>
                                                    <td class="border"><?php echo date('d/M/Y', strtotime($view[0]->checking_date)); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Check Out Date </td>
                                                    <td class="border"><?php echo date('d/M/Y', strtotime($view[0]->checkout_date)); ?></td>
                                                </tr>
                                                <tr>
                                                    <td>No Of days</td>
                                                    <td class="border"><?php echo $view[0]->numberday; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>Rate Par Day</td>
                                                    <td class="border">&#8377; <?php echo $hotel[0]->price; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>No of Person</td>
                                                    <td class="border"><?php echo $view[0]->person; ?></td>
                                                </tr>
                                                <tr>
                                                    <td>No Of Room  </td>
                                                    <td class="border"><?php echo $view[0]->Room; ?></td>
                                                </tr>
                                            </table>
                                        </div>
                                    </div>
                                    <div style="padding-top: 20px;">
                                        <table width="100%" border="1" class="table table-striped">
                                            <tr>
                                                <th class="style4">Sales Rep. Name</th>
                                                <th class="style4">Address</th>
                                                <th class="style4">pincode</th>
                                                <th class="style4">Due Date</th>
                                            </tr>
                                            <tr>
                                                <td><?php echo $agent[0]->company_name; ?></td>
                                                <td><?php echo $agent[0]->address; ?></td>
                                                <td><?php echo $agent[0]->pincode; ?></td>
                                                <td><?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <div style="padding-top: 20px;">
                                        <table width="100%" border="1" class="table table-striped">
                                            <tr>
                                                <th class="style4">No Of Room</th>
                                                <th class="style4">Name</th>
                                                <th class="style4">Check In Date</th>
                                                <th class="style4">Check out Date</th>
                                                <th class="style4">AMOUNT</th>
                                                <th class="style4">TOTAL</th>
                                            </tr>
                                            <tr>
                                                <td><?php echo $view[0]->Room; ?></td>
                                                <td><?php echo $user[0]->name; ?></td>
                                                <td><?php echo date('d/M/Y', strtotime($view[0]->checking_date)); ?></td>
                                                <td><?php echo date('d/M/Y', strtotime($view[0]->checkout_date)); ?></td>
                                                <td>&#8377;<?php echo $hotel[0]->price; ?></td>
                                                <td>&#8377;<?php echo $view[0]->amount; ?></td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                            </tr>
                                            <tr>
                                                <th colspan="5" style="text-align: right;">Sub Total</th>
                                                <td>
                                                    <div style="font-weight: bold;">
                                                        <table>
                                                            <tr>
                                                                <td>  <p style="float : right; display: inline-block;">&#8377; <?php echo $hotel[0]->price; ?> </p></td>
                                                            </tr>
                                                            <tr>
                                                                <td> * <p style="float: right;display: inline-block;"><?php echo $view[0]->Room; ?> </p></td>
                                                            </tr>
                                                            <tr style="border-top: 0.5px black solid;">
                                                                <td> = <p style="float : right; display: inline-block;">&#8377; <?php echo $view[0]->amount; ?> </p></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </td>
                                            </tr>
                                            <tr>
                                                <th colspan="5" style="text-align: right"><p style="display: inline-block;padding-right: 50px;">GST</p><p style="display: inline-block;">8.5%</p></th>
                                                <td>&#8377; 0</td>
                                            </tr>
                                            <tr>
                                                <th colspan="5"><div align="right">Total</div></th>
                                                <td class="style4">&#8377; <?php echo $view[0]->amount; ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                    <hr align="right" width="15%"  style="size:30%;"/>
                                    <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
                                    <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
                                    <table border="1" style="width: 100%;" class="table table-striped">
                                        <tr>
                                            <td  class="style4"><div align="center"><strong><span>T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
                                        </tr>
                                        <tr>
                                            <td bgcolor="#333333"> 
                                                <div class="row" style="color: #777;font-weight: bold;">
                                                    <span class="col-md-4" style="text-align: left;">A: <p style="display: inline"><?php echo $agent[0]->address; ?></p></span>
                                                    <span class="col-md-4" style="text-align: center;">P: <p style="display: inline"><?php echo $agent[0]->phone; ?></p></span>
                                                    <span class="col-md-4" style="text-align: right;">E: <p style="display: inline"><?php echo $agent[0]->email; ?></p></span>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                </div>
                            </article>
                        </section>
                    </section>
                </div>
            </div>
        </main>
        <script src="<?php echo base_url(); ?>Assets/js/jquery-3.4.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script>
            function printDiv()
            {
                var contents = $("#DivIdToPrint").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({"position": "absolute", "top": "-1000000px"});
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>Hotel Booking Invoice</title>');
                //Append the external CSS file.
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/mycss.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/theme-turqoise.css" id="template-color" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/lightslider.min.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styler.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');
                frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>');
                //Append the DIV contents.
                frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();

                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 500);
            }
        </script>
        <?php
        $this->load->view('User/Footer');
        ?>
    </body>
</html>
