﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - my profile</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body onload="initialize()">

        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->

        <?php
        $this->load->view('User/Header');
        ?>


        <!--main-->
        <main class="main" >
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>Favorite Hotel</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <h3 class="text-left col-md-12" style="padding-top: 0px !important; margin-top : 0px !important;">Favorite Hotel</h3>
                    <!--three-col content-->
                    <section class="three-col">
                        <!--inner navigation-->
                        <?php
                        $this->load->view('User/Profile_menu');
                        ?>
                        <!--//inner navigation-->
                        <!--Contain-->
                        <section id="" class="tab-content">
                            <article class="mysettings ">
                                <div class="row">
                                    <?php
                                    if (sizeof($view) == 0) {
                                        ?>
                                        <div class="col-md-12">
                                            <article class="bookings">
                                                <h2>Favourite Hotel</h2>
                                                <center>
                                                    <img src="<?php echo base_url() ?>Assets/images/Favourite_Hotel.gif" style="width: 250px;">
                                                    <h3>Not Any Favourite Hotel At a Time.</h3>
                                                    <a href="<?php echo base_url('Hotel'); ?>">Click Here To Add First Favourite Hotel.</a>
                                                </center>
                                            </article>
                                        </div>
                                        <?php
                                    } else {
                                        $c = 0;
                                        foreach ($view as $data) {
                                            $record = $this->md->my_select("tbl_hotel", "*", array('hotel_id' => $data->type_id));
                                            $wh['location_id'] = $record[0]->location_id;
                                            $city = $this->md->my_select("tbl_location", "*", $wh);
                                            $whe['location_id'] = $city[0]->parent_id;
                                            $state = $this->md->my_select("tbl_location", "*", $whe);
                                            $wher['location_id'] = $state[0]->parent_id;
                                            $country = $this->md->my_select("tbl_location", "*", $wher);
                                            $pic = explode(',', $record[0]->photo);
                                            ?>
                                            <div class="col-md-4" style="padding: 10px !important;">
                                                <a href="<?php echo base_url(); ?>View_hotel/<?php echo $record[0]->hotel_id; ?>">
                                                    <figure>
                                                        <img src="<?php echo base_url(); ?><?php echo $pic[0]; ?>" alt="" style="height: 200px; width: 350px;">
                                                    </figure>
                                                </a>   
                                                <div class="details" style="height: 60px !important;">
                                                    <div class="row">
                                                        <div class="col-md-10" style="padding-bottom: 5px !important;">
                                                            <h4><?php echo $record[0]->hotel_name; ?></h4>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <h4>
                                                                <a onclick="$('#place-del').attr('href', '<?php echo base_url(); ?>Remove-User/place/<?php echo $data->wish_id; ?>')" title="Remove Favourite" data-toggle="modal" data-target=".bs-example-modal-md" style="cursor: pointer; color: #f58634 !important;" class="btndel"><i class="fa fa-trash-o" aria-hidden="true"></i></a>
                                                            </h4>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php
                                            $c++;
                                        }
                                    }
                                    ?>
                                </div>
                            </article>
                        </section>
                        <!--//Contain-->
                    </section>
                    <!--//three-col content-->
                </div>
            </div>
        </main>
        <div class="modal fade bs-example-modal-md" tabindex="-1" role="dialog"  aria-labelledby="mySmallModalLabel">
            <div class="modal-dialog modal-md" role="document">
                <div class="modal-content" style="padding: 30px;">
                    <center>
                        <img src="<?php echo base_url(); ?>admin_assets/images/cross.png" style="height: 100px;width: 100px;color: #b30000;" >
                        <p style="font-size: 12px; color: red;">Favorite Hotel</p>
                        <p style="margin-top: 5%;font-size: 20px;">Are You Sure Want To Remove ??</p>
                        <a href="" class="btn btn-default" data-dismiss="modal" style="padding:6px 40px; ">Cancel</a>
                        <a id="place-del" class="btn  btn-hover-shine" style="padding:6px 25px;background-color: #b30000;color: white;">Yes,Remove it!!</a>
                    </center>
                </div>
            </div>
        </div>
        <!--//main-->
        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
        <script type="text/javascript">
            $(document).ready(function(){    
                $("#profile").click(function(){
                    window.location.href = "<?php echo base_url('My_Profile'); ?>";      
                });     
                $("#h_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_hotel_booking'); ?>";      
                });     
                $("#p_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_package_booking'); ?>";      
                });     
                $("#f_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_Flight_booking'); ?>";      
                });     
                $("#passport").click(function(){    
                    window.location.href = "<?php echo base_url('Passport'); ?>";      
                });     
                $("#review").click(function(){    
                    window.location.href = "<?php echo base_url('Myreview'); ?>";      
                });     
                $("#Place").click(function(){    
                    window.location.href = "<?php echo base_url('favorite_place'); ?>";      
                });     
                $("#hotel").click(function(){    
                    window.location.href = "<?php echo base_url('favorite_hotel'); ?>";      
                });     
                $("#changepass").click(function(){    
                    window.location.href = "<?php echo base_url('change_password'); ?>";      
                });     
                $("#logout").click(function(){    
                    window.location.href = "<?php echo base_url('Logout'); ?>";      
                });     
            });
        </script>
    </body>
</html>