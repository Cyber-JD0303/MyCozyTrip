<?php
$flight_detail = $this->md->my_select("tbl_air_schedule", "*",array('schedule_id' => $view[0]->schedule_id));
$t_city = $this->md->my_select("tbl_location", "*", array('location_id' => $flight_detail[0]->to_location));
$t_state = $this->md->my_select("tbl_location", "*", array('location_id' => $t_city[0]->parent_id));
$t_country = $this->md->my_select("tbl_location", "*", array('location_id' => $t_state[0]->parent_id));
$f_city = $this->md->my_select("tbl_location", "*", array('location_id' => $flight_detail[0]->from_location));
$f_state = $this->md->my_select("tbl_location", "*", array('location_id' => $f_city[0]->parent_id));
$f_country = $this->md->my_select("tbl_location", "*", array('location_id' => $f_state[0]->parent_id));
$plane = $this->md->my_select("tbl_plane", "*", array('plane_id' => $flight_detail[0]->plan_id));
$airline = $this->md->my_select("tbl_airlines", "*", array('airlines_id' => $plane[0]->airlines_id));
$user = $this->md->my_select("tbl_register", "*",array('Rid' => $view[0]->Rid));
$city = $this->md->my_select("tbl_location", "*", array('location_id' => $user[0]->location_id));
if($flight_detail[0]->class == '1')
{
    $class = 'Business Class';
}else if($flight_detail[0]->class == '2')
{
    $class = 'Economy Class';
}else if($flight_detail[0]->class == '3')
{
    $class = 'First Class';
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Flight Invoice</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body>
        <?php
        $this->load->view('User/Header');
        ?>
        <main class="main" >
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>My Account</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <div class="col-md-5">
                        <h3 class="text-left">My Account</h3>
                    </div>
                    <div class="col-md-7">
                        <input type='button' class="gradient-button right print" id='btn' value='Print' onclick='printDiv();'>
                    </div>
                    <!--three-col content-->
                    <section class="three-col">
                        <!--inner navigation-->
                        <?php
                        $this->load->view('User/Profile_menu');
                        ?>

                        <!--//inner navigation-->
                        <!--Contain-->

                        <section id="" class="tab-content">
                            <article class="myreviews">
                                <div id="DivIdToPrint">
                                    <div class="container-fluid">
                                        <div class="row" style="margin : 0px !important;">
                                            <div class="col-md-6">
                                                <div class="logo">
                                                    <a href="" title="MycozyTrip">
                                                        <img src="<?php echo base_url(); ?>Assets/images/txt/logo.png" alt="Book Your Travel" />
                                                    </a>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="contact"  >
                                                    <p class="" style="padding: 15px; ">
                                                        <span  style="padding-left: 30px;">24/7 Support number</span>
                                                        <span  style="padding-left: 30px;" class="number"><a style="color: #A58585 !important;">+91 8980776898</a></span>
                                                    </p>
                                                </div>
                                                <!--//contact-->

                                                <!--Email-->
                                                <div class="contact"> 
                                                    <p class="" style="padding: 15px;">
                                                        <span style="padding-left: 30px;">Email</span>
                                                        <span style="padding-left: 30px; color: #B8ADA8 !important;"><a style="color: #A58585 !important;">mycozytrip@gmail.com</a></span>
                                                    </p>
                                                </div>
                                            </div>
                                            <hr/> 
                                            <div class="row" style="margin : 0px !important;">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="logo" style="padding-top: 5px !important;">
                                                            <table style="border: none !important;margin-bottom: 0px !important;">
                                                                <tr>
                                                                    <td style="padding: 5px !important;border: none !important;">
                                                                        <label>Invoice No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
                                                                    </td>
                                                                    <td style="padding: 5px !important;border: none !important;padding-top: 0px !important;">
                                                                        <?php echo $view[0]->booking_id; ?>
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td style="padding: 5px !important;border: none !important;">
                                                                        <label>Booking Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
                                                                    </td>
                                                                    <td style="padding: 5px !important;border: none !important;padding-top: 0px !important;">
                                                                        <?php echo date('d/m/Y', strtotime($view[0]->book_date)); ?>
                                                                    </td>
                                                                </tr>
                                                            </table>
                                                            
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6" style="margin: -15px -10px !important;">
                                                        <div class="contact">
                                                            <div align="center"><strong style="padding: 15px;font-size: 30px;background-color: #0277b7;color: #fff;">INVOICE</strong></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <table style="border: none !important;">
                                                            <tr style="text-transform: uppercase;">
                                                                <th>Bill TO</th>
                                                            </tr>
                                                            <tr>
                                                                <td style="border-bottom: none !important;border-top: none !important;padding-bottom: 0px !important;"><?php echo $user[0]->name; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="border-bottom: none !important;border-top: none !important;padding: 0px 13px !important;"><?php echo $user[0]->email; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="border-bottom: none !important;border-top: none !important;padding: 0px 13px !important;"><?php echo $user[0]->phone; ?></td>
                                                            </tr>
                                                            <tr>
                                                                <td style="border-top: none !important;padding: 0px 13px 10px 13px !important;"><?php echo $city[0]->name; ?></td>
                                                            </tr>
                                                        </table>
                                                        <table class="table table-striped">
                                                            <tr style="text-transform: uppercase;">
                                                                <th colspan="2" style="text-align: center;">Passenger List</th>
                                                            </tr>
                                                            <tr>
                                                                <th>Name</th>
                                                                <th>Age</th>
                                                            </tr>
                                                            <tr>
                                                                <td>Dobariya Jemish</td>
                                                                <td>20 Year</td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <table style="border: none !important;margin-bottom: 15px !important;">
                                                            <tr style="text-transform: uppercase;">
                                                                <th>Airline</th>
                                                                <th>Destination City</th>
                                                                <th>Plane No</th>
                                                                <th>Booking Date</th>
                                                            </tr>
                                                            <tr>
                                                                <td><?php echo $airline[0]->airlines; ?></td>
                                                                <td><?php echo $t_city[0]->name; ?></td>
                                                                <td><?php echo $plane[0]->plane_name; ?></td>
                                                                <td><?php echo date('d/m/Y', strtotime($view[0]->book_date)); ?></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <table>
                                                            <tr style="text-transform: uppercase;font-weight: bold;">
                                                                <th style="padding: 5px !important;border: none !important;">From</th>
                                                                <th style="padding: 5px !important;border: none !important;">To</th>
                                                                <th style="padding: 5px !important;border: none !important;">Date</th>
                                                                <th style="padding: 5px !important;border: none !important;">Class</th>
                                                                <th style="padding: 5px !important;border: none !important;">Dep. Time</th>
                                                                <th style="padding: 5px !important;border: none !important;">Arr. Time</th>
                                                            </tr>
                                                            <tr>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo $f_city[0]->name; ?></td>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo $t_city[0]->name; ?></td>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo $class; ?></td>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo date('g:i a', strtotime($flight_detail[0]->from_time)); ?></td>
                                                                <td style="padding: 5px !important;border: none !important;"><?php echo date('g:i a', strtotime($flight_detail[0]->to_time)); ?></td>
                                                            </tr>
                                                        </table>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr align="right" width="15%"  style="size:30%;"/>
                                            <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
                                            <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
                                            <table border="1" style="width: 100%;" class="table table-striped">
                                                <tr>
                                                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong><span style="color: #FFFFFF">T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
                                                </tr>
                                            </table>    
                                        </div>
                                    </div>
                                </div>
                            </article>
                        </section>
                    </section>
                </div>
            </div>
        </main>
        <script src="<?php echo base_url(); ?>Assets/js/jquery-3.4.1.min.js" type="text/javascript"></script>
        <script src="<?php echo base_url(); ?>Assets/js/bootstrap.min.js" type="text/javascript"></script>
        <script>
            function printDiv()
            {
                var contents = $("#DivIdToPrint").html();
                var frame1 = $('<iframe />');
                frame1[0].name = "frame1";
                frame1.css({"position": "absolute", "top": "-1000000px"});
                $("body").append(frame1);
                var frameDoc = frame1[0].contentWindow ? frame1[0].contentWindow : frame1[0].contentDocument.document ? frame1[0].contentDocument.document : frame1[0].contentDocument;
                frameDoc.document.open();
                //Create a new HTML document.
                frameDoc.document.write('<html><head><title>Flight Booking Invoice</title>');
                //Append the external CSS file.
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/style.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/mycss.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/theme-turqoise.css" id="template-color" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/lightslider.min.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="<?php echo base_url(); ?>Assets/css/styler.css" type="text/css" />');
                frameDoc.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" type="text/css" />');
                frameDoc.document.write('<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />');
                frameDoc.document.write('<link href="<?php echo base_url(); ?>Assets/css/bootstrap-theme.min.css" rel="stylesheet" type="text/css"/>');
                //Append the DIV contents.
                frameDoc.document.write('</head><body>');
                frameDoc.document.write(contents);
                frameDoc.document.write('</body></html>');
                frameDoc.document.close();

                setTimeout(function () {
                    window.frames["frame1"].focus();
                    window.frames["frame1"].print();
                    frame1.remove();
                }, 500);
            }
        </script>
        <?php
        $this->load->view('User/Footer');
        ?>
    </body>
</html>
