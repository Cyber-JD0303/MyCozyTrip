﻿<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
	<meta name="description" content="Book Your Travel - Online Booking HTML Template">
	<meta name="author" content="themeenergy.com">
	
	<title>My Cozy Trip - Contact</title>
	<?php
            $this->load->view('User/Head');
        ?>
</head>
<body onload="initialize()">

    <!--- loading animation -->
	<div class="loading">
		<div class="ball"></div>
		<div class="ball1"></div>
	</div>
	<!--- //loading animation -->

	<?php
            $this->load->view('User/Header');
        ?>
       
        
	<!--main-->
	<main class="main">		
		<div class="wrap">
			<!--breadcrumbs-->
			<nav class="breadcrumbs">
				<!--crumbs-->
				<ul>
					<li><a href="#" title="Home">Home</a></li> 
					<li>Contact</li>                                       
				</ul>
				<!--//crumbs-->
			</nav>
			<!--//breadcrumbs-->
			<div class="row">
				<!--three-fourth content-->
				<div class="three-fourth">
					
					<!--map-->
					<div class="map-wrap">
                                            <article class="widget"> 
                                                <h4>Our Location</h4>
                                                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3719.0084103067416!2d72.86409901464887!3d21.231515086202123!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be04f3c8840ae65%3A0xe447279a17c1f6c2!2sVIP%20Cir%2C%20Uttran%2C%20Surat%2C%20Gujarat%20394105!5e0!3m2!1sen!2sin!4v1576843491594!5m2!1sen!2sin" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
					</article>

                                        </div>
					<!--//map-->
				</div>	
				<!--three-fourth content-->
				
				<!--sidebar-->
				<aside class="one-fourth right-sidebar lower">
					<!--contact form-->
					<article class="widget">
						<h4>Send us a message</h4>
                                                <form method="post" action="" name="contactform" class="">
                                                    <fieldset>
                                                        <div id="message"></div>
                                                            <div class="row">
                                                                <div class="f-item full-width">
                                                                    <label for="name">Name</label>
                                                                    <input type="text" name="Name" autofocus check_control="alpha" value="<?Php
                                                                        if (!isset($success) && set_value('Name') ) {
                                                                            echo set_value("Name");
                                                                        }
                                                                        else if($this->session->userdata('user'))
                                                                        {
                                                                            $user = $this->md->my_select('tbl_register','name',array('email'=>$this->session->userdata('user')));
                                                                            echo $user[0]->name;
                                                                        }
                                                                        ?>" <?php if($this->session->userdata('user')){ echo 'readonly'; ?> title="readonly"<?php }?>/>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('Name')) {
                                                                            echo form_error("Name");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="f-item full-width">
                                                                    <label for="email">Email</label>
                                                                    <input type="email" check_control="email" check_control="alpha" name="Email" value="<?Php
                                                                    if (!isset($success) && set_value('Email')) 
                                                                    {
                                                                        echo set_value("Email");
                                                                    }
                                                                    else if($this->session->userdata('user'))
                                                                    {
                                                                        echo $this->session->userdata('user');
                                                                    }
                                                                    ?>" <?php if($this->session->userdata('user')){ echo 'readonly'; ?> title="readonly"<?php }?>/>
                                                                    <div class="error">
                                                                        <?php
                                                                        if (form_error('Email')) 
                                                                        {
                                                                            echo form_error("Email");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="f-item full-width">
                                                                    <label for="comments">Message</label>
                                                                    <textarea name="msg" rows="10" cols="10"><?Php
                                                                    if (!isset($success) && set_value('msg')) 
                                                                    {
                                                                        echo set_value("msg");
                                                                    }
                                                                    ?></textarea>
                                                                    <div class="error">
                                                                    <?php
                                                                        if (form_error('msg')) 
                                                                        {
                                                                            echo form_error("msg");
                                                                        }
                                                                        ?>
                                                                    </div>
                                                                </div>
                                                                <div class="f-item full-width">
                                                                        <input type="submit" value="Send" name="submit" class="gradient-button" />
                                                                </div>
                                                            </div>
                                                    </fieldset>
						</form>
					</article>
					<!--//contact form-->
					
					<!--contact info-->
					<article class="widget">
						<h4>Or contact us directly</h4>
                                                <p class="number"><a href="tel:8980776898" style="padding-left: 30px;">+91 8980776898</a></p>
                                                <p class="email"><a href="mailto:mycozytrip@gmail.com" style="padding-left: 30px;">mycozytrip@gmail.com</a></p>   
					</article>
					<!--//contact info-->
				</aside>
				<!--//sidebar-->
			</div>
			<!--//main content-->
		</div>
            <?php
            if (isset($success)) {
                ?>
                <div class="my_alert_success animated bounceInLeft">
                    <p>
                        <i class="fa fa-check-circle" aria-hidden="true"></i>
                        <b>Yeah, </b> <small><?php echo $success; ?></small>
                    </p>
                </div>
                <?php
            }
            if (isset($error)) {
                ?>
                <div class="my_alert animated bounceInRight">
                    <p>
                        <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                        <b>Oops,</b><small><?php echo $error; ?></small>
                    </p>
                </div>
                <?php
            }
            ?>
	</main>
	<!--//main-->
	<?php
            $this->load->view('User/Footer');
        ?>
        <?php
            $this->load->view('User/Footer_Script');
        ?>
	</body>

</html>