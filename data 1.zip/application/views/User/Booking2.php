<?php
$package_detail = $this->md->my_select("tbl_trip_package", "*", array('package_id' => $booking_detail[0]->package_id));
$user = $this->md->my_select("tbl_register", "*", array('Rid' => $booking_detail[0]->Rid));
$place = $this->md->my_select("tbl_place", "*", array('name' => $package_detail[0]->To_location));
$agent = $this->md->my_select("tbl_agent", "*", array('agent_id' => $package_detail[0]->agent_id));
$city = $this->md->my_select("tbl_location", "*", array('location_id' => $package_detail[0]->To_location));
$state = $this->md->my_select("tbl_location", "*", array('location_id' => $city[0]->parent_id));
$country = $this->md->my_select("tbl_location", "*", array('location_id' => $state[0]->parent_id));
$f_city = $this->md->my_select("tbl_location", "*", array('location_id' => $package_detail[0]->From_location));
$f_state = $this->md->my_select("tbl_location", "*", array('location_id' => $f_city[0]->parent_id));
$f_country = $this->md->my_select("tbl_location", "*", array('location_id' => $f_state[0]->parent_id));
$t_city = $this->md->my_select('tbl_location', '*', array('location_id' => $package_detail[0]->To_location));
$hotel = $this->md->my_select("tbl_hotel", "*", array('hotel_id' => $package_detail[0]->hotel_id));
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title><?php echo $package_detail[0]->name; ?></title>
        <?php
        $this->load->view('User/Head');
        ?>
        <style>
            .lSPager lSGallery li a img{
                width :100% !important;
                margin-right: 5px !important;
                height: 125px !important;
            }
            .text-wrap
            {
                padding: 0px 10px 10px !important;
            }
        </style>
    </head>
    <body>
        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->


        <?php
        $this->load->view('User/Header');
        ?>

        <!--main-->
        <main class="main">

            <div class="wrap">
                <div class="row">
                    <!--breadcrumbs-->
                    <nav class="breadcrumbs">
                        <!--crumbs-->
                        <ul>
                            <li><a href="#" title="Home">Home</a></li> 
                            <li><a href="<?php echo base_url('place') ?>" title="place">place</a></li>                                       
                            <li><a href="<?php echo base_url('') ?>View_place/<?php echo $place[0]->place_id; ?>" title="place"><?php echo $city[0]->name; ?></a></li>                                       
                            <li><a href="<?php echo base_url(); ?>View_package/<?php echo $package_detail[0]->package_id; ?>" title="place"><?php echo $package_detail[0]->name; ?></a></li>                                       
                            <li>Booking <?php echo $city[0]->name; ?> Package</li>                                       
                        </ul>
                        <!--//crumbs-->
                    </nav>
                    <div class="row">

                        <!--three-fourth content-->
                        <div class="three-fourth">
                            <fieldset>
                                <form action="<?php echo PAYPAL_URL; ?>" method="post" class="static-content booking">
                                    <!-- Identify your business so that you can collect the payments. -->
                                    <input type="hidden" name="business" value="<?php echo PAYPAL_ID; ?>">
                                    <!-- Specify a Buy Now button. -->
                                    <input type="hidden" name="cmd" value="_xclick">
                                    <!-- Specify details about the item that buyers will purchase. -->
                                    <input type="hidden" name="item_name" value="<?php echo $package_detail[0]->name; ?>">
                                    <input type="hidden" name="item_number" value="<?php echo $booking_detail[0]->booking_id; ?>">
                                    <input type="hidden" name="amount" value="<?php echo $booking_detail[0]->amount; ?>">
                                    <input type="hidden" name="currency_code" value="<?php echo PAYPAL_CURRENCY; ?>">

                                    <!-- Specify URLs -->
                                    <input type="hidden" name="return" value="<?php echo PAYPAL_RETURN_URL; ?>">
                                    <input type="hidden" name="cancel_return" value="<?php echo PAYPAL_CANCEL_URL; ?>">

                                    <!-- Display the payment button. -->

                                    <h2><span>02 </span>Payment Confirmation</h2>
                                    <div class="text-wrap">
                                        <input class="gradient-button right print" type="image" name="Book Now" value="Book Now" border="0" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif">
                                        <h3>Traveller info</h3>
                                    </div>
                                    <div class="text-wrap">
                                        <div class="output">
                                            <p>Booking number :</p>
                                            <p><?php echo $booking_detail[0]->booking_id; ?></p>
                                            <p>Name : </p>
                                            <p><?php echo $user[0]->name; ?></p>
                                            <p>Email : </p>
                                            <p><?php echo $user[0]->email; ?></p>
                                            <p>Phone No :</p>
                                            <p><?php echo $user[0]->phone; ?></p>
                                            <p>Person :</p>
                                            <p><?php echo $booking_detail[0]->person; ?></p>
                                            <p>price :</p>
                                            <p>&#8377; <?php echo $package_detail[0]->price; ?></p>
                                            <p>Total Amount :</p>
                                            <p>&#8377; <?php echo $booking_detail[0]->amount; ?></p>
                                            <p>Country :</p>
                                            <p><?php echo $f_country[0]->name; ?></p>
                                            <p>State :</p>
                                            <p><?php echo $f_state[0]->name; ?></p>
                                            <p>City :</p>
                                            <p><?php echo $f_city[0]->name; ?></p>
                                            <p>ZIP code: </p>
                                            <p><?php echo $booking_detail[0]->zipcode; ?></p>
                                        </div>
                                    </div>
                                    <?php
                                    if ($booking_detail[0]->descirption != '') {
                                        ?>
                                        <h3>Special requirements</h3>
                                        <div class="text-wrap">
                                            <p><?php echo $booking_detail[0]->descirption; ?></p>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                    <h3>Payment</h3>
                                    <div class="text-wrap">
                                        <p>You have now confirmed and guaranteed your booking by credit card.All payments are to be made at the hotel during your stay, unless otherwise stated in the hotel policies or in the room conditions.Please note that your credit card may be pre-authorised prior to your arrival. </p>
                                        <p><strong class="dark">This hotel accepts the following forms of payment:</strong></p>
                                        <p>American Express, Visa, MasterCard</p>
                                    </div>

                                    <h3>Don’t forget</h3>
                                    <div class="text-wrap">
                                        <p>You can change or cancel your booking via our online self service tool myBookYourTravel:
                                            <a href="#">https://secure.bookyourtravel.com/myreservations.html?tmpl=profile/myreservations;bn=904054553;pincode=6525</a></p>
                                        <p><strong>We wish you a pleasant stay</strong><i>your BookYourTravel team</i></p>
                                    </div>
                                </form>
                            </fieldset>
                        </div>
                        <!--//three-fourth content-->

                        <!--sidebar-->
                        <aside class="one-fourth right-sidebar">
                            <!--Agent details-->
                            <article class="hotel-details booking-details">
                                <h4>package Details</h4>
                                <h1><?php echo $package_detail[0]->name; ?></h1>
                                <span class="address"><?php echo $f_city[0]->name; ?> To <?php echo $city[0]->name; ?></span>
                                <dl class="booking-info">
                                    <dt>Hotel</dt>
                                    <dd><?php echo $hotel[0]->hotel_name; ?></dd>
                                    <dt>Hotel website</dt>
                                    <dd><?php echo $hotel[0]->website; ?></dd>
                                    <dt>Hotel Phone Number</dt>
                                    <dd><?php echo $hotel[0]->contact; ?></dd>
                                    <dt>Travel Type</dt>
                                    <dd><?php echo $package_detail[0]->travel_type; ?></dd>
                                    <?php
                                    if ($package_detail[0]->travel_type == 'Flight') {
                                        $flight = $this->md->my_select("tbl_air_schedule", "*", array('schedule_id' => $package_detail[0]->travel_id));
                                        ?>
                                        <dt>Flight Arrival Time</dt>
                                        <dd><?php echo $flight[0]->from_time; ?></dd>
                                        <dt>Flight Departure Time</dt>
                                        <dd><?php echo $flight[0]->to_time; ?></dd>
                                    <?php
                                }
                                ?>
                                </dl>
                                <div class="price">
                                    <p class="total">Total Price : &#8377; <?php echo $booking_detail[0]->amount; ?></p>
                                </div>
                            </article>
                            <article class="widget">
                                <h4>Agent Details</h4>
                                <img src="<?php echo base_url(); ?><?php echo $agent[0]->profile_pic; ?>" style="width: 200px;" alt="<?php echo $agent[0]->company_name; ?>"/>
                                <p><?php echo $agent[0]->company_name; ?></p>
                                <a href="tel:<?php echo $agent[0]->phone; ?>"><span><i class="fa fa-phone"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->phone; ?></p></span></a><br>
                                <a href="mailto:<?php echo $agent[0]->email; ?>"><span><i class="fa fa-envelope"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->email; ?></p></span></a>
                                <p class="address"><?php echo $agent[0]->address; ?></p>
                            </article>
                            <!--//Need Help Booking?-->

                            <!--Why Book with us?-->
                            <article class="widget">
                                <h4>Need Help Booking?</h4>
                                <p>Call our customer services team on the number below to speak to one of our advisors who will help you with all of your holiday needs.</p>
                                <a href="tel:<?php echo $agent[0]->phone; ?>"><span><i class="fa fa-phone"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->phone; ?></p></span></a><br>
                            </article>
                            <!--//Why Book with us?-->

                        </aside>
                        <!--//sidebar-->
                    </div>
                </div>
            </div>
        </main>
<?php
if (isset($success)) {
    ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
    <?php
}
if (isset($error)) {
    ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
    <?php
}
?>
        <!--//main-->

<?php
$this->load->view('User/Footer');
?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
        <script type="text/javascript">
            $(document).ready(function () {
                $('#image-gallery').lightSlider({
                    gallery: true,
                    item: 1,
                    thumbItem: 6,
                    slideMargin: 0,
                    speed: 500,
                    auto: true,
                    loop: true,
                    onSliderLoad: function () {
                        $('#image-gallery').removeClass('cS-hidden');
                    }
                });

                $('#gallery1,#gallery2,#gallery3,#gallery4').lightGallery({
                    download: false
                });
            });
        </script>
    </body>
</html>