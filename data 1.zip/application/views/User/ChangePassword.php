﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - my profile</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body onload="initialize()">

        <!--- loading animation -->
            <div class="loading">
                <div class="ball"></div>
                <div class="ball1"></div>
            </div>
        <!--- //loading animation -->

        <?php
        $this->load->view('User/Header');
        ?>


        <!--main-->
        <main class="main" >
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>Change Password</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <h3 class="text-left">Change Password</h3>
                    <!--three-col content-->
                    <section class="three-col">
                        <!--inner navigation-->
                        <?php
                        $this->load->view('User/Profile_menu');
                        ?>
                        <!--//inner navigation-->
                        <!--Contain-->
                        <section id="" class="tab-content">
                            <article class="mysettings ">
                                <h6>To change your password.Enter your current password in the field below and enter new password, retype it for verification and click <b>change password.</b></h6>
                                <hr style="margin-top: -10px;">

                                <div class="col-md-8 ">
                                    <div class="profile-edit">
                                        <form method="post" class="form-horizontal" action="" class="" name="changepassword">
                                            <h4 class="mb-xlg text-left">Change Your Password</h4>
                                            <fieldset>
                                                <div class="form-group">
                                                    <label class="col-md-2" for="password-field">Old Password</label>
                                                    <div class="col-md-9">
                                                        <input id="password-field" type="password" name="old_pass" placeholder="Old Password" autofocus="" class="form-control" id="password-field" value="<?Php
                                                        if (!isset($success) && set_value('old_pass')) {
                                                            echo set_value("old_pass");
                                                        }
                                                        ?>"/>
                                                        <i class="fa fa-eye-slash field-icon toggle-password fa-lg" style="vertical-align: -25%;" toggle="#password-field"></i>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('old_pass')) {
                                                                echo form_error("old_pass");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-2" for="password-field1">New Password</label>
                                                    <div class="col-md-9">
                                                        <input id="password-field1" type="password" name="new_pass" placeholder="New Password" class="form-control" id="password-field1" value="<?Php
                                                        if (!isset($success) && set_value('new_pass')) {
                                                            echo set_value("new_pass");
                                                        }
                                                        ?>"/>
                                                        <i class="fa fa-eye-slash field-icon toggle-password fa-lg" style="vertical-align: -25%;" toggle="#password-field1"></i>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('new_pass')) {
                                                                echo form_error("new_pass");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <label class="col-md-2" for="password-field2">Confirm Password</label>
                                                    <div class="col-md-9">
                                                        <input id="password-field2" type="password" name="confirm_pass" id="password" placeholder="Confirm Password" class="form-control" id="password-field2" value="<?Php
                                                        if (!isset($success) && set_value('confirm_pass')) {
                                                            echo set_value("confirm_pass");
                                                        }
                                                        ?>"/>
                                                        <i class="fa fa-eye-slash field-icon toggle-password fa-lg" style="vertical-align: -25%;" toggle="#password-field2"></i>
                                                        <div class="error">
                                                            <?php
                                                            if (form_error('confirm_pass')) {
                                                                echo form_error("confirm_pass");
                                                            }
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </fieldset>
                                            <input type="submit" value="Change password" name="update" class="gradient-button">
                                        </form>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <h3> Password Must contain:</h3>
                                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- Minimum of 8 Character. </label>
                                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- At least one Uppercase Letter [A-Z].</label>
                                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- At least one Lowercase Letter [a-z]. </label>
                                    <label>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;- At least one Number [0-9]. </label>
                                </div>
                            </article>
                        </section>
                        <!--//Contain-->
                    </section>
                    <!--//three-col content-->
                </div>
            </div>
        </main>
        <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b><small><?php echo $success; ?></small></b> 
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><small><?php echo $error; ?></small></b> 
                </p>
            </div>
            <?php
        }
        ?>
        <!--//main-->
        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
        <script type="text/javascript">
            $(document).ready(function(){    
                $("#profile").click(function(){    
                    window.location.href = "<?php echo base_url('My_Profile'); ?>";      
                });     
                $("#h_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_hotel_booking'); ?>";      
                });     
                $("#p_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_package_booking'); ?>";      
                });     
                $("#f_booking").click(function(){    
                    window.location.href = "<?php echo base_url('My_Flight_booking'); ?>";      
                });     
                $("#passport").click(function(){    
                    window.location.href = "<?php echo base_url('Passport'); ?>";      
                });     
                $("#review").click(function(){    
                    window.location.href = "<?php echo base_url('Myreview'); ?>";      
                });     
                $("#Place").click(function(){    
                    window.location.href = "<?php echo base_url('favorite_place'); ?>";      
                });     
                $("#hotel").click(function(){    
                    window.location.href = "<?php echo base_url('favorite_hotel'); ?>";      
                });     
                $("#changepass").click(function(){    
                    window.location.href = "<?php echo base_url('change_password'); ?>";      
                });     
                $("#logout").click(function(){    
                    window.location.href = "<?php echo base_url('Logout'); ?>";      
                });     
            });
        </script>
    </body>
</html>