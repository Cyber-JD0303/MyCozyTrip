<?php
$place = $this->md->my_select("tbl_place","*",array('name'=>$package_detail[0]->To_location));
$agent = $this->md->my_select("tbl_agent","*",array('agent_id'=>$package_detail[0]->agent_id));
$city = $this->md->my_select("tbl_location","*",array('location_id'=>$package_detail[0]->To_location));
$state = $this->md->my_select("tbl_location", "*", array('location_id'=>$city[0]->parent_id));
$country = $this->md->my_select("tbl_location", "*", array('location_id'=>$state[0]->parent_id));
$f_city = $this->md->my_select("tbl_location","*",array('location_id'=>$package_detail[0]->From_location));
$f_state = $this->md->my_select("tbl_location", "*", array('location_id'=>$f_city[0]->parent_id));
$f_country = $this->md->my_select("tbl_location", "*", array('location_id'=>$f_state[0]->parent_id));
$hotel = $this->md->my_select("tbl_hotel", "*", array('hotel_id'=>$package_detail[0]->hotel_id));
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title><?php echo $package_detail[0]->name; ?></title>
        <?php
        $this->load->view('User/Head');
        ?>
        <style>
            .lSPager lSGallery li a img{
                width :100% !important;
                margin-right: 5px !important;
                height: 125px !important;
            }
        </style>
    </head>
    <body>
        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->


        <?php
        $this->load->view('User/Header');
        ?>

        <!--main-->
        <main class="main">

            <div class="wrap">
                <div class="row">
                    <!--breadcrumbs-->
                    <nav class="breadcrumbs">
                        <!--crumbs-->
                        <ul>
                            <li><a href="#" title="Home">Home</a></li> 
                            <li><a href="<?php echo base_url('place') ?>" title="place">place</a></li>                                       
                            <li><a href="<?php echo base_url('') ?>View_place/<?php echo $place[0]->place_id;  ?>" title="place"><?php echo $city[0]->name; ?></a></li>                                       
                            <li><a href="<?php echo base_url(); ?>View_package/<?php echo $package_detail[0]->package_id; ?>" title="place"><?php echo $package_detail[0]->name; ?></a></li>                                       
                            <li>Booking <?php echo $city[0]->name; ?> Package</li>                                       
                        </ul>
                        <!--//crumbs-->
                    </nav>
                    <div class="row">
                        
                        <!--three-fourth content-->
                        <div class="three-fourth">
                            <form id="booking" method="post" action="" novalidate="" class="static-content booking">
                                <fieldset>
                                        <h2><span>01</span> Traveller Info</h2>
                                        <div class="row">
                                            <div class="f-item col-md-12 form-group active">
                                                <label for="name">Name </label>
                                                <input type="text" readonly="" id="name" name="name" value="<?php echo $user[0]->name; ?>">
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="f-item one-half">
                                                <label for="email">Email </label>
                                                <input type="email" id="email" name="email" value="<?php echo $user[0]->email; ?>" readonly="">
                                            </div>
                                            <div class="f-item one-half">
                                                <label for="phone">Phone Number </label>
                                                <input type="text" id="phone" name="phone" value="<?php echo $user[0]->phone; ?>" readonly="">
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="col-md-6">  
                                                <label for="country">Country</label>
                                                <select readonly="" name="country" id="country" class="fancy-select form-control" onchange="set_combo('state', this.value);">
                                                    <option>Select Country</option>
                                                    <?php
                                                    $recordset = $this->md->my_select("tbl_location", "*", array("label" => "country"));
                                                    foreach ($recordset as $data) {
                                                        ?>
                                                        <option value="<?php echo $data->location_id ?>" <?php
                                                    if (!isset($success) && set_select("country", $data->location_id)) {
                                                        echo "selected";
                                                    }
                                                    else 
                                                    {
                                                        if( $data->location_id == $f_country[0]->location_id )
                                                        {
                                                            echo "selected";
                                                        }
                                                    }
                                                    ?>><?php echo $data->name; ?></option>
                                                    <?php
                                                        }
                                                        ?>
                                                </select>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('country')) {
                                                        echo form_error("country");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div  class="col-md-6">  
                                                <label for="state">State </label>
                                                <select readonly name="state" id="state" class="fancy-select form-control" onchange="set_combo('city', this.value);">
                                                    <option value="">Select State</option>
                                                        <?php
                                                            if( $this->input->post('country') && !isset($success) )
                                                            {
                                                                $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$this->input->post('country')));
                                                                foreach ($recordset as $data)
                                                                {
                                                            ?>
                                                            <option value="<?php echo $data->location_id ?>" <?php

                                                                if(!isset($success) && set_select('state', $data->location_id) )
                                                                {
                                                                    echo set_select('state', $data->location_id);
                                                                }
                                                            ?>><?php echo $data->name; ?></option>
                                                            <?php
                                                                }
                                                            }
                                                            else
                                                            {
                                                                $recordset = $this->md->my_select("tbl_location","*",array("label"=>"state",'parent_id'=>$f_country[0]->location_id));
                                                                foreach ($recordset as $data)
                                                                {
                                                            ?>
                                                            <option value="<?php echo $data->location_id ?>" <?php
                                                               if($data->location_id == $f_state[0]->location_id)
                                                               {
                                                                   echo "selected";
                                                               }
                                                            ?>><?php echo $data->name; ?></option>
                                                            <?php
                                                                }
                                                            }
                                                        ?>
                                                </select>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('state')) {
                                                        echo form_error("state");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row form-group" style="margin-bottom: 0 !important;">
                                            <div class="col-md-6">  
                                                <label>City </label>
                                                <select readonly name="city" id="city" class="fancy-select form-control">
                                                    <option>Select City</option>
                                                    <?php
                                                        if( $this->input->post('state') && !isset($success) )
                                                        {
                                                            $recordset = $this->md->my_select("tbl_location","*",array("label"=>"city",'parent_id'=>$this->input->post('state')));
                                                            foreach ($recordset as $data)
                                                            {
                                                        ?>
                                                        <option value="<?php echo $data->location_id ?>" <?php

                                                            if(!isset($success) && set_select('city', $data->location_id) )
                                                            {
                                                                echo set_select('city', $data->location_id);
                                                            }
                                                        ?>><?php echo $data->name; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                        else
                                                        {
                                                            $recordset = $this->md->my_select("tbl_location","*",array("label"=>"city",'parent_id'=>$f_state[0]->location_id));
                                                            foreach ($recordset as $data)
                                                            {
                                                        ?>
                                                        <option value="<?php echo $data->location_id ?>" <?php
                                                           if($data->location_id == $f_city[0]->location_id )
                                                           {
                                                               echo "selected";
                                                           }
                                                        ?>><?php echo $data->name; ?></option>
                                                        <?php
                                                            }
                                                        }
                                                    ?>
                                                </select>
                                                <div class="error">
                                                    <?php
                                                    if (form_error('city')) {
                                                        echo form_error("city");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="f-item one-half">
                                                <label for="zip">Pincode Code</label>
                                                <input type="number" placeholder="Enter Pincode" minlength="1" id="zip" name="zip" value="<?php 
                                                if (!isset($success) && set_value("zip")) {
                                                    echo set_value("zip");
                                                 }?>">
                                                <div class="error">
                                                    <?php
                                                    if (form_error('zip')) {
                                                        echo form_error("zip");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="f-item one-half">                                                
                                                <label for="booking_date" >Booking Date</label>
                                                <input type="date" id="booking_date" name="booking_date" value="<?php 
                                                if (!isset($success) && set_value("booking_date")) {
                                                    echo set_value("booking_date");
                                                 }?>">
                                                <div class="error">
                                                    <?php
                                                    if (form_error('booking_date')) {
                                                        echo form_error("booking_date");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                            <div class="f-item one-half">                                                
                                                <label for="person">Person</label>
                                                <input type="number" name="person" min="1" max="10" onchange="set_price('price','<?php echo $package_detail[0]->price; ?>',this.value);" id="person" value="<?php 
                                                if (!isset($success) && set_value("person")) {
                                                    echo set_value("person");
                                                 }else
                                                 {
                                                     echo '1';
                                                 }?>">
                                                <div class="error">
                                                    <?php
                                                    if (form_error('person')) {
                                                        echo form_error("person");
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row form-group">
                                            <div class="f-item full-width">
                                                <label for="discription">Special requirements: <span>(Not Guaranteed)</span></label>
                                                <textarea rows="10" id="discription" cols="10" name="discription"><?php 
                                                if (!isset($success) && set_value("discription")) {
                                                    echo set_value("discription");
                                                 } ?></textarea>
                                            </div>
                                            <span class="info">Please write your requests in English.</span>
                                        </div>
                                        <div class="row">
                                            <div class="f-item full-width">
                                                <input type="submit" class="gradient-button" value="Proceed to next step" name="book" id="next-step">
                                            </div>
                                        </div>
                                </fieldset>
                            </form>
                        </div>
                        <!--//three-fourth content-->

                        <!--sidebar-->
                        <aside class="one-fourth right-sidebar">
                            <!--Agent details-->
                            <article class="hotel-details booking-details">
                                <h4>package Details</h4>
                                    <h1><?php echo $package_detail[0]->name; ?></h1>
                                    <span class="address"><?php echo $f_city[0]->name;?> To <?php echo $city[0]->name;  ?></span>
                                    <dl class="booking-info">
                                        <dt>Hotel</dt>
                                        <dd><?php echo $hotel[0]->hotel_name; ?></dd>
                                        <dt>Travel Type</dt>
                                        <dd><?php echo $package_detail[0]->travel_type; ?></dd>
                                        <?php
                                        if($package_detail[0]->travel_type == 'Flight')
                                        {
                                            $flight = $this->md->my_select("tbl_air_schedule", "*", array('schedule_id'=>$package_detail[0]->travel_id));
                                        ?>
                                        <dt>Flight Arrival Time</dt>
                                        <dd><?php echo $flight[0]->from_time; ?></dd>
                                        <dt>Flight Departure Time</dt>
                                        <dd><?php echo $flight[0]->to_time; ?></dd>
                                        <?php
                                        }
                                        ?>
                                    </dl>
                                    <div class="price">
                                        <p class="total" id="price">Total Price : &#8377; <?php echo $package_detail[0]->price; ?></p>
                                    </div>
                            </article>
                            <article class="widget">
                                <h4>Agent Details</h4>
                                <img src="<?php echo base_url(); ?><?php echo $agent[0]->profile_pic; ?>" style="width: 200px;" alt="<?php echo $agent[0]->company_name; ?>"/>
                                <p><?php echo $agent[0]->company_name; ?></p>
                                <a href="tel:<?php echo $agent[0]->phone; ?>"><span><i class="fa fa-phone"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->phone; ?></p></span></a><br>
                                <a href="mailto:<?php echo $agent[0]->email; ?>"><span><i class="fa fa-envelope"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->email; ?></p></span></a>
                                <p class="address"><?php echo $agent[0]->address; ?></p>
                            </article>
                            <!--//Need Help Booking?-->

                            <!--Why Book with us?-->
                            <article class="widget">
                                    <h4>Need Help Booking?</h4>
                                    <p>Call our customer services team on the number below to speak to one of our advisors who will help you with all of your holiday needs.</p>
                                    <a href="tel:<?php echo $agent[0]->phone; ?>"><span><i class="fa fa-phone"></i>&nbsp;&nbsp;<p style="position: relative;font-weight: 700;display: inline-block !important;"><?Php echo $agent[0]->phone; ?></p></span></a><br>
                            </article>
                            <!--//Why Book with us?-->

                        </aside>
                        <!--//sidebar-->
                        </div>
                    </div>
            </div>
        </main>
            <?php
        if (isset($success)) {
            ?>
            <div class="my_alert_success animated bounceInLeft">
                <p>
                    <i class="fa fa-check-circle" aria-hidden="true"></i>
                    <b> </b> <small><?php echo $success; ?></small>
                </p>
            </div>
            <?php
        }
        if (isset($error)) {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b></b><small><?php echo $error; ?></small>
                </p>
            </div>
            <?php
        }
        ?>
        <!--//main-->

        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
        <script type="text/javascript">
        fdate();
        function fdate(){
            var today = new Date();
            var dd = String(today.getDate()).padStart(2, '0');
            var mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
            var yyyy = today.getFullYear();
            today = yyyy + '-' + mm + '-' + dd ;
            $("#booking_date").attr("min",today);
        }
	 $(document).ready(function() {
            $('#image-gallery').lightSlider({
                gallery:true,
                item:1,
                thumbItem:6,
                slideMargin: 0,
                speed:500,
                auto:true,
                loop:true,
                onSliderLoad: function() {
                    $('#image-gallery').removeClass('cS-hidden');
                }  
            });
			
			$('#gallery1,#gallery2,#gallery3,#gallery4').lightGallery({
				download:false
			});
		});
    </script>
    </body>
</html>