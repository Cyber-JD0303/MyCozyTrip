﻿<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - About AS</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body onload="initialize()">

        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->

        <?php
        $this->load->view('User/Header');
        ?>


        <!--main-->
        <main class="main">
            <div class="wrap">
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="#" title="Home">Home</a></li> 
                        <li>About Us</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
            <div class="row">
                <h2 class="text-left" style="text-align: left;font-size: 30px"> About Us </h2>

                <p style="text-align: justify">
                    Nurtured from the seed of a single great idea - to empower the traveller - My cozy Trip is a pioneer in India’s online travel industry. Founded in the year 2000 by Jemish Dobariya,My cozy Trip came to life to empower the Indian traveller with instant bookings and comprehensive choices. The company initiated its journey serving the US-India travel market offering a range of best-value products and services powered by technology and round-the-clock customer support.
                </p>
                <p style="text-align: justify">

                    After consolidating its position in the market as a brand recognised for its reliability and transparency, My Cozy Trip launched its India operations in 2005. With more and more Indians initiating to transact online with IRCTC and new opportunities with the advent of low cost carriers, My Cozy Trip offered travellers the convenience of booking travel online with a few clicks.
                </p>
                <p style="text-align: justify">

                    My cozy Trip’s rise has been led by the vision and the spirit of each one of its employees, for whom no idea was too big and no problem too difficult. With untiring determination, My Cozy Trip has proactively diversified its product offering, adding a variety of online and offline products and services. My cozy Trip has stayed ahead of the curve by continually evolving its technology to meet the ever-changing demands of the rapidly developing global travel market, steadily establishing itself as India’s leading online travel company.
                </p>
                <H2>Management Team</H2>
                <div class="row" style="padding-top: 30px;">
                    <div class="col-md-2">
                        <div>
                            <img src="<?php echo base_url() ?>Admin_Assets\images\Upload\Admin\Ad-2.jpg" style="width:138px;height:138px">
                        </div>
                    </div>
                    <div class="Col-md-10">
                        <div>
                            <h6 id="Ourstory" class="Red TextBold XCN" style="margin:0;padding:0;font-size:16px;">
                                Dobariya Jemish, CEO
                            </h6>
                            <p style="text-align: justify;padding-top: 10px !important;"> 
                                Sometimes it takes a lowly, title-less man to humble the world.Kings, rulers, CEOs, judges, doctors, pastors, they are already expected to be greater and wiser.” 
                                No matter what the industry you choose to ultimately invest all your time and energy in, be sure you're the owner, founder, and CEO.
                                Sometimes it takes a lowly, title-less man to humble the world.Kings, rulers, CEOs, judges, doctors, pastors, they are already expected to be greater and wiser.” 
                                No matter what the industry you choose to ultimately invest all your time and energy in, be sure you're the owner, founder, and CEO.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row" style="padding-top: 30px;">
                    <div class="col-md-2">
                        <div>
                            <img src="<?php echo base_url() ?>Admin_Assets\images\Upload\Admin\Ad-2.jpg" style="width:138px;height:138px">
                        </div>
                    </div>
                    <div class="Col-md-10">
                        <div>
                            <h6 id="Ourstory" class="Red TextBold XCN" style="margin:0;padding:0;font-size:16px;">
                                Nemisha Vadodariya, Managment
                            </h6>
                            <p style="text-align: justify;padding-top: 10px !important;"> 
                                Sometimes it takes a lowly, title-less man to humble the world. 
                                Kings, rulers, CEOs, judges, doctors, pastors, they are already expected to be greater and wiser. 
                            <p>“No matter what the industry you choose to ultimately invest all your time and energy in, be sure you're the owner, founder, and CEO's.</p>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row" style="padding-top: 30px;">
                    <div class="col-md-2">
                        <div>
                            <img src="<?php echo base_url() ?>Admin_Assets\images\Upload\Admin\Ad-2.jpg" style="width:138px;height:138px">
                        </div>
                    </div>
                    <div class="Col-md-10">
                        <div>
                            <h6 id="Ourstory" class="Red TextBold XCN" style="margin:0;padding:0;font-size:16px;">
                                Twinkal Senjaliya, DBA
                            </h6>
                            <p style="text-align: justify;padding-top: 20px !important;"> 
                                Twinkal Senjaliya has been Chief Executive Officer of Mycozy since June 2023. Prior to Mycozy. 
                                He served as an Executive Vice President of Info Edge India (Naukri group), heading two group businesses namely Shiksha.com and Jeevansathi.com. 
                                He’s also worked as General Manager of Marketing and Innovation at Airtel and has also had multiple roles across Marketing, Brand Management and Sales at Hindustan Unilever. 
                                Prakash has completed his MBA from IIM Calcutta and also holds an Honours degree in Production Engineering from Mumbai University.
                            </p>
                        </div>
                    </div>
                </div>
            </div><!-- /.col-lg-4 -->
        </main>
        <!--//main-->
        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
    </body>

</html>