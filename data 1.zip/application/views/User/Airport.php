<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - Airports</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body>
        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->


        <?php
        $this->load->view('User/Header');
        ?>
        
        <!--main-->
        <main class="main">
           
            <div class="wrap">
                <div class="row">
                    
            <!--breadcrumbs-->
                    <nav class="breadcrumbs">
                        <!--crumbs-->
                        <ul>
                            <li><a href="#" title="Home">Home</a></li> 
                            <li>Airport</li>                                       
                        </ul>
                        <!--//crumbs-->
                    </nav>
                    <!--//breadcrumbs-->
                    <div class="full-width">
                        <header class="s-title">
                            <div class="row">
                                <div class="col-md-6" >
                                    <h2 style="padding-top: 5px !important;padding-bottom: 10px !important;">Most popular Airport</h2>
                                </div>
                                <div class="col-md-6" style="padding-top: 5px !important;padding-bottom: 10px !important;">
                                    <input type="text" name="search" id="search" placeholder="Search Any Airport Here.." onkeyup="set_combo('Airport',this.value);"/>
                                </div>
                            </div>
                        </header>
                        <div class="deals ">
                            <div class="row" id="Airport">
                                <?php
                                $c=0;
                                foreach($view as $data)
                                {
                                    $pic= explode(',', $data->photo);
                                    ?>
                                <!--<a href="">-->
                                    <article class="one-fourth">
                                        <figure>
                                            <img src="<?php echo base_url(); ?><?php echo $pic[0]; ?>" alt="" style="height: 200px; width: 350px;">
                                        </figure>
                                        <div class="details" style="height: 80px !important;">
                                            <h4><?php echo $data->air_name; ?></h4>
                                        </div>
                                    </article>
                                <!--</a>-->   
                                <?php
                                    $c++;
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
        <!--//main-->

        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>       
    </body>

</html>