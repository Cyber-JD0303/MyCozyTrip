<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="Book Your Travel - Online Booking HTML Template">
        <meta name="description" content="Book Your Travel - Online Booking HTML Template">
        <meta name="author" content="themeenergy.com">

        <title>My Cozy Trip - Feedback</title>
        <?php
        $this->load->view('User/Head');
        ?>
    </head>
    <body onload="initialize()">

        <!--- loading animation -->
        <div class="loading">
            <div class="ball"></div>
            <div class="ball1"></div>
        </div>
        <!--- //loading animation -->

        <?php
        $this->load->view('User/Header');
        ?>


        <!--main-->
        <main class="main">
            <div class="wrap">
                <!--breadcrumbs-->
                <nav class="breadcrumbs">
                    <!--crumbs-->
                    <ul>
                        <li><a href="<?php echo base_url(); ?>" title="Home">Home</a></li> 
                        <li>Feedback</li>                                       
                    </ul>
                    <!--//crumbs-->
                </nav>
                <div class="row">
                    <div class="col-md-6">
                        <img src="<?php echo base_url(); ?>Assets/images/feed.png"style="width: 500px; height: 450px; padding-top: 90px;  ">
                    </div>
                    <div  class="col-md-6">
                        <div class="imagebg ">
                            <div class="form-container" style="margin-top: 0px;background : whitesmoke;padding: 40px;">
                                <form method="post" action="" name="Feedback" class="" novalidate="">
                                    <h2 class="text-center" style="text-align: left;font-size: 30px"> Feedback </h2>
                                    <div class="row">
                                        <div class="form-group">
                                            <label for="name">
                                                Your Name :
                                            </label>
                                            <input type="text" id="name" name="Name" check_control="alpha" required autofocus="" value="<?Php
                                            if (!isset($success) && set_value('Name')) {
                                                echo set_value("Name");
                                            } else if ($this->session->userdata('user')) {
                                                $user = $this->md->my_select('tbl_register', 'name', array('email' => $this->session->userdata('user')));
                                                echo $user[0]->name;
                                            }
                                            ?>" <?php
                                                   if ($this->session->userdata('user')) {
                                                       echo 'readonly';
                                                       ?> title="readonly"<?php } ?>/>
                                            <div class="error">
                                                <?php
                                                if (form_error('Name')) {
                                                    echo form_error("Name");
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group">
                                            <label for="email">
                                                Email :
                                            </label>
                                            <input type="email" id="email" check_control="email" name="Email" required value="<?Php
                                            if (!isset($success) && set_value('Email')) {
                                                echo set_value("Email");
                                            } else if ($this->session->userdata('user')) {
                                                echo $this->session->userdata('user');
                                            }
                                            ?>" <?php
                                                   if ($this->session->userdata('user')) {
                                                       echo 'readonly';
                                                       ?> title="readonly"<?php } ?>/>
                                            <div class="error">
                                                <?php
                                                if (form_error('Email')) {
                                                    echo form_error("Email");
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group">
                                            <label for="comments">
                                                Comments:</label>
                                            <textarea type="textarea" name="msg" placeholder="Your Comments" maxlength="6000" rows="7"><?Php
                                                if (!isset($success) && set_value('msg')) {
                                                    echo set_value("msg");
                                                }
                                                ?></textarea>
                                            <div class="error">
                                                <?php
                                                if (form_error('msg')) {
                                                    echo form_error("msg");
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="form-group">
                                            <input type="submit" name="add" value="send Your Feedback" class="button-gradient"/>
                                        </div>
                                    </div>
                                    <?php
                                    if (isset($success)) {
                                        ?>
                                        <div class="my_alert_success animated bounceInLeft">
                                            <p>
                                                <i class="fa fa-check-circle" aria-hidden="true"></i>
                                                <b><small><?php echo $success; ?></small></b>
                                            </p>
                                        </div>
                                        <?php
                                    }
                                    if (isset($error)) {
                                        ?>
                                        <div class="my_alert animated bounceInRight">
                                            <p>
                                                <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                                                <b><small><?php echo $error; ?></small></b>
                                            </p>
                                        </div>
                                        <?php
                                    }
                                    ?>
                                </form>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
        </main>
        <!--//main-->
        <?php
        $this->load->view('User/Footer');
        ?>
        <?php
        $this->load->view('User/Footer_Script');
        ?>
    </body>

</html>