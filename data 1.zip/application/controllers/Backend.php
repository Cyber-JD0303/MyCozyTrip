<?php

class Backend extends CI_Controller {

    public function subscribe_email() {
        $wh['email'] = $this->input->post('email');
        $count = count($this->md->my_select("tbl_email", "*", $wh));
        if ($count == 0) {
            echo $this->md->my_insert('tbl_email', $wh);
        } else {
            echo '2';
        }
    }

    public function index() {
        $action = $this->input->post('action_val');
        $id = $this->input->post('id');
        if ($action == 'state') {
            $recordset = $this->md->my_query("select * from tbl_location where parent_id = '$id' and label = '$action' Order By name ASC");
            echo '<option value="">Select State</option>';
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->location_id; ?>"><?php echo $data->name; ?></option>
                <?php
            }
        } elseif ($action == 'city') {
            $recordset = $this->md->my_query("select * from tbl_location where parent_id = '$id' and label = '$action' Order By name ASC");
            echo '<option value="">Select City</option>';
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->location_id; ?>"><?php echo $data->name; ?></option>
                <?php
            }
        } elseif ($action == 'hotel') {
            $recordset = $this->md->my_query("select * from tbl_hotel where location_id = '$id' Order By hotel_name ASC");
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->hotel_id; ?>"><?php echo $data->hotel_name; ?></option>
                <?php
            }
        } elseif ($action == 'plane') {
            $recordset = $this->md->my_query("select * from tbl_plane where airlines_id = '$id' Order By plane_name ASC");
            echo '<option value="">Select Plane</option>';
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->plane_id; ?>"><?php echo $data->plane_name; ?></option>
                <?php
            }
        } elseif ($action == 't_state') {
            $recordset = $this->md->my_query("select * from tbl_location where parent_id = '$id' and label = 'state' Order By name ASC");
            echo '<option value="">Select State</option>';
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->location_id; ?>"><?php echo $data->name; ?></option>
                <?php
            }
        } elseif ($action == 't_city') {
            $recordset = $this->md->my_query("select * from tbl_location where parent_id = '$id' and label = 'city' Order By name ASC");
            echo '<option value="">Select City</option>';
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->location_id; ?>"><?php echo $data->name; ?></option>
                <?php
            }
        } elseif ($action == 'Travel') {
            $recordset = $this->md->my_query("select * from tbl_air_schedule where from_location = '$id' and to_location = ".$this->input->post('tid')." Order By schedule_id ASC");
            foreach ($recordset as $data) {
                $plane = $this->md->my_select('tbl_plane', '*', array('plane_id' => $data->plan_id));
                $Airline = $this->md->my_select('tbl_airlines', 'airlines', array('airlines_id' => $plane[0]->airlines_id));
                ?>
                <div class="col-md-4">
                    <div style="padding: 20px;background: #f5f5f5">
                        <label>
                            <input type="radio" name="Air" style="zoom: 1.4;vertical-align: sub" value="<?php echo $data->schedule_id; ?>"/>
                            Select Plane
                        </label>
                        <br />
                        <table>
                            <tr>
                                <th>Plane :&nbsp;&nbsp;</th> 
                                <td><?php echo $plane[0]->plane_name; ?></td> 
                            </tr>
                            <tr>
                                <th>Airline :&nbsp;&nbsp;</th> 
                                <td><?php echo $Airline[0]->airlines; ?></td> 
                            </tr>
                            <tr>
                                <th>Price :&nbsp;&nbsp;</th> 
                                <td><?php echo $data->price; ?></td> 
                            </tr>
                            <tr>
                                <th>From Time :&nbsp;&nbsp;</th> 
                                <td><?php echo $data->from_time; ?></td> 
                            </tr>
                            <tr>
                                <th>To Time :&nbsp;&nbsp;</th> 
                                <td><?php echo $data->to_time; ?></td> 
                            </tr>
                        </table>
                    </div>
                </div>
                <?php
            }
        } elseif ($action == 'error_show') {
            ?>
            <div class="my_alert animated bounceInRight">
                <p>
                    <i class="fa fa-exclamation-triangle" aria-hidden="true"></i>
                    <b><small><?php echo 'You Are Need TO Login First'; ?></small></b>
                </p>
            </div>
            <?php
        } elseif ($action == 'price') {
            $val = $this->input->post('val');
            ?>
            Total Price : &#8377; <?php echo $val * $id; ?>
            <?php
        } elseif ($action == 'hotel_name') {
            $recordset = $this->md->my_query("select * from tbl_hotel where location_id = '$id' Order By hotel_name ASC");
            foreach ($recordset as $data) {
                ?>
                <option value="<?php echo $data->hotel_name; ?>" id="<?php echo $data->hotel_id; ?>">
                    <?php
                }
            } elseif ($action == 'place') {
                $val = "%" . $this->input->post('id') . "%";
                if ($val == "") {
                    $recordset = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id order by ct.name ASC");
                } else {
                    $recordset = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id and ct.name like '" . $val . "' order by ct.name ASC");
                }
                if (sizeof($recordset) != 0) {
                    $c = 0;
                    foreach ($recordset as $data) {
                        $pic = explode(',', $data->photo);
                        ?>
                    <a href="<?php echo base_url(); ?>View_place/<?php echo $data->place_id; ?>">
                        <article class="one-fourth">
                            <figure class="First">
                                <img src="<?php echo base_url(); ?><?php echo $pic[0]; ?>" alt="" style="height: 200px; width: 350px;">
                            </figure>
                            <div class="details" style="height: 60px !important;">
                                <h4><?php echo $data->city; ?></h4>
                            </div>
                        </article>
                    </a>   
                    <?php
                    $c++;
                }
            } else {
                ?>
                <div class="col-md-12">
                    <article class="bookings">
                        <center>
                            <img src="<?php echo base_url() ?>Assets/images/NoRecordFound.png">
                            <h3>Not Any Place At a Time.</h3>
                        </center>
                    </article>
                </div>
                <?php
            }
        } elseif ($action == 'Airport') {
            $val = "%" . $this->input->post('id') . "%";
            if ($val == "") {
                $recordset = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,a.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_airport` AS a WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND a.location_id = ct.location_id order by a.air_name ASC");
            } else {
                $recordset = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,a.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_airport` AS a WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND a.location_id = ct.location_id and a.air_name like '" . $val . "' order by a.air_name ASC");
            }

            if (sizeof($recordset) != 0) {
                foreach ($recordset as $data) {
                    $pic = explode(',', $data->photo);
                    ?>
                    <!--<a href="">-->
                    <article class="one-fourth">
                        <figure>
                            <img src="<?php echo base_url(); ?><?php echo $pic[0]; ?>" alt="" style="height: 200px; width: 350px;">
                        </figure>
                        <div class="details" style="height: 80px !important;">
                            <h4><?php echo $data->air_name; ?></h4>
                        </div>
                    </article>
                    <!--</a>-->   
                    <?php
                }
            } else {
                ?> 
                <div class="col-md-12">
                    <article class="bookings">
                        <center>
                            <img src="<?php echo base_url() ?>Assets/images/NoRecordFound.png">
                            <h3>Not Any Airport At a Time.</h3>
                        </center>
                    </article>
                </div>
                <?php
            }
        } elseif ($action == 'Flight') {
            $val = "%" . $this->input->post('id') . "%";
            if ($val == "") {
                $recordset = $this->md->my_query("SELECT c.name AS From_country, s.name AS From_state, ct.name as From_city,To_c.name AS To_country, To_s.name AS To_state, To_ct.name as To_city,a.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_location` AS To_c, `tbl_location` AS To_s, `tbl_location` AS To_ct,`tbl_air_schedule` AS a WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND a.from_location = ct.location_id AND To_ct.parent_id = To_s.location_id AND To_s.parent_id = To_c.location_id AND a.to_location = To_ct.location_id");
            } else {
                $recordset = $this->md->my_query("SELECT c.name AS From_country, s.name AS From_state, ct.name as From_city,To_c.name AS To_country, To_s.name AS To_state, To_ct.name as To_city,a.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_location` AS To_c, `tbl_location` AS To_s, `tbl_location` AS To_ct,`tbl_air_schedule` AS a WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND a.from_location = ct.location_id AND To_ct.parent_id = To_s.location_id AND To_s.parent_id = To_c.location_id AND a.to_location = To_ct.location_id and To_ct.name like '" . $val . "'");
            }

            if (sizeof($recordset) != 0) {
                foreach ($recordset as $data) {
                    $plane = $this->md->my_select("tbl_plane", "*", array('plane_id' => $data->plan_id));
                    $airline = $this->md->my_select("tbl_airlines", "*", array('airlines_id' => $plane[0]->airlines_id));
                    $f_city = $this->md->my_select("tbl_location", "*", array('location_id' => $data->from_location));
                    $t_city = $this->md->my_select("tbl_location", "*", array('location_id' => $data->to_location));
                    ?>
                    <!--column-->
                    <article class="one-fourth" height="200px">
                        <figure><a href="<?php echo base_url(); ?>View_flight/<?php echo $data->schedule_id; ?>" title=""><img src="<?php echo base_url(); ?><?php echo $airline[0]->photo; ?>" alt="" style="height : 200px !important;width: 300px;"/></a></figure>
                        <div class="details">
                            <a href="<?php echo base_url(); ?>View_flight/<?php echo $data->schedule_id; ?>" title="View all" class="gradient-button">View all</a>
                            <h4><?php echo $airline[0]->airlines; ?></h4>
                            <span class="count">&#8377;<?php echo $data->price; ?></span>
                            <div class="ribbon">
                                <div class="half flight">
                                    <a title="From Time">
                                        <span class="small">From Time</span>
                                        <span class="price"><?php echo date('g:i a', strtotime($data->from_time)); ?></span>
                                    </a>
                                </div>
                                <div class="half flight">
                                    <a title="To Time">
                                        <span class="small">To Time</span>
                                        <span class="price"><?php echo date('g:i a', strtotime($data->to_time)); ?></span>
                                    </a>
                                </div>
                            </div>
                            <div class="ribbon">
                                <div class="half flight">
                                    <a title="From Place">
                                        <span class="small">From</span>
                                        <span class="price"><?php echo $f_city[0]->name; ?></span>
                                    </a>
                                </div>
                                <div class="half flight">
                                    <a title="To Place">
                                        <span class="small">To</span>
                                        <span class="price"><?php echo $t_city[0]->name; ?></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </article>
                    <!--//column-->
                    <?php
                }
            } else {
                ?> 
                <div class="col-md-12">
                    <article class="bookings">
                        <center>
                            <img src="<?php echo base_url() ?>Assets/images/NoRecordFound.png">
                            <h3>Not Any Airport At a Time.</h3>
                        </center>
                    </article>
                </div>
                <?php
            }
        }
    }

    public function package() {
        $wh['email'] = $this->session->userdata('agent');
        $ins['package_id'] = $this->input->post('id');
        $this->md->my_update('tbl_agent', $ins, $wh);
    }

    public function Bill1() {
        $view = $this->md->my_select('tbl_booking', '*', array('booking_id' => $this->input->post('id')));
        $package = $this->md->my_select('tbl_trip_package', '*', array('package_id' => $view[0]->package_id));
        $agent = $this->md->my_select('tbl_agent', '*', array('agent_id' => $package[0]->agent_id));
        $f_city = $this->md->my_select('tbl_location', '*', array('location_id' => $package[0]->From_location));
        $t_city = $this->md->my_select('tbl_location', '*', array('location_id' => $package[0]->To_location));
        ?>
        <div class="row" style="margin : 0px !important;">
            <div class="col-md-6">
                <div class="logo">
                    <a href="" title="Book Your Travel">
                        <img src="<?php echo base_url(); ?>Assets/images/txt/logo.png" alt="Book Your Travel" />
                    </a>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact"  >
                    <p class="" style="padding: 15px; ">
                        <span  style="padding-left: 30px;">24/7 Support number</span>
                        <span  style="padding-left: 30px;" class="number"><a style="color: #A58585 !important;">+91 8980776898</a></span>
                    </p>
                </div>
                <!--//contact-->

                <!--Email-->
                <div class="contact"> 
                    <p class="" style="padding: 15px;  ">
                        <span style="padding-left: 30px;">Email</span>
                        <span style="padding-left: 30px; color: #B8ADA8 !important;"><a style="color: #A58585 !important;">mycozytrip@gmail.com</a></span>
                    </p>
                </div>
            </div>
            <hr/> 
            <div align="right">
                <h1 style="margin-bottom: 20px !important;padding : 20px 0 20px 0 !important;font-weight: bolder"><font style="color: #0277b7;">TOURS AND</font> TRAVEL INVOICE</h1>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <table width="100%" border="1" class="table table-striped">
                        <tr>
                            <td class="heder" style="background-color: #0277b7;color: #fff;" colspan="2">
                                <div align="center">
                                    <strong style="font-size: 25px;">TO</strong>
                                </div>
                            </td>
                        </tr>
                        <tr style="border: none;">
                            <td style="text-align: center;" colspan="2"><h3 style="font-size: 20px;margin-top: 10px !important;  "><?php echo $agent[0]->company_name; ?></h3></td>
                        </tr>
                        <tr style="border: none;">
                            <th colspan="2" >A : 
                                <p style="display: inline-block"><?php echo $agent[0]->address; ?></p>
                            </th>
                        </tr>
                        <tr style="border: none;">
                            <th>P : 
                                <p style="display: inline-block"><?php echo $agent[0]->phone; ?></p>
                            </th>
                            <th>M : <p style="display: inline-block"><?php echo $agent[0]->email; ?></p></th>
                        </tr>
                    </table>
                </div>
                <div class="col-md-3">
                    <table width="50%" border="1">
                        <tr>
                            <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>DATE</strong></div></td>
                        </tr>
                        <tr>
                            <td> 
                                <div style="margin: 5px !important; text-align: center;"><center><h3 style=" font-size: 30px !important;"><?php echo date('d/M/Y', strtotime($view[0]->booked_date)); ?></h3></center></div> 
                            </td>
                        </tr>
                    </table>
                </div>
                <div class="col-md-3" style="padding-left: 25px !important;">
                    <table width="50%" border="1">
                        <tr>
                            <td  class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>INVOICE</strong></div></td>
                        </tr>
                        <tr>
                            <td>
                                <div style="margin: 5px !important; text-align: center;"><center><h3 style=" font-size: 30px !important;"><?php echo $view[0]->booking_id; ?></h3></center></div> 
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
            <div>
                <h3><p style="text-align: center;margin-bottom: 20px;"><font style="color: #0277b7;font-weight: bold;">Travel</font> Details</p></h3>
            </div>
            <table width="100%" border="1" class="table table-striped">
                <tr>
                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Source-Destination</strong></div></td>
                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Travelling Date </strong></div></td>
                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>No.of Travelers </strong></div></td>
                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong>Charges</strong></div></td>
                </tr>
                <tr>
                    <td align="center"><?php echo $f_city[0]->name; ?> - <?php echo $t_city[0]->name; ?></td>
                    <td align="center"><?php echo date('d/M/Y', strtotime($view[0]->booked_date)); ?></td>
                    <td><div align="center"><?php echo $view[0]->person; ?></div></td>
                    <td><div align="center" style="color: #0277b7; font-weight: bold;">&#8377; <?php echo $package[0]->price; ?></div></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="2" rowspan="2"></td>
                    <td style="font-weight: bold;color: #666; padding-left: 20px;">Sub Total</td>
                    <td>
                        <div align="" style="color: #0277b7; font-weight: bold;">
                            <table>
                                <tr>
                                    <td><p style="float : right; display: inline-block;">&#8377; <?php echo $package[0]->price; ?> </p></td>
                                </tr>
                                <tr>
                                    <td> * <p style="float : right; display: inline-block;"><?php echo $view[0]->person; ?> </p></td>
                                </tr>
                                <tr>
                                    <td>= <p style="float : right; display: inline-block;">&#8377; <?php echo $view[0]->amount; ?> </p></td>
                                </tr>
                            </table>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="font-weight: bold;color: #666; padding-left: 20px;">Tax <p style="display: inline-block;float: right;padding-right: 20px;margin: 0px 0px 5px !important;color: #0277b7;">8.5%</p></td>
                    <td><div align="center" style="color: #0277b7; font-weight: bold;">&#8377; 00</div></td>
                </tr>
                <tr>
                    <td class="heder" style="background-color: #0277b7;color: #fff;font-weight: bold;text-align: center">Payment Method</td>
                    <td></td>
                    <td class="heder" style="background-color: #0277b7;color: #fff;font-weight: bold;"><div align="center">Total Charges </div></td>
                    <td style="color: #fff; font-weight: bold;background-color: #3b3b1f;"><div align="center">&#8377; <?php echo $view[0]->amount; ?></div></td>
                </tr>
            </table>
            <div class="row">
                <div class="col-md-4">
                    <table width="30%" class="table table-striped">
                        <tr>
                            <th>Bank name </th>
                            <td>:&nbsp;&nbsp; Your Bank Name </td>
                        </tr>
                        <tr>
                            <th>Account No </th>
                            <td>:&nbsp;&nbsp; 33658224</td>
                        </tr>
                        <tr>
                            <th>IFSC Code </th>
                            <td>:&nbsp;&nbsp; RJF0214517</td>
                        </tr>
                    </table>
                </div>
            </div>
            <hr align="right" width="15%"  style="size:30%;"/>
            <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
            <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
            <table border="1" style="width: 100%;" class="table table-striped">
                <tr>
                    <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong><span style="color: #FFFFFF">T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
                </tr>
                <tr>
                    <td bgcolor="#333333"> 
                        <div class="row" style="color: #777;font-weight: bold;">
                            <span class="col-md-4" style="text-align: left;">   <b style="color:black"> A: &nbsp;</b> <p style="display: inline;"><?php echo $agent[0]->address; ?></p></span>
                            <span class="col-md-4" style="text-align: center;"> <b style="color:black"> P: &nbsp;</b> <p style="display: inline"><?php echo $agent[0]->phone; ?></p></span>
                            <span class="col-md-4" style="text-align: right;">  <b style="color:black"> E: &nbsp;</b> <p style="display: inline"><?php echo $agent[0]->email; ?></p></span>
                        </div>
                    </td>
                </tr>
            </table>    
        </div>
        <?php
    }

    public function Bill2() {
        $view = $this->md->my_select('tbl_hotel_book', '*', array('booking_id' => $this->input->post('id')));
        $hotel = $this->md->my_select('tbl_hotel', '*', array('hotel_id' => $view[0]->hotel_id));
        $agent = $this->md->my_select('tbl_agent', '*', array('agent_id' => $hotel[0]->agent_id));
        $user = $this->md->my_select('tbl_register', '*', array('Rid' => $view[0]->Rid));
        $city = $this->md->my_select('tbl_location', '*', array('location_id' => $user[0]->location_id));
        ?>
        <div class="row" style="margin : 0px !important;">
            <div class="col-md-8">
                <span>
                    <h1><label><?php echo $hotel[0]->hotel_name; ?></label></h1>
                </span>
                <div align="left">
                    <?php echo $hotel[0]->address; ?><br />
                    <?php echo $hotel[0]->contact; ?><br />
                    <?php echo $hotel[0]->website; ?><br />
                </div>
            </div>
            <div class="col-md-4">
                <div align="right" style="margin-top: 20px;margin-bottom: 10px;">
                    <h3><label style="background: #777;color: #fff;padding: 20px;text-transform: uppercase;">Hotel Invoice</label></h3>
                    <table width="50%" align="right">
                        <tr>
                            <td>Invoice No </td>
                            <td> : <?php echo $view[0]->booking_id; ?></td>
                        </tr>
                        <tr>
                            <td>Date </td>
                            <td> : <?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                        </tr>
                    </table>
                </div>
            </div>    
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6">
                <table width="100%" class="table table-striped">
                    <tr>
                        <th colspan="2"><h2 align="center">Bill To </h2> </th>
                    </tr>
                    <tr>
                        <td>Name</td>
                        <td class="border"><?php echo $user[0]->name; ?></td>
                    </tr>
                    <tr>
                        <td>City</td>
                        <td class="border"><?php echo $city[0]->name; ?></td>
                    </tr>
                    <tr>
                        <td>Phone NO</td>
                        <td class="border"><?php echo $user[0]->phone; ?></td>
                    </tr>
                    <tr>
                        <td>email</td>
                        <td class="border"><?php echo $user[0]->email; ?></td>
                    </tr>
                    <tr>
                        <td></td>
                        <td class="border">&nbsp;</td>
                    </tr>
                    <tr>
                        <td></td>
                        <td class="border">&nbsp;</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-6">
                <table width="100%" class="table table-striped">
                    <tr>
                        <th colspan="2"><h2 align="center">Other Information</h2> </th>
                    </tr>
                    <tr>
                        <td>Check In Date </td>
                        <td class="border"><?php echo date('d/M/Y', strtotime($view[0]->checking_date)); ?></td>
                    </tr>
                    <tr>
                        <td>Check Out Date </td>
                        <td class="border"><?php echo date('d/M/Y', strtotime($view[0]->checkout_date)); ?></td>
                    </tr>
                    <tr>
                        <td>No Of days</td>
                        <td class="border"><?php echo $view[0]->numberday; ?></td>
                    </tr>
                    <tr>
                        <td>Rate Par Day</td>
                        <td class="border">&#8377; <?php echo $hotel[0]->price; ?></td>
                    </tr>
                    <tr>
                        <td>No of Person</td>
                        <td class="border"><?php echo $view[0]->person; ?></td>
                    </tr>
                    <tr>
                        <td>No Of Room  </td>
                        <td class="border"><?php echo $view[0]->Room; ?></td>
                    </tr>
                </table>
            </div>
        </div>
        <div style="padding-top: 20px;">
            <table width="100%" border="1" class="table table-striped">
                <tr>
                    <th class="style4">Sales Rep. Name</th>
                    <th class="style4">Address</th>
                    <th class="style4">pincode</th>
                    <th class="style4">Due Date</th>
                </tr>
                <tr>
                    <td><?php echo $agent[0]->company_name; ?></td>
                    <td><?php echo $agent[0]->address; ?></td>
                    <td><?php echo $agent[0]->pincode; ?></td>
                    <td><?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                </tr>
            </table>
        </div>
        <div style="padding-top: 20px;">
            <table width="100%" border="1" class="table table-striped">
                <tr>
                    <th class="style4">No Of Room</th>
                    <th class="style4">Name</th>
                    <th class="style4">Check In Date</th>
                    <th class="style4">Check out Date</th>
                    <th class="style4">AMOUNT</th>
                    <th class="style4">TOTAL</th>
                </tr>
                <tr>
                    <td><?php echo $view[0]->Room; ?></td>
                    <td><?php echo $user[0]->name; ?></td>
                    <td><?php echo date('d/M/Y', strtotime($view[0]->checking_date)); ?></td>
                    <td><?php echo date('d/M/Y', strtotime($view[0]->checkout_date)); ?></td>
                    <td>&#8377;<?php echo $hotel[0]->price; ?></td>
                    <td>&#8377;<?php echo $view[0]->amount; ?></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                    <td>&nbsp;</td>
                </tr>
                <tr>
                    <th colspan="5" style="text-align: right;">Sub Total</th>
                    <td>
                        <div style="font-weight: bold;">
                            <table>
                                <tr>
                                    <td>  <p style="float : right; display: inline-block;">&#8377; <?php echo $hotel[0]->price; ?> </p></td>
                                </tr>
                                <tr>
                                    <td> * <p style="float: right;display: inline-block;"><?php echo $view[0]->Room; ?> </p></td>
                                </tr>
                                <tr style="border-top: 0.5px black solid;">
                                    <td> = <p style="float : right; display: inline-block;">&#8377; <?php echo $view[0]->amount; ?> </p></td>
                                </tr>
                            </table>
                        </div>
                    </td>
                </tr>
                <tr>
                    <th colspan="5" style="text-align: right"><p style="display: inline-block;padding-right: 50px;">GST</p><p style="display: inline-block;">8.5%</p></th>
                    <td>&#8377; 0</td>
                </tr>
                <tr>
                    <th colspan="5"><div align="right">Total</div></th>
                    <td class="style4">&#8377; <?php echo $view[0]->amount; ?></td>
                </tr>
            </table>
        </div>
        <hr align="right" width="15%"  style="size:30%;"/>
        <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
        <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
        <table border="1" style="width: 100%;" class="table table-striped">
            <tr>
                <td  class="style4"><div align="center"><strong><span>T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
            </tr>
        </table>         
        <?php
    }

    public function Bill3() {
        $view = $this->md->my_select('tbl_flight_book', '*', array('flightbook_id' => $this->input->post('id')));
        $flight_detail = $this->md->my_select("tbl_air_schedule", "*", array('schedule_id' => $view[0]->schedule_id));
        $t_city = $this->md->my_select("tbl_location", "*", array('location_id' => $flight_detail[0]->to_location));
        $f_city = $this->md->my_select("tbl_location", "*", array('location_id' => $flight_detail[0]->from_location));
        $plane = $this->md->my_select("tbl_plane", "*", array('plane_id' => $flight_detail[0]->plan_id));
        $airline = $this->md->my_select("tbl_airlines", "*", array('airlines_id' => $plane[0]->airlines_id));
        $user = $this->md->my_select("tbl_register", "*", array('Rid' => $view[0]->Rid));
        $city = $this->md->my_select("tbl_location", "*", array('location_id' => $user[0]->location_id));
        if ($flight_detail[0]->class == '1') {
            $class = 'Business Class';
        } else if ($flight_detail[0]->class == '2') {
            $class = 'Economy Class';
        } else if ($flight_detail[0]->class == '3') {
            $class = 'First Class';
        }
        ?>
        <div class="container-fluid">
            <div class="row" style="margin : 0px !important;">
                <div class="col-md-6">
                    <div class="logo">
                        <a href="" title="MycozyTrip">
                            <img src="<?php echo base_url(); ?>Assets/images/txt/logo.png" alt="Book Your Travel" />
                        </a>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="contact"  >
                        <p class="" style="padding: 15px; ">
                            <span  style="padding-left: 30px;">24/7 Support number</span>
                            <span  style="padding-left: 30px;" class="number"><a style="color: #A58585 !important;">+91 8980776898</a></span>
                        </p>
                    </div>
                    <!--//contact-->

                    <!--Email-->
                    <div class="contact"> 
                        <p class="" style="padding: 15px;">
                            <span style="padding-left: 30px;">Email</span>
                            <span style="padding-left: 30px; color: #B8ADA8 !important;"><a style="color: #A58585 !important;">mycozytrip@gmail.com</a></span>
                        </p>
                    </div>
                </div>
                <hr/> 
                <div class="row" style="margin : 0px !important;">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="logo" style="padding-top: 5px !important;">
                                <table style="border: none !important;margin-bottom: 0px !important;">
                                    <tr>
                                        <td style="padding: 5px !important;border: none !important;">
                                            <label>Invoice No &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
                                        </td>
                                        <td style="padding: 5px !important;border: none !important;padding-top: 0px !important;">
                                            <?php echo $view[0]->booking_id; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;border: none !important;">
                                            <label>Booking Date &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</label>
                                        </td>
                                        <td style="padding: 5px !important;border: none !important;padding-top: 0px !important;">
                                            <?php echo date('d/m/Y', strtotime($view[0]->book_date)); ?>
                                        </td>
                                    </tr>
                                </table>

                            </div>
                        </div>
                        <div class="col-md-6" style="margin: -15px -10px !important;">
                            <div class="contact">
                                <div align="center"><strong style="padding: 15px;font-size: 30px;background-color: #0277b7;color: #fff;">INVOICE</strong></div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table style="border: none !important;">
                                <tr style="text-transform: uppercase;">
                                    <th>Bill TO</th>
                                </tr>
                                <tr>
                                    <td style="border-bottom: none !important;border-top: none !important;padding-bottom: 0px !important;"><?php echo $user[0]->name; ?></td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: none !important;border-top: none !important;padding: 0px 13px !important;"><?php echo $user[0]->email; ?></td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: none !important;border-top: none !important;padding: 0px 13px !important;"><?php echo $user[0]->phone; ?></td>
                                </tr>
                                <tr>
                                    <td style="border-top: none !important;padding: 0px 13px 10px 13px !important;"><?php echo $city[0]->name; ?></td>
                                </tr>
                            </table>
                            <table class="table table-striped">
                                <tr style="text-transform: uppercase;">
                                    <th colspan="2" style="text-align: center;">Passenger List</th>
                                </tr>
                                <tr>
                                    <th>Name</th>
                                    <th>Age</th>
                                </tr>
                                <tr>
                                    <td>Dobariya Jemish</td>
                                    <td>20 Year</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table style="border: none !important;margin-bottom: 15px !important;">
                                <tr style="text-transform: uppercase;">
                                    <th>Airline</th>
                                    <th>Destination City</th>
                                    <th>Plane No</th>
                                    <th>Booking Date</th>
                                </tr>
                                <tr>
                                    <td><?php echo $airline[0]->airlines; ?></td>
                                    <td><?php echo $t_city[0]->name; ?></td>
                                    <td><?php echo $plane[0]->plane_name; ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($view[0]->book_date)); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <table>
                                <tr style="text-transform: uppercase;font-weight: bold;">
                                    <th style="padding: 5px !important;border: none !important;">From</th>
                                    <th style="padding: 5px !important;border: none !important;">To</th>
                                    <th style="padding: 5px !important;border: none !important;">Date</th>
                                    <th style="padding: 5px !important;border: none !important;">Class</th>
                                    <th style="padding: 5px !important;border: none !important;">Dep. Time</th>
                                    <th style="padding: 5px !important;border: none !important;">Arr. Time</th>
                                </tr>
                                <tr>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo $f_city[0]->name; ?></td>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo $t_city[0]->name; ?></td>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo date('d/M/Y', strtotime($view[0]->book_date)); ?></td>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo $class; ?></td>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo date('g:i a', strtotime($flight_detail[0]->from_time)); ?></td>
                                    <td style="padding: 5px !important;border: none !important;"><?php echo date('g:i a', strtotime($flight_detail[0]->to_time)); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>
                <hr align="right" width="15%"  style="size:30%;"/>
                <div align="right" style="margin-right:10px;color: #0277b7;">( S I G N A T U R E )</div>
                <p align="center"  style="color: #00FFFF; font-weight: bold;">&nbsp;</p>
                <table border="1" style="width: 100%;" class="table table-striped">
                    <tr>
                        <td class="heder" style="background-color: #0277b7;color: #fff;"><div align="center"><strong><span style="color: #FFFFFF">T h a n k &nbsp;&nbsp;&nbsp; Y o u ! </span></strong></div></td>
                    </tr>
                </table>    
            </div>
        </div>       
        <?php
    }

    public function Details() {
        if ($this->input->post('action') == 'User') {
            $user = $this->md->my_select('tbl_register', '*', array('Rid' => $this->input->post('id')))[0];
            ?>
            <div class="modal-dialog modal-md" style="width: 650px !important;" role="document">
                <div class="modal-content"  style="padding: 20px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">User Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo base_url() ?><?php echo $user->profile; ?>"/>
                            </div>
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label">Name</label></td>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label">Email</label></td>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->email; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label">Phone No</label></td>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->phone; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label">Gender</label></td>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->gender; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label">Birth date</label></td>
                                        <td style="padding: 10px 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->dob; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label>Country : </label>
                                <label>India</label>
                            </div>
                            <div class="col-md-4">
                                <label>State : </label>
                                <label>Gujarat</label>
                            </div>
                            <div class="col-md-4">
                                <label>City : </label>
                                <label>Surat</label>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'Agent') {
            $agent = $this->md->my_select('tbl_agent', '*', array('agent_id' => $this->input->post('id')))[0];
            if ($agent->location_id != 0) {
                $city = $this->md->my_select('tbl_location', '*', array('location_id' => $agent->location_id))[0];
                $state = $this->md->my_select('tbl_location', '*', array('location_id' => $city->parent_id))[0];
                $country = $this->md->my_select('tbl_location', '*', array('location_id' => $state->parent_id))[0];
                $c = $city->name;
                $s = $state->name;
                $co = $country->name;
            } else {
                $c = '-';
                $s = '-';
                $co = '-';
            }
            ?>
            <div class="modal-dialog modal-md"  role="document">
                <div class="modal-content"  style="padding: 20px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Agent Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo base_url() ?><?php echo $agent->profile_pic; ?>" width="200px"/>
                            </div>
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $agent->company_name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Email</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $agent->email; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Phone No</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $agent->phone; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Pincode</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $agent->pincode; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Address</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $agent->address; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <label>Country : </label>
                                <label><?php echo $co; ?></label>
                            </div>
                            <div class="col-md-4">
                                <label>State : </label>
                                <label><?php echo $s; ?></label>
                            </div>
                            <div class="col-md-4">
                                <label>City : </label>
                                <label><?php echo $c; ?></label>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'Airport') {
            $Airport = $this->md->my_select('tbl_airport', '*', array('air_id' => $this->input->post('id')))[0];
            $city = $this->md->my_select('tbl_location', '*', array('location_id' => $Airport->location_id))[0];
            $state = $this->md->my_select('tbl_location', '*', array('location_id' => $city->parent_id))[0];
            $country = $this->md->my_select('tbl_location', '*', array('location_id' => $state->parent_id))[0];
            ?>
            <div class="modal-dialog modal-md"  role="document">
                <div class="modal-content"  style="padding: 20px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Airport Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <img src="<?php echo base_url() ?><?php echo $Airport->photo; ?>" width="250px"/>
                            </div>
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Airport Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $Airport->air_name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Country</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $country->name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">State</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $state->name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">City</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $city->name; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'plane') {
            $plane = $this->md->my_select('tbl_plane', '*', array('plane_id' => $this->input->post('id')))[0];
            $airline = $this->md->my_select("tbl_airlines", "* ", array('airlines_id' => $plane->airlines_id))[0];
            ?>
            <div class="modal-dialog modal-md" style="width: 750px !important;" role="document">
                <div class="modal-content"  style="padding: 20px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Plane Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4">
                                <img src="<?php echo base_url() ?><?php echo $airline->photo; ?>" width="250px"/>
                            </div>
                            <div class="col-md-8">
                                <table>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Plane Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $plane->plane_name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Airline Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $airline->airlines; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Pattern</label></td>
                                        <td style="padding: 5px !important;word-wrap: break-word"><label for="recipient-name" class="control-label"><?php echo substr($plane->pattern, 0, 60); ?><br><?php echo substr($plane->pattern, 60, 120); ?><br><?php echo substr($plane->pattern, 120, 180); ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'Flight') {
            $book = $this->md->my_select('tbl_flight_book', '*', array('flightbook_id' => $this->input->post('id')))[0];
            $user = $this->md->my_select('tbl_register', '*', array('Rid' => $book->Rid))[0];
            $flight = $this->md->my_select('tbl_air_schedule', '*', array('schedule_id' => $book->schedule_id))[0];
            $plane = $this->md->my_select('tbl_plane', '*', array('plane_id' => $flight->plan_id))[0];
            $airline = $this->md->my_select('tbl_airlines', '*', array('airlines_id' => $plane->airlines_id))[0];
            ?>
            <div class="modal-dialog modal-md" style="width: 750px !important;" role="document">
                <div class="modal-content"  style="padding: 20px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Flight Booking Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <th colspan="2" style="text-align: center;">
                                            User Information
                                        </th>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Email</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->email; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Phone No</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $user->phone; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Booking Date</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo date('d-m-Y', strtotime($book->book_date)); ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Amount</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $book->amount; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <table>
                                    <tr>
                                        <th colspan="2" style="text-align: center;">
                                            Flight Information
                                        </th>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Plane Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $plane->plane_name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Airline Name</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $airline->airlines;?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Flight Price</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $flight->price; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Person</label></td>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label"><?php echo $book->person; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'Place') {
            $place = $this->md->my_select('tbl_place', '*', array('place_id' => $this->input->post('id')))[0];
            $city = $this->md->my_select('tbl_location', '*', array('location_id' => $place->name))[0];
            ?>
            <div class="modal-dialog modal-md" role="document" style="margin-top: 70px;">
                <div class="modal-content"  style="padding: 30px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Place Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12">
                                <table>
                                    <tr>
                                        <th colspan="2" style="text-align: center;">
                                            Place Information
                                        </th>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Place Name</label></td>
                                        <td style="padding: 5px !important;text-align: center;"><label for="recipient-name" class="control-label"><?php echo $city->name; ?></label></td>
                                    </tr>
                                    <tr>
                                        <td style="padding: 5px !important;"><label for="recipient-name" class="control-label">Description</label></td>
                                        <td style="padding: 5px !important;text-align: justify;"><label for="recipient-name" class="control-label"><?php echo $place->description; ?></label></td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>                      
                </div>
            </div>
            <?php
        } else if ($this->input->post('action') == 'package') {
            $package_detail = $this->md->my_select("tbl_trip_package", "*", array('package_id' => $this->input->post('id')));
            $place = $this->md->my_select("tbl_place", "*", array('name' => $package_detail[0]->To_location));
            $agent = $this->md->my_select("tbl_agent", "*", array('agent_id' => $package_detail[0]->agent_id));
            $f_city = $this->md->my_select("tbl_location", "*", array('location_id' => $package_detail[0]->From_location));
            $t_city = $this->md->my_select("tbl_location", "*", array('location_id' => $package_detail[0]->To_location));
            $h = explode(',', $package_detail[0]->hotel_id);
            $hotel = $this->md->my_select("tbl_hotel", "*", array('hotel_id' => $h[0]));
            ?>
            <div class="modal-dialog modal-md" role="document" style="margin-top: 70px;">
                <div class="modal-content"  style="padding: 30px;">
                    <div class="modal-header">
                        <div class="row">
                            <div class="col-md-11">
                                <h4 class="modal-title" id="exampleModalLabel">Package Information</h4>
                            </div>
                            <div class="col-md-1">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close" style="color:red;"><span aria-hidden="true">&times;</span></button>
                            </div>
                        </div>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-12"  style="text-align: center !important;">
                                <label><?php echo $package_detail[0]->name; ?></label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table style="width: 500px;">
                                    <tr>
                                        <th>From City </th>
                                        <td><?php echo $f_city[0]->name; ?></td>
                                    </tr>
                                    <tr>
                                        <th>To City </th>
                                        <td><?php echo $t_city[0]->name; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Price</th>
                                        <td><?php echo $package_detail[0]->price; ?></td>
                                    </tr>
                                    <tr>
                                        <th>hotel Name</th>
                                        <td><?php echo $hotel[0]->hotel_name; ?></td>
                                    </tr>
                                    <tr>
                                        <th>Travel Type</th>
                                        <td><?php echo $package_detail[0]->travel_type; ?></td>
                                    </tr>
                                    <tr>
                                        <th>description</th>
                                        <td style="text-align: justify;"><?php echo $package_detail[0]->description; ?></td>
                                    </tr>
                                </table>
                            </div>
                        </div>                      
                    </div>
                </div>
                <?php
            }
        }
    }