<?php

Class Authorize extends CI_Controller 
{

    public function __construct() 
    {
        parent::__construct();
        date_default_timezone_set("Asia/Kolkata");
    }

    public function security() 
    {
        if (!$this->session->userdata('admin')) 
        {
            redirect('Admin_Login');
        }
    } 
    
    public function Index() 
    {
        $data = array();
        if ($this->input->post('login')) {
            
            $this->form_validation->set_rules('email', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Email Address."));
            $this->form_validation->set_rules('ps', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Password."));
            if ($this->form_validation->run() == TRUE)
            {
                $wh['email'] = $this->input->post('email');
                $record = $this->md->my_select('tbl_admin', '*', $wh);
		// $ps = $this->encryption->decrypt($record[0]->password);
		// print($ps);
		// exit();
                $count = count($record);
                if ($count == 1) 
                {
                    $ps = $this->encryption->decrypt($record[0]->password);
                    if ($ps == $this->input->post('ps')) 
                    {
                        if ($this->input->post('svp')) {
                            $expire = 60 * 60 * 24 * 3;
                            set_cookie('admin_email', $this->input->post('email'), $expire);
                            set_cookie('admin_pass', $this->input->post('ps'), $expire);
                        } else {
                            if ($this->input->cookie('admin_email')) {
                                set_cookie('admin_email', '', -10);
                                set_cookie('admin_pass', '', -10);
                            }
                        }
                        $email = $record[0]->email;
                        $time = Date('Y-m-d h:i:s');
                        $this->session->set_userdata('admin', $email);
                        $this->session->set_userdata('admin_lastlogin', $time);
                        redirect('Dashboard');
                    }
                    else 
                    {
                        $data['error'] = 'Username Or Password Do Not Match.';
                    }
                } 
                else 
                {
                    $data['error'] = 'Username Or Password Do Not Match.';
                }
            }
        }
        $this->load->view("Admin/Index", $data);
    }

    public function Forgot() 
    {
        $record = $this->md->my_select('tbl_admin', '*');
        $ps = $this->encryption->decrypt($record[0]->password);
        $subject = "Forgot password";
        $message = "Hi admin Your Password is : " . $ps;
        $receiver = 'mycozytrip2020@gmail.com';
        $config = array(
            'protocol' => 'smtp',
            'smtp_host' => 'ssl://smtp.googlemail.com',
            'smtp_port' => 465,
            'smtp_timeout' => '45',
            'smtp_user' => "mycozytrip1994@gmail.com",
            'smtp_pass' => "Mycozy@2020",
            'mailtype' => 'html',
            'charset' => 'iso-8859-1',
            'wordwrap' => TRUE
        );

        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");
        $this->email->set_crlf("\r\n");
        $this->email->from($config['smtp_user']);
        $this->email->to($receiver);
        $this->email->subject($subject);
        $this->email->message(html_entity_decode($message));
        if ($this->email->send()) {
            $this->session->set_userdata('forget','1');
            redirect('Admin_Login');
        }else
        {
            $this->session->set_userdata('forget','2');
            redirect('Admin_Login');
        }
    }

    public function Admin_Setting() 
    {
        $data = array();
        if ($this->input->post('update')) {
            $this->form_validation->set_rules('old_pass', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Old Password."));
            $this->form_validation->set_rules('new_pass', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter New Password."));
            $this->form_validation->set_rules('confirm_pass', '', 'required|matches[new_pass]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Confirm Password.", 'matches' => "<i class='fa fa-info-circle animated flash infinite'></i> Confirm password doesn't match."));
            if ($this->form_validation->run() == TRUE) {
                $wh['email'] = $this->session->userdata('admin');
                $record = $this->md->my_select('tbl_admin', '*', $wh);
                $ops = $this->encryption->decrypt($record[0]->password);
                $ps = $this->input->post('old_pass');
                if ($ps == $ops) {
                    $ins['password'] = $this->encryption->encrypt($this->input->post('confirm_pass'));
                    $result = $this->md->my_update('tbl_admin', $ins, $wh);
                    if ($result == 1) {
                        $expire = 60 * 60 * 24 * 3;
                        set_cookie('admin_pass', $this->input->post('confirm_pass'), $expire);
                        $data["success"] = "Password Change Succesfully.";
                    } else {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                } else {
                    $data["error"] = "Password Doesn't Match.";
                }
            }
        }
        if ($this->input->post('update_profile')) 
        {
            $this->form_validation->set_rules('Photo', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Photo."));
            if ($this->form_validation->run() == TRUE) {
                $wh['email'] = $this->session->userdata('admin');
                $name = "Admin_0";
                $config['upload_path'] = './Admin_Assets/images/user/';
                $config['allowed_types'] = 'jpg|png|jpeg';
                $config['max_size'] = 1024 * 3;
                $config['file_name'] = $name;
                $config['overwrite'] = TRUE;
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                if ($this->upload->do_upload('Photo')) 
                {
                    $ins['profile'] = "Admin_Assets/images/user/" . $this->upload->data('file_name');
                    $result = $this->md->my_update("tbl_admin", $ins,$wh);
                    if ($result == 1) 
                    {
                        $data["success"] = "Profile Photo Change Successfully .";
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong .";
                    }
                }
                else
                {
                    $data['error'] = $this->upload->display_errors();
                }
            }
        }
        $this->load->view("Admin/Admin_Setting", $data);
    }
    
    public function Logout() 
    {
        $data['last_login'] = $this->session->userdata('admin_lastlogin');
        $wh['email'] = $this->session->userdata('admin');
        $this->md->my_update('tbl_admin', $data, $wh);
        $this->session->unset_userdata('admin');
        $this->session->unset_userdata('admin_lastlogin');
        redirect('Admin_Login');
    }
    
    
    public function Dashboard()
    {
        $this->security();
        $data['Country'] = count($this->md->my_select("tbl_location", "*", array("label" => "country")));
        $data['State'] = count($this->md->my_select("tbl_location", "*", array("label" => "state")));
        $data['City'] = count($this->md->my_select("tbl_location", "*", array("label" => "city")));
        $data['Contact'] = count($this->md->my_select("tbl_contact_us", "cid"));
        $data['Feedback'] = count($this->md->my_select("tbl_feedback", "fid"));
        $data['Email'] = count($this->md->my_select("tbl_email", "eid"));
        $data['User'] = count($this->md->my_select("tbl_register", "Rid"));
        $data['Agent'] = count($this->md->my_select("tbl_agent", "agent_id"));
        $data['Banner'] = count($this->md->my_select("tbl_banner", "banner_id"));
        $data['Package'] = count($this->md->my_select("tbl_package", "package_id"));
        $data['Airport'] = count($this->md->my_select("tbl_airport", "air_id"));
        $data['Airline'] = count($this->md->my_select("tbl_airlines", "airlines_id"));
        $data['Plane'] = count($this->md->my_select("tbl_plane", "plane_id"));
        $data['A_user'] = count($this->md->my_select("tbl_register", "Rid", array("status" => 1)));
        $data['D_user'] = count($this->md->my_select("tbl_register", "Rid", array("status" => 0)));
        $data['A_agent'] = count($this->md->my_select("tbl_agent", "agent_id", array("status" => 1)));
        $data['D_agent'] = count($this->md->my_select("tbl_agent", "agent_id", array("status" => 0)));
        $data['F_book'] = count($this->md->my_select("tbl_flight_book", "flightbook_id", array("status" => 'paid')));
        $data['schedule'] = count($this->md->my_select("tbl_air_schedule", "schedule_id"));
        $this->load->view("Admin/Dashboard", $data);
    }

    public function Location_Country() 
    {
        $data = array();
        $this->security();
        if ($this->input->post('add')) {
            $this->form_validation->set_rules("country", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Country Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Country Name."));
            if ($this->form_validation->run() == TRUE) {
                $name = ucwords(strtolower($this->input->post("country")));
                $wh["name"] = $name;
                $wh["label"] = "country";
                $count = count($this->md->my_select("tbl_location", "*", $wh));
                if ($count != 0) {
                    $data["error"] = $name . " Is Already Exist.";
                } else {
                    $data['name'] = $this->input->post('country');
                    $data['parent_id'] = 0;
                    $data['label'] = 'country';
                    $result = $this->md->my_insert("tbl_location", $data);
                    if ($result == 1) {
                        $data["success"] = $name . " Added Successfully.";
                    } else {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $data['view'] = $this->md->my_query("select * from tbl_location where label = 'country' order by `location_id` DESC");
        $this->load->view("Admin/Location_Country", $data);
    }

    public function Location_State()
    {
        $data = array();
        $this->security();
        if ($this->input->post("add")) 
        {
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter State Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid State Name."));
            if ($this->form_validation->run() == TRUE) 
            {
                $name = ucwords(strtolower($this->input->post("state")));
                $wh["name"] = $name;
                $wh["parent_id"] = $this->input->post("country");
                $recordset = $this->md->my_select("tbl_location", "*", $wh);
                $count = count($recordset);
                if ($count != 0) 
                {
                    $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("country")));
                    $data["error"] = $name . " Is Already Exist In " . $recordset[0]->name . ".";
                } 
                else 
                {
                    $data['location_id'] = 0;
                    $data['name'] = $name;
                    $data['parent_id'] = $this->input->post("country");
                    $data['label'] = "state";
                    $result = $this->md->my_insert("tbl_location", $data);
                    if ($result == 1) 
                    {
                        $where["location_id"] = $this->input->post("country");
                        $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("country")));
                        $data["success"] = $name . "Added Successfully In " . $recordset[0]->name . ".";
                    } 
                    else
                    {
                        $data["error"] = "Something Is Wrong.";
                    }
                }
            }
        }
        $data["state_detail"] = $this->md->my_query("select st.name as country,ct.* from tbl_location as st,tbl_location as ct where st.location_id = ct.parent_id and ct.label = 'state' ORDER by st.location_id DESC");
        $this->load->view("Admin/Location_State", $data);
    }

    public function Location_City() 
    {
        $data = array();
        if ($this->input->post("add")) {
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter City Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i> Enter valid City Name."));
            if ($this->form_validation->run() == TRUE) {
                $name = ucwords(strtolower($this->input->post("city")));
                $wh["name"] = $name;
                $wh["parent_id"] = $this->input->post("state");
                $recordset = $this->md->my_select("tbl_location", "*", $wh);
                $count = count($recordset);
                if ($count != 0) {
                    $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("state")));
                    $data["error"] = $name . " Is Already Exist In " . $recordset[0]->name . ".";
                } else {

                    $ins['location_id'] = 0;
                    $ins['name'] = $name;
                    $ins['parent_id'] = $this->input->post("state");
                    $ins['label'] = "city";
                    $result = $this->md->my_insert("tbl_location", $ins);
                    if ($result == 1) {
                        $where["location_id"] = $this->input->post("state");
                        $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("state")));
                        $data["success"] = $name . " Added Successfully In " . $recordset[0]->name . ".";
                    } else {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $data["city_detail"] = $this->md->my_query("SELECT c.name AS country , s.name AS state , ct.* FROM `tbl_location` AS c , `tbl_location` AS s , `tbl_location` AS ct WHERE c.location_id = s.parent_id AND s.location_id = ct.parent_id AND ct.label = 'city' ORDER by ct.location_id DESC");
        $this->load->view("Admin/Location_City", $data);
    }

    public function Manage_Contact() 
    {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_query("select * from tbl_contact_us order by cid DESC");
        $this->load->view("Admin/Manage_Contact", $data);
    }

    public function Manage_Feedback() 
    {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_query("select * from tbl_feedback order by fid DESC");
        $this->load->view("Admin/Manage_Feedback", $data);
    }

    public function Manage_Email() 
    {
        $c = 0;
        $data = array();
        $this->security();
        if ($this->input->post('send')) 
        {
            if ($this->input->post('recieve')) 
            {
                if ($this->input->post('subject') != "" && $this->input->post('message') != "") 
                {
                    $title = $this->input->post('subject');
                    $message = $this->input->post('message');
                    $recevier = $this->input->post('recieve');
                    foreach ($recevier as $rc) 
                    {
                        $c = $this->md->mailer($title, $message, $rc);
                    }
                    if ($c == 1) 
                    {
                        $data['success'] = "message sent successfully.";
                    } 
                    else 
                    {
                        $data['error'] = "something is wrong.";
                    }
                } 
                else 
                {
                    $data['error'] = "Please Enter Title Or Messege.";
                }
            } 
            else 
            {
                $data['error'] = "Please Select Atleast One Receiver.";
            }
        }

        $data['view'] = $this->md->my_select("tbl_email", "*");
        $this->load->view("Admin/Manage_Email", $data);
    }

    public function Manage_Banner() 
    {
        $data = array();
        $this->security();
        if ($this->input->post("add")) 
        {
            $this->form_validation->set_rules('name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Banner Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Banner Name."));
            $this->form_validation->set_rules('Photo', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atlest One banner Photo."));
            if ($this->form_validation->run() == TRUE) 
            {
                $banner_name = ucwords(strtolower($this->input->post("name")));
                $wh["Banner_name"] = $banner_name;
                $count = count($this->md->my_select("tbl_banner", "*", $wh));
                if ($count != 0) 
                {
                    $data["error"] = $banner_name . " Is Already Exist.";
                } 
                else 
                {
                    $result = $this->md->my_query("select max(Banner_id) as mx from tbl_banner");
                    $c = $result[0]->mx;
                    if ($c == "") 
                    {
                        $name = "Banner_0";
                    } else {
                        $name = "Banner_" . $c;
                    }
                    $config['upload_path'] = './Admin_Assets/images/Upload/Banner/';
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    $config['max_size'] = 1024 * 3;
                    $config['file_name'] = $name;
                    $config['overwrite'] = TRUE;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('Photo')) 
                    {
                        $ins['photo'] = "Admin_Assets/images/Upload/Banner/" . $this->upload->data('file_name');
                        $ins['Banner_name'] = $banner_name;
                        $result = $this->md->my_insert("tbl_banner", $ins);
                        if ($result == 1) 
                        {
                            $data["success"] = $banner_name . " Added Successfully .";
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_banner", "*");
        $this->load->view("Admin/Manage_Banner", $data);
    }
    
     public function Manage_Packages()
    {
        $this->security();
        $data = array();
        if ($this->input->post("add")) {
            $this->form_validation->set_rules("package", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Package Name."));
            $this->form_validation->set_rules("duration", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Duration Of Package."));
            $this->form_validation->set_rules("price", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Price Of Package."));
            $this->form_validation->set_rules("description", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Description Of Package."));
            if ($this->form_validation->run() == TRUE) {
                $package = ucwords(strtolower($this->input->post("package")));
                $duration = ucwords(strtolower($this->input->post("duration")));
                $price = ucwords(strtolower($this->input->post("price")));
                $description = ucwords(strtolower($this->input->post("description")));
                $wh["package_name"] = $package;
//                $wh["price"] = $price;
//                $wh["duration"] = $duration;
//                $wh["description"] = $description;
                $count = count($this->md->my_select("tbl_package", "*", $wh));
                if ($count != 0) {
                    $data["error"] = $package . " Is Already Exist.";
                } else {
                    $ins['package_name'] = $package;
                    $ins['duration'] = $duration;
                    $ins['price'] = $price;
                    $ins['description'] = $description;
                    $result = $this->md->my_insert("tbl_package", $ins);
                    if ($result == 1) {
                        $data["success"] = $package . " Added Successfully .";
                    } else {
                        $data["error"] = "Somethis Is Wrong .";
                    }
                }
            }
        }
        $data["package_detail"] = $this->md->my_select("tbl_package", "*");
        $this->load->view("Admin/Manage_Packages", $data);
    }
    
    public function Manage_User() 
    {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_select("tbl_register", "*");
        $this->load->view("Admin/Manage_User", $data);
    }

    public function Active_user() 
    {
        $data = array();
        $this->security();
        $wh['status'] = 1;
        $data['view'] = $this->md->my_select("tbl_register", "*", $wh);
        $this->load->view("Admin/User_active", $data);
    }

    public function Deactive_user() 
    {
        $data = array();
        $this->security();
        $wh['status'] = 0;
        $data['view'] = $this->md->my_select("tbl_register", "*", $wh);
        $this->load->view("Admin/User_deactive", $data);
    }

    public function Manage_Agent() 
    {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_select("tbl_agent", "*");
        $this->load->view("Admin/Manage_Agent", $data);
    }

    public function Active_agent() 
    {
        $data = array();
        $this->security();
        $wh['status'] = 1;
        $data['view'] = $this->md->my_select("tbl_agent", "*", $wh);
        $this->load->view("Admin/Agent_active", $data);
    }

    public function Deactive_agent() 
    {
        $data = array();
        $this->security();
        $wh['status'] = 0;
        $data['view'] = $this->md->my_select("tbl_agent", "*", $wh);
        $this->load->view("Admin/Agent_deactive", $data);
    }
    
    public function Manage_Airport() 
    {
        $data = array();
        $this->security();
        if ($this->input->post('add')) 
        {
//                echo 'hi';die;
            $this->form_validation->set_rules("Airpotname", "", "required|is_unique[tbl_airport.air_name]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Airport.", 'is_unique' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Unique  Airport."));
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) {
            print_r($this->input->post());die;
                $Air_name = ucwords(strtolower($this->input->post("Airpotname")));
                $wh["air_name"] = $Air_name;
                $wh["location_id"] = $this->input->post("city");
                $count = count($this->md->my_select("tbl_airport", "*", $wh));
                if ($count != 0) 
                {
                    $data["error"] = $Air_name . " Is Already Exist.";
                } 
                else 
                {
                    $detail = $this->md->my_query("select max(air_id) as mx from `tbl_airport`");
                    $id = $detail[0]->mx;
                    if ($id == "") 
                    {
                        $name = "Airport_0";
                    } 
                    else 
                    {
                        $name = "Airport_" . $id;
                    }
                    $config['upload_path'] = './Admin_Assets/images/Upload/Airport/';
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    $config['max_size'] = 1024 * 3;
                    $config['file_name'] = $name;
                    $config['overwrite'] = TRUE;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ( $this->upload->do_upload('Photo') ) 
                    {
                        $ins['photo'] = "Admin_Assets/images/Upload/Airport/" . $this->upload->data('file_name');
                        $ins['air_name'] = $Air_name;
                        $ins['location_id'] = $this->input->post('city');
                        $result = $this->md->my_insert("tbl_airport", $ins);
                        if ($result == 1) 
                        {
                            $data["success"] = $this->input->post('Airpotname') . " Added Successfully .";
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                    else 
                    {
                        $data["error"] = $this->upload->display_errors();
                    }
                }
            }
        }
        $data['view'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,ai.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_airport` AS ai WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND ai.location_id = ct.location_id");
        $this->load->view("Admin/Manage_Airport", $data);
    }
    
    public function Manage_Airlines()
    {
        $this->security();
        $data = array();
        if ($this->input->post("add")) 
        {
            $this->form_validation->set_rules('name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Airline Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Airline Name."));
            $this->form_validation->set_rules('Photo', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atlest One Airline Photo."));
            if ($this->form_validation->run() == TRUE) 
            {
                $Airline_name = ucwords(strtolower($this->input->post("name")));
                $wh["airlines"] = $Airline_name;
                $count = count($this->md->my_select("tbl_airlines", "*", $wh));
                if ($count != 0) 
                {
                    $data["error"] = $Airline_name . " Is Already Exist.";
                } 
                else 
                {
                    $result = $this->md->my_query("select max(airlines_id) as mx from tbl_airlines");
                    $c = $result[0]->mx;
                    if ($c == "") {
                        $name = "Airline_0";
                    } else {
                        $name = "Airline_" . $c;
                    }
                    $config['upload_path'] = './Admin_Assets/images/Upload/Airline/';
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    $config['max_size'] = 1024 * 3;
                    $config['file_name'] = $name;
                    $config['overwrite'] = TRUE;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('Photo')) {
                        $ins['photo'] = "Admin_Assets/images/Upload/Airline/" . $this->upload->data('file_name');
                        $ins['airlines'] = $Airline_name;
                        $result = $this->md->my_insert("tbl_airlines", $ins);
                        if ($result == 1) {
                            $data["success"] = $Airline_name . " Added Successfully .";
                        } else {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_airlines", "*");
        $this->load->view("Admin/Manage_Airlines", $data);
    }
    
        public function Manage_Plane()
    {
        $data = array();
        $this->security();
        if ($this->input->post('add')) {
            $this->form_validation->set_rules('Planename', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Plane Name."));
            $this->form_validation->set_rules('Airline', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Airline."));
            $this->form_validation->set_rules('pattern', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Plane pattern."));
            if ($this->form_validation->run() == TRUE) 
            {
                $ins['plane_name'] = $this->input->post('Planename');
                $ins['airlines_id'] = $this->input->post('Airline');
                $ins['pattern'] = $this->input->post('pattern');
                $result = $this->md->my_insert("tbl_plane", $ins);
                if ($result == 1) {
                    $data["success"] = $this->input->post('Planename') . " Added Successfully.";
                } else {
                    $data["error"] = "Somethis Is Wrong.";
                }
            }
        }
        $data["view"] = $this->md->my_select("tbl_plane", "*");
        $this->load->view("Admin/Manage_Plane", $data);
    }
    
    public function Add_Air_schedule() 
    {
        $data = array();
        $this->security();
        if ($this->input->post('add')) 
        {
            $this->form_validation->set_rules('airline', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One airline."));
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('plane', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One plane."));
            $this->form_validation->set_rules('Class', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast Flight Class."));
            $this->form_validation->set_rules("t_country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("t_state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("t_city", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('plane', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One plane."));
            $this->form_validation->set_rules('price', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Filght Price."));
            $this->form_validation->set_rules('ftime', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter plane From Time."));
            $this->form_validation->set_rules('ttime', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter plane To Time."));
            if ($this->form_validation->run() == TRUE) 
            {
                $ins['plan_id']=$this->input->post('plane');
                $ins['from_time']=$this->input->post('ftime');
                $ins['to_time']=$this->input->post('ttime');
                $ins['from_location']=$this->input->post('city');
                $ins['to_location']=$this->input->post('t_city');
                $ins['price']=$this->input->post('price');
                $ins['class']=$this->input->post('Class');
                $result = $this->md->my_insert("tbl_air_schedule", $ins);
                if ($result == 1) 
                {
                    $plane  = $this->md->my_select("tbl_plane",'plane_name',array('plane_id' => $this->input->post('plane')))[0]->plane_name;
                    $data["success"] = $plane . " Added Successfully.";
                } else {
                    $data["error"] = "Somethis Is Wrong.";
                }   
            }
        }
        $this->load->view("Admin/Add_Air_Schedule", $data);
    }

    public function Air_schedule() 
    {
        $data = array();
        $this->security();
        $data['view']=$this->md->my_select("tbl_air_schedule", "*");
        $this->load->view("Admin/Manage_Air_Schedule", $data);
    }
    
    public function flight_Booking() 
    {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_select("tbl_flight_book", "*",array('status'=>'paid'));
        $this->load->view("Admin/flight_Booking",$data);
    }
    
    public function Delete()
    {
        $table = $this->uri->segment(2);
        if ($table == "User") 
        {
            $wh['Rid'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_register", $wh);
            redirect("Manage_User");
        }
        if ($table == "Agent") 
        {
            $wh['agent_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_agent", $wh);
            redirect("Manage_Agent");
        }
        if ($table == "country") 
        {
            $record = $this->md->my_select("tbl_location",'*',array('parent_id'=>$this->uri->segment(3)));
            foreach ($record as $data)
            {
                $this->md->my_delete("tbl_location",array('parent_id'=>$data->location_id));
            }
            $this->md->my_delete("tbl_location",array('parent_id'=>$this->uri->segment(3)));
            $this->md->my_delete("tbl_location", array('location_id'=>$this->uri->segment(3)));
            redirect("Location_Country");
        }
        if ($table == "state") {
            $record = $this->md->my_select("tbl_location",'*',array('parent_id'=>$this->uri->segment(3)));
            foreach ($record as $data)
            {
                $this->md->my_delete("tbl_location",array('location_id'=>$data->location_id));
            }
            $this->md->my_delete("tbl_location", array('location_id'=>$this->uri->segment(3)));
            redirect("Location_State");
        }
        if ($table == "city") 
        {
            $wh['location_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_location", $wh);
            redirect("Location_City");
        }
        if ($table == "contact") 
        {
            $wh['cid'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_contact_us", $wh);
            redirect("Manage_Contact");
        }
        if ($table == "email") 
        {
            $wh['eid'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_email", $wh);
            redirect("Manage_Email");
        }
        if ($table == "feedback") 
        {
            $wh['fid'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_feedback", $wh);
            redirect("Manage_Feedback");
        }
        if ($table == "Package") 
        {
            $wh['Package_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_package", $wh);
            redirect("Manage_Packages");
        }
        if ($table == "Airline") 
        {
            $wh['airlines_id'] = $this->uri->segment(3);
            $photo = $this->md->my_select("tbl_airlines",'*',$wh);
            unlink($photo[0]->photo);
            $this->md->my_delete("tbl_airlines", $wh);
            redirect("Manage_Airlines");
        }
        if ($table == "plane") 
        {
            $wh['plane_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_plane", $wh);
            redirect("Manage_Plane");
        }
        if ($table == "Banner") 
        {
            $wh['Banner_id'] = $this->uri->segment(3);
            $photo = $this->md->my_select("tbl_banner",'*',$wh);
            unlink($photo[0]->photo);
            $this->md->my_delete("tbl_banner", $wh);
            redirect("Manage_Banner");
        }
        if ($table == "Airport") 
        {
            $wh['air_id'] = $this->uri->segment(3);
            $photo = $this->md->my_select("tbl_airport",'*',$wh);
            unlink($photo[0]->photo);
            $this->md->my_delete("tbl_airport", $wh);
            redirect("Manage_Airport");
        }
        if ($table == "schedule") 
        {
            $wh['schedule_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_air_schedule", $wh);
            redirect("Manage_Air_schedule");
        }
    }
}
