<?php
class Edit extends CI_Controller 
{
    public function country() 
    {
        $wh['location_id'] = $this->uri->segment(2);
        $data["country_edit_detail"] = $this->md->my_select("tbl_location", "*", $wh);
        $data["country_detail"] = $this->md->my_select("tbl_location", "*", array("label" => "country"));
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules("country", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter country Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Country Name."));
            if ($this->form_validation->run() == TRUE) 
            {
                $name = ucwords(strtolower($this->input->post("country")));
                $where["name"] = $name;
                $where["label"] = "country";
                $count = count($this->md->my_select("tbl_location", "*", $where));
                if ($count != 0) 
                {
                    $data["error"] = $name." Is Already Exist.";
                }
                else 
                {
                    $ins['name'] = $name;
                    $result = $this->md->my_update("tbl_location", $ins, $wh);
                    if ($result == 1) 
                    {
                        redirect("Location_Country");
                    }
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_location", "*", array("label" => "country"));
        $this->load->view("Admin/Location_Country",$data);
    }

    public function state() 
    {
        $wh['location_id'] = $this->uri->segment(2);
        $data["state_edit_detail"] = $this->md->my_select("tbl_location", "*", $wh);
        $data["state_detail"] = $this->md->my_query("select st.name as country,ct.* from tbl_location as st,tbl_location as ct where st.location_id = ct.parent_id and ct.label = 'state';");
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter State Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter Valid State Name."));
            if ($this->form_validation->run() == TRUE) 
            {
                $name = ucwords(strtolower($this->input->post("state")));
                $where["name"] = $name;
                $where["parent_id"] = $this->input->post("country");
                $recordset = $this->md->my_select("tbl_location", "*", $where);
                $count = count($recordset);
                if ($count != 0) 
                {
                    $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("country")));
                    $data["error"] = $name . " Is Already Exist In " . $recordset[0]->name . ".";
                } 
                else 
                {
                    $ins['name'] = $name;
                    $ins['parent_id'] = $this->input->post("country");
                    $result = $this->md->my_update("tbl_location", $ins, $wh);
                    if ($result == 1) 
                    {
                        redirect("Location_State");
                    }
                    else
                    {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $this->load->view("Admin/Location_State",$data);
    }
    
    public function city()
    {
        $wh['location_id'] = $this->uri->segment(2);
        $data["city_edit_detail"] = $this->md->my_select("tbl_location", "*", $wh);
        $data["city_detail"] = $this->md->my_query("select cn.name as country, st.name as state , ct.location_id,ct.name from tbl_location as cn , tbl_location as st ,tbl_location as ct where ct.parent_id = st.location_id AND st.parent_id = cn.location_id;");
        if ($this->input->post("update")) {
            
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One state."));
            $this->form_validation->set_rules("city", "", "required|regex_match[/^[A-Za-z ]+$/]", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter City Name.", "regex_match" => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid City Name."));
            if ($this->form_validation->run() == TRUE) 
            {
                $name = ucwords(strtolower($this->input->post("city")));
                $where["name"] = $name;
                $where["parent_id"] = $this->input->post("state");
                $recordset = $this->md->my_select("tbl_location", "*", $where);
                $count = count($recordset);
                if ($count != 0) {
                    $recordset = $this->md->my_select("tbl_location", "*", array("location_id" => $this->input->post("state")));
                    $data["error"] = $name . " Is Already Exist In " . $recordset[0]->name . ".";
                } else {
                    $ins['name'] = $name;
                    $ins['parent_id'] = $this->input->post("state");
                    $result = $this->md->my_update("tbl_location", $ins, $wh);
                    if ($result == 1) 
                        {
                        redirect("Location_City");
                    } else {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_location", "*", array("label" => "city"));
        $this->load->view("Admin/Location_City",$data);
    }
    
    public function user()
    {
        $st = $this->uri->segment(2);
        $wh['Rid'] = $this->uri->segment(3);
        if($st==1)
        {
            $ins['status']=0;
            echo $this->md->my_update('tbl_register',$ins,$wh);
            redirect("Active_user");
        }
        else if($st==0)
        {
            $ins['status']=1;
            echo $this->md->my_update('tbl_register',$ins,$wh);
            redirect("Deactive_user");
        }
    }
    
    public function review()
    {
        $st = $this->uri->segment(2);
        $wh['review_id'] = $this->uri->segment(3);
        if($st==1)
        {
            $ins['status']=0;
            echo $this->md->my_update('tbl_review',$ins,$wh);
            redirect("Active_Review");
        }
        else if($st==0)
        {
            $ins['status']=1;
            echo $this->md->my_update('tbl_review',$ins,$wh);
            redirect("Deactive_Review");
        }
    }
    
    public function Agent()
    {
        $st = $this->uri->segment(2);
        $wh['agent_id'] = $this->uri->segment(3);
        if($st==1)
        {
            $ins['status']=0;
            echo $this->md->my_update('tbl_agent',$ins,$wh);
            redirect("Active_agent");
        }
        else if($st==0)
        {
            $ins['status']=1;
            echo $this->md->my_update('tbl_agent',$ins,$wh);
            redirect("Deactive_agent");
        }
    }
    
    public function package() 
    {
        $wh['package_id'] = $this->uri->segment(2);
        $data["package_edit_detail"] = $this->md->my_select("tbl_package", "*", $wh);
        $data["package_detail"] = $this->md->my_select("tbl_package", "*");
        if ($this->input->post('update')) 
        {
            $this->form_validation->set_rules("package", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Package Name."));
            $this->form_validation->set_rules("duration", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Duration Of Package."));
            $this->form_validation->set_rules("price", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Price Of Package."));
            $this->form_validation->set_rules("description", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Description Of Package."));
            if ($this->form_validation->run() == TRUE) 
            {
                $package = ucwords(strtolower($this->input->post("package")));
                $duration = ucwords(strtolower($this->input->post("duration")));
                $price = ucwords(strtolower($this->input->post("price")));
                $description = ucwords(strtolower($this->input->post("description")));
                $where["package_name"] = $package;
                $where["package_id"] = $this->uri->segment(2);
                $where["price"] = $price;
                $where["duration"] = $duration;
                $where["description"] = $description;
                $count = count($this->md->my_select("tbl_package", "*", $where));
                if ($count != 0) 
                {
                    $data["error"] = $package . " Is Already Exist .";
                } else 
                {
                    $ins['package_name'] = $package;
                    $ins['duration'] = $duration;
                    $ins['price'] = $price;
                    $ins['description'] = $description;
                    $result = $this->md->my_update("tbl_package", $ins, $wh);
                    if ($result == 1) 
                    {
                        redirect("Manage_Packages");
                    } else {
                        $data["error"] = "Somethis Is Wrong .";
                    }
                }
            }
        }
        $this->load->view("Admin/Manage_Packages",$data);
    }
    
    public function plane() 
    {
        $wh['plane_id'] = $this->uri->segment(2);
        $data["plane_edit_detail"] = $this->md->my_select("tbl_plane", "*", $wh);
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules('Planename', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Plane Name."));
            $this->form_validation->set_rules('Airline', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Airline."));
            $this->form_validation->set_rules('pattern', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Plane pattern."));
            if ($this->form_validation->run() == TRUE) 
            {
                $plane_name = ucwords(strtolower($this->input->post("Planename")));
                $count = count($this->md->my_select("tbl_plane", "*", array('plane_name'=>$plane_name,'airlines_id'=>$this->input->post("Airline"),'pattern'=>$this->input->post("pattern"))));
                if ($count != 0) 
                {
                    $data["error"] = $plane_name . " Is Already Exist.";
                } 
                else 
                {
                    $ins['plane_name'] = $plane_name;
                    $ins['airlines_id'] = $this->input->post('Airline');
                    $ins['pattern'] = $this->input->post('pattern');
                    $result = $this->md->my_update("tbl_plane", $ins, $wh);
                    if ($result == 1) 
                    {
                        redirect("Manage_Plane");
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
            }
        }
        $data["view"] = $this->md->my_select("tbl_plane", "*");
        $this->load->view("Admin/Manage_Plane", $data);
    }
    
    public function airlines() 
    {
        $wh['airlines_id'] = $this->uri->segment(2);
        $data["air_edit_data"] = $this->md->my_select("tbl_airlines", "*", $wh);
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules('name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter Airline Name.", 'regex_match' => "Enter Valid Airline Name."));
            if ($this->form_validation->run() == TRUE) 
            {
                $Airline_name = ucwords(strtolower($this->input->post("name")));
                $count = count($this->md->my_select("tbl_airlines", "*", array('airlines'=>$Airline_name)));
                if ($count != 0) 
                {
                    $data["error"] = $Airline_name . " Is Already Exist.";
                } 
                else 
                {
                    if(!empty($_FILES['Photo']['name']))
                    {
                        $id = $this->uri->segment(2) - 1;
                        $name = "Airline_" . $id;
                        $config['upload_path'] = './Admin_Assets/images/Upload/Airline/';
                        $config['allowed_types'] = 'jpg|png|jpeg';
                        $config['max_size'] = 1024 * 3;
                        $config['file_name'] = $name;
                        $config['overwrite'] = TRUE;
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if ($this->upload->do_upload('Photo')) 
                        {
                            $ins['photo'] = "Admin_Assets/images/Upload/Airline/" . $this->upload->data('file_name');
                            $ins['airlines'] = $Airline_name;
                            $result = $this->md->my_update("tbl_airlines", $ins, $wh);
                            if ($result == 1) 
                            {
                                redirect("Manage_Airlines");
                            } 
                            else 
                            {
                                $data["error"] = "Somethis Is Wrong .";
                            }
                        }
                        else 
                        {
                            $data["error"] = $this->upload->display_errors();
                        }
                    }
                    else 
                    {
                        $ins['airlines'] = $Airline_name;
                        $result = $this->md->my_update("tbl_airlines", $ins, $wh);
                        if ($result == 1) 
                        {
                            redirect("Manage_Airlines");
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_airlines", "*");
        $this->load->view("Admin/Manage_Airlines", $data);
    }
    
    public function edit_airport() 
    {
        $wh['air_id'] = $this->uri->segment(2);
        $data["air_edit_data"] = $this->md->my_select("tbl_airport", "*", $wh);
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules("Airpotname", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Please  Enter Airport."));
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fas fa-exclamation-circle animated flash infinite'></i> Please Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) 
            {
                $Air_name = ucwords(strtolower($this->input->post("Airpotname")));
                $count = count($this->md->my_select("tbl_airport", "*",array('air_name'=>$Air_name,'location_id'=>$this->input->post("city"))));
                if ($count != 0) 
                {
                    $data["error"] = $Air_name."  Already Existed. ";
                } 
                else 
                {
                    if(!empty($_FILES['Photo']['name']))
                    {
                        $id = $this->uri->segment(2) - 1;
                        $name = "Airport_" . $id;
                        $config['upload_path'] = './Admin_Assets/images/Upload/Airport/';
                        $config['allowed_types'] = 'jpg|png|jpeg';
                        $config['max_size'] = 1024 * 3;
                        $config['file_name'] = $name;
                        $config['overwrite'] = TRUE;
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if ( $this->upload->do_upload('Photo') ) 
                        {
                            $ins['photo'] = "Admin_Assets/images/Upload/Airport/" . $this->upload->data('file_name');
                            $ins['air_name'] = $Air_name;
                            $ins['location_id'] = $this->input->post('city');
                            $result = $this->md->my_update("tbl_airport", $ins, $wh);
                            if ($result == 1) 
                            {
                                redirect("Manage_Airport");
                            } 
                            else 
                            {
                                $data["error"] = "Somethis Is Wrong .";
                            }
                        }
                        else 
                        {
                            $data["error"] = $this->upload->display_errors();
                        }
                    }
                    else 
                    {
                        $ins['air_name'] = $Air_name;
                        $ins['location_id'] = $this->input->post('city');
                        $result = $this->md->my_update("tbl_airport", $ins, $wh);
                        if ($result == 1) 
                        {
                            redirect("Manage_Airport");
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                }
            }
        }
        $data['view'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,ai.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_airport` AS ai WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND ai.location_id = ct.location_id");
        $this->load->view("Admin/manage_airport", $data);
    }
     public function edit_schedule() 
     {
        $wh['schedule_id'] = $this->uri->segment(2);
        $data["schedule_edit_detail"] = $this->md->my_select("tbl_air_schedule", "*", $wh);
        if ($this->input->post("update")) 
        {
            $this->form_validation->set_rules('airline', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One airline."));
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One from Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One from state."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One from city."));
            $this->form_validation->set_rules('plane', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One plane."));
            $this->form_validation->set_rules('Class', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast Flight Class."));
            $this->form_validation->set_rules("t_country", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One to Country."));
            $this->form_validation->set_rules("t_state", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One to state."));
            $this->form_validation->set_rules("t_city", "", "required", array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One to city."));
            $this->form_validation->set_rules('plane', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Select Atleast One plane."));
            $this->form_validation->set_rules('ftime', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter plane From Time."));
            $this->form_validation->set_rules('ttime', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i>  Enter plane To Time."));
            if ($this->form_validation->run() == TRUE) 
            {
                $where["plan_id"] = $this->input->post("plane");
                $where["from_time"] = $this->input->post("ftime");
                $where["to_time"] = $this->input->post("ttime");
                $where["from_location"] = $this->input->post("city");
                $where["to_location"] = $this->input->post("t_city");
                $where["price"] = $this->input->post("price");
                $where["class"] = $this->input->post("Class");
                $count = count($this->md->my_select("tbl_air_schedule", "*", $where));
                if ($count != 0) 
                {
                    $data["error"] = "Air Schedule Is Already Existed. ";
                } else {
                    $ins['plan_id']=$this->input->post('plane');
                    $ins['from_time']=$this->input->post('ftime');
                    $ins['to_time']=$this->input->post('ttime');
                    $ins['from_location']=$this->input->post('city');
                    $ins['to_location']=$this->input->post('t_city');
                    $ins['price']=$this->input->post('price');
                    $ins['class']=$this->input->post('Class');
                    $result = $this->md->my_update("tbl_air_schedule", $ins, $wh);
                    if ($result == 1) {
                        redirect("Manage_Air_schedule");
                    } else {
                        $data["error"] = "Something Is Wrong";
                    }
                }
            }
        }
        $this->load->view("Admin/Add_Air_Schedule", $data);
    }
    
    //Agent
    public function edit_place() {
        $data = array();
        $c=0;
        $where['place_id'] = $this->uri->segment(2);
        $data['editdata'] = $this->md->my_select('tbl_place', '*', $where);
        $data['view'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id");
        if ($this->input->post('update')) 
        {
            $this->form_validation->set_rules('disp', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Place Description.")); 
            $this->form_validation->set_rules('country', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules('state', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules('city', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) 
            {
                $wh['name'] = $this->input->post('city');
                $wh['description'] = ucwords(strtolower($this->input->post('disp')));
                $result = count($this->md->my_select("tbl_place", "*", $wh));
                if ($result == 0) 
                {
                    $len = strlen($_FILES['Photo']['name'][0]);
                    if($len > 0)
                    {
                        if($c == 0)
                        {
                            $pic = explode(',',$data['editdata'][0]->photo);
                            foreach ($pic as $p)
                            {
                                unlink($p);
                            }
                            $c++;
                        }
                        $count = count($_FILES['Photo']['name']);
                        for ($i = 0; $i < $count; $i++) 
                        {
                            $_FILES['single']['name'] = $_FILES['Photo']['name'][$i];
                            $_FILES['single']['type'] = $_FILES['Photo']['type'][$i];
                            $_FILES['single']['size'] = $_FILES['Photo']['size'][$i];
                            $_FILES['single']['error'] = $_FILES['Photo']['error'][$i];
                            $_FILES['single']['tmp_name'] = $_FILES['Photo']['tmp_name'][$i];
                            $detail = $this->md->my_query("select max(place_id) as mx from `tbl_place`");
                            $id = $this->uri->segment(2) - 1;
                            $name = "Place_$id-$i";
                            $config['upload_path'] = './Admin_Assets/images/Upload/Place/';
                            $config['allowed_types'] = 'jpg|png|jpeg';
                            $config['overwrite'] = TRUE;
                            $config['max_size'] = 1024 * 3;
                            $config['file_name'] = $name;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('single')) 
                            {
                                $j =1;
                            }
                            $path[] ="Admin_Assets/images/Upload/Place/".$this->upload->data('file_name');
                        }
                        $pname = implode(',',$path);
                        if($j == 1)
                        {
                            $count = count($this->md->my_select("tbl_place", "*",array('name'=>$this->input->post('city'))));
                            if ($count == 0) 
                            {
                                $ins['name'] = $this->input->post('city');
                            }
                            else
                            {
                                $city = $this->md->my_select("tbl_location", "*",array('location_id' => $this->input->post('city')));
                                $data["error"] =  $city[0]->name . " Is Already Exist.";
                            }
                            $ins['photo'] = $pname;
                            $ins['description'] = $this->input->post('disp');
                            $result = $this->md->my_update("tbl_place", $ins,$where);
                            if ($result == 1) 
                            {
                                redirect("Manage_place");
                            } 
                            else 
                            {
                                $data["error"] = "Something Is Wrong .";
                            }
                        }
                        else 
                        {
                            $data["error"] = "Something Is Wrong.";
                        }
                    }
                    else
                    {
                        $count = count($this->md->my_select("tbl_place", "*",array('name'=>$this->input->post('city'))));
                        if ($count == 0) 
                        {
                            $ins['name'] = $this->input->post('city');
                        }
                        else
                        {
                            $city = $this->md->my_select("tbl_location", "*",array('location_id' => $this->input->post('city')));
                            $data["error"] =  $city[0]->name . " Is Already Exist.";
                        }
                        $ins['photo'] = $pname;
                        $ins['description'] = ucwords(strtolower($this->input->post('disp')));
                        $result = $this->md->my_update("tbl_place", $ins,$where);
                        if ($result == 1) 
                        {
                            redirect("Manage_place");
                        } 
                        else 
                        {
                            $data["error"] = "Something Is Wrong .";
                        }
                    }
                }
                else 
                {
                    $data["error"] = "Please Update Place Details.";
                }
            }
        }
        $this->load->view("Agent/Manage_place",$data);
    }
    public function edit_facility() 
    {
        $data = array();
        $where['facility_id'] = $this->uri->segment(2);
        $record=$this->md->my_select('tbl_agent','agent_id',array('email'=>$this->session->userdata('agent')));
        $wh['agent_id'] = $record[0]->agent_id;
        $data['editdata'] = $this->md->my_select('tbl_facility', '*', $where);
        $data['view'] = $this->md->my_select('tbl_facility', '*', $wh);
        if ($this->input->post('edit')) 
        {
            $this->form_validation->set_rules('Type', '', 'required', array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Select Facility."));
            $this->form_validation->set_rules('Facility', ' ', 'required', array("required" => "<i class='fa fa-exclamation-circle animated flash infinite'></i>Please Enter Type of Policy."));
            if ($this->form_validation->run() == TRUE) 
            {
                $name = ucwords(strtolower($this->input->post('Facility')));
                $type = ucwords(strtolower($this->input->post("Type")));
                $ins['agent_id'] = $record[0]->agent_id;
                $ins['type'] = $type;
                $ins['facility'] = $name;
                $result = count($this->md->my_select("tbl_facility", "*", $ins));
                if ($result == 0) 
                {
                    $op = $this->md->my_update("tbl_facility", $ins, $where);
                    if ($op == 1) 
                    {
                        redirect("Agent_Facility");
                    } 
                    else 
                    {
                        $data["error"] = " Facility  Is Already Exist.";
                    }
                } 
                else 
                {
                    $data["error"] = "Please Update Your Facility.";
                }
            }
        }
        $this->load->view("Agent/Facility",$data);
    }
     public function edit_policy() {

       $data = array();
        $where['policy_id'] = $this->uri->segment(2);
        $record=$this->md->my_select('tbl_agent','agent_id',array('email'=>$this->session->userdata('agent')));
        $agent=$record[0]->agent_id;
        $wh['agent_id'] = $record[0]->agent_id;
        $data['editdata'] = $this->md->my_select('tbl_policy', '*', $where);
        $data['view'] = $this->md->my_select('tbl_policy', '*', $wh);

        if ($this->input->post('edit')) {
            $this->form_validation->set_rules('Type', ' ', 'required', array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i>Please Select Type Of Policy.",));
            $this->form_validation->set_rules('policy', ' ', 'required', array("required" => "<i class='fa fa-exclamation-circle animated flash infinite'></i>Please Enter Policy."));

            if ($this->form_validation->run() == TRUE) {
                $policy = ucwords(strtolower($this->input->post('policy')));
                $type = ucwords(strtolower($this->input->post("Type")));
                $wh['policy'] = $policy;
                $wh['type'] = $type;
                $count = count($this->md->my_select("tbl_policy", "*", $wh));

                if ($count != 0) {

                    $data["error"] = " Please Update Your Policy.";
                } else {

                    $ins['policy'] = $policy;
                    $ins['type'] = $type;
                    $result = $this->md->my_update("tbl_policy", $ins, $where);
                    if ($result == 1) {
                        redirect("Agent_policy");
                    } else {
                        $data["error"] = "Something Is Wrong";
                    }
                }
            }
        }
        
        $this->load->view('Agent/policy', $data);
    }
    public function edit_package_seller() 
    {
        $data = array();
        $c=0;$j=0;
        $where['package_id'] = $this->uri->segment(2);
        $record=$this->md->my_select('tbl_agent','agent_id',array('email'=>$this->session->userdata('agent')));
        $wh['agent_id'] = $record[0]->agent_id;
        $data['editdata'] = $this->md->my_select('tbl_trip_package', '*', $where);
        $data['view'] = $this->md->my_select('tbl_trip_package', '*', $wh);
        if ($this->input->post('edit')) 
        {
            $this->form_validation->set_rules('Package', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Package Name.")); 
            $this->form_validation->set_rules('country', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules('state', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules('city', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('t_country', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules('t_state', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules('t_city', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('Type', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Traveller Type."));
            $this->form_validation->set_rules('Price', "", "required|regex_match[/^[0-9]+$/]", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Price.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Package Price."));
            $this->form_validation->set_rules('hotel[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one hotel."));
            $this->form_validation->set_rules('Facility[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Facility."));
            $this->form_validation->set_rules('Policy[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Policy."));
            $this->form_validation->set_rules('disp', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Discription."));
            if($this->input->post('Type') == 'Flight')
            {
                $this->form_validation->set_rules('Air', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast Plane."));
            }
            if ($this->form_validation->run() == TRUE) 
            {
                $Facility = implode(',', $this->input->post('Facility'));
                $Policy = implode(',', $this->input->post('Policy'));
                $hotel = implode(',', $this->input->post("hotel"));
                
                $whe['facility_id'] = $Facility;
                $whe['policy_id'] = $Policy;
                $whe['agent_id'] = $record[0]->agent_id;
                $whe['name'] = ucwords(strtolower($this->input->post('Package')));
                $whe['From_location'] = $this->input->post('city');
                $whe['To_location'] = $this->input->post('t_city');
                $whe['price'] = $this->input->post('Price');
                $whe['hotel_id'] = $hotel;
                $whe['travel_type'] = ucwords(strtolower($this->input->post('Type')));
                if($this->input->post('Type') == 'Flight')
                {
                    $whe['travel_id'] = $this->input->post('Air');
                }
                $whe['description'] = ucwords(strtolower($this->input->post('disp')));
                $count = count($this->md->my_select("tbl_trip_package","*",$whe));
                
                if ($count != 0) 
                {
                    $data["error"] = $this->input->post('Package') . " Is Already Exist.";
                } 
                else 
                {
                    $len = strlen($_FILES['package_pic']['name'][0]);
                    if($len > 0)
                    {
                        if($c == 0)
                        {
                            $pic = explode(',',$data['editdata'][0]->photo);
                            foreach ($pic as $p)
                            {
                                unlink($p);
                            }
                            ++$c;
                        }
                        $count = count($_FILES['package_pic']['name']);
                        for ($i = 0; $i < $count; $i++) 
                        {
                            $_FILES['single']['name'] = $_FILES['package_pic']['name'][$i];
                            $_FILES['single']['type'] = $_FILES['package_pic']['type'][$i];
                            $_FILES['single']['size'] = $_FILES['package_pic']['size'][$i];
                            $_FILES['single']['error'] = $_FILES['package_pic']['error'][$i];
                            $_FILES['single']['tmp_name'] = $_FILES['package_pic']['tmp_name'][$i];
                            $id = $this->uri->segment(2) - 1;
                            $name = "Package_$id-$i";
                            $config['upload_path'] = './Admin_Assets/images/Upload/Package/';
                            $config['allowed_types'] = 'jpeg|png|jpg';
                            $config['max_size'] = 1024 * 3;
                            $config['overwrite'] = TRUE;
                            $config['file_name'] = $name;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('single')) 
                            {
                                $j =1;
                            }
                            $path[] ="Admin_Assets/images/Upload/Package/" . $this->upload->data('file_name');
                        }
                        $pname = implode(',',$path);
                        if($j == 1)
                        {
                            $ins['photo'] = $pname;
                            $ins['facility_id'] = $Facility;
                            $ins['policy_id'] = $Policy;
                            $ins['agent_id'] = $record[0]->agent_id;
                            $ins['name'] = ucwords(strtolower($this->input->post('Package')));
                            $ins['From_location'] = $this->input->post('city');
                            $ins['To_location'] = $this->input->post('t_city');
                            $ins['price'] = $this->input->post('Price');
                            $ins['hotel_id'] = $hotel;
                            $ins['travel_type'] = ucwords(strtolower($this->input->post('Type')));
                            if($this->input->post('Type') == 'Flight')
                            {
                                $ins['travel_id'] = $this->input->post('Air');
                            }
                            $ins['description'] = ucwords(strtolower($this->input->post('disp')));
                            $result = $this->md->my_update("tbl_trip_package", $ins,$where);
                            if ($result == 1) 
                            {
                                redirect('View_Package');
                            } 
                            else 
                            {
                                $data["error"] = "Somethis Is Wrong .";
                            }
                        }
                        else
                        {
                            $data["error"] = 'something is Wrong.';
                        }
                    }
                    else
                    {
                        $ins['facility_id'] = $Facility;
                        $ins['policy_id'] = $Policy;
                        $ins['agent_id'] = $record[0]->agent_id;
                        $ins['name'] = ucwords(strtolower($this->input->post('Package')));
                        $ins['From_location'] = $this->input->post('city');
                        $ins['To_location'] = $this->input->post('t_city');
                        $ins['price'] = $this->input->post('Price');
                        $ins['hotel_id'] = $hotel;
                        $ins['travel_type'] = ucwords(strtolower($this->input->post('Type')));
                        if($this->input->post('Type') == 'Flight')
                        {
                            $ins['travel_id'] = $this->input->post('Air');
                        }
                        $ins['description'] = ucwords(strtolower($this->input->post('disp')));
                        $result = $this->md->my_update("tbl_trip_package", $ins,$where);
                        if ($result == 1) 
                        {
                            redirect('View_Package');
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                }
            }
        }
        $this->load->view('Agent/add_package', $data);
    }
    public function edit_hotel() {

        $data = array();
        $c=0;$j=0;
        $where['hotel_id'] = $this->uri->segment(2);
        $record=$this->md->my_select('tbl_agent','agent_id',array('email'=>$this->session->userdata('agent')));
        $agent=$record[0]->agent_id;
        $wh['agent_id'] = $record[0]->agent_id;
        $data['view'] = $this->md->my_select('tbl_hotel', '*', $wh);
        $data['editdata'] = $this->md->my_select('tbl_hotel', '*', $where);

        if ($this->input->post('edit')) {
            $this->form_validation->set_rules('name', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Name.")); 
            $this->form_validation->set_rules('address', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel address.")); 
            $this->form_validation->set_rules('star', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atlest One Star.")); 
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('contact', '','required|max_length[15]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter contact Number.",'max_length' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Contact Number Is Maximum 15.")); 
            $this->form_validation->set_rules('Facility[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Facility.")); 
            $this->form_validation->set_rules('policy[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one policy.")); 
            $this->form_validation->set_rules('website', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Website.")); 
            $this->form_validation->set_rules('map', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel map location.")); 
            $this->form_validation->set_rules('disp', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Discription.")); 
            $this->form_validation->set_rules('Price', "", "required|regex_match[/^[0-9]+$/]", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Price.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Hotel Price."));
            
            if ($this->form_validation->run() == TRUE) 
            {
                $hotel = ucwords(strtolower($this->input->post('name')));
                $star = $this->input->post("star");
                $city = $this->input->post("city");
                $address = ucwords(strtolower($this->input->post("address")));
                $website = $this->input->post("website");
                $contact= $this->input->post("contact");
                $price= $this->input->post("Price");
                $disp = ucwords(strtolower($this->input->post("disp")));
                $facility = implode(',', $this->input->post("Facility"));
                $policy = implode(',', $this->input->post("policy"));

                $wh['hotel_name'] = $hotel;
                $wh['star'] = $star;
                $wh['address'] = $address;
                $wh['website'] = $website;
                $wh['contact'] = $contact;
                $wh['discription'] = $disp;
                $wh['facility'] = $facility;
                $wh['policy'] = $policy;
                $wh['location_id'] = $city;
                $wh['price'] = $price;
                $count = count($this->md->my_select("tbl_hotel", "*", $wh));
                if ($count != 0) 
                {
                    $data["error"] = " $hotel Is Already Exist";
                } 
                else 
                {
                    $len = strlen($_FILES['hotel_pic']['name'][0]);
                    if($len > 0)
                    {
                        if($c == 0)
                        {
                            $pic = explode(',',$data['editdata'][0]->photo);
                            foreach ($pic as $p)
                            {
                                unlink($p);
                            }
                            ++$c;
                        }
                        $count = count($_FILES['hotel_pic']['name']);
                        for ($i = 0; $i < $count; $i++) 
                        {
                            $_FILES['single']['name'] = $_FILES['hotel_pic']['name'][$i];
                            $_FILES['single']['type'] = $_FILES['hotel_pic']['type'][$i];
                            $_FILES['single']['size'] = $_FILES['hotel_pic']['size'][$i];
                            $_FILES['single']['error'] = $_FILES['hotel_pic']['error'][$i];
                            $_FILES['single']['tmp_name'] = $_FILES['hotel_pic']['tmp_name'][$i];
                            $detail = $this->md->my_query("select max(hotel_id) as mx from `tbl_hotel`");
                            $id = $this->uri->segment(2) - 1;
                            $name = "Hotel_$id-$i";
                            $config['upload_path'] = './Admin_Assets/images/Upload/Hotel/';
                            $config['allowed_types'] = 'jpeg|png|jpg';
                            $config['max_size'] = 1024 * 3;
                            $config['file_name'] = $name;
                            $config['overwrite'] = TRUE;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('single')) 
                            {
                                $j =1;
                            }
                            $path[] ="Admin_Assets/images/Upload/Hotel/" . $this->upload->data('file_name');
                        }
                        $pname = implode(',',$path);
                        if($j == 1)
                        {
                            $ins['photo'] = $pname;
                            $ins['facility'] = $facility;
                            $ins['policy'] = $policy;
                            $ins['agent_id'] = $agent;
                            $ins['hotel_name'] = ucwords(strtolower($this->input->post('name')));
                            $ins['location_id'] = $this->input->post('city');
                            $ins['star'] = $this->input->post('star');
                            $ins['address'] = ucwords(strtolower($this->input->post('address')));
                            $ins['iframe'] = $this->input->post('map');
                            $ins['website'] = $this->input->post('website');
                            $ins['Discription'] = ucwords(strtolower($this->input->post('disp')));
                            $ins['contact'] = $this->input->post('contact');
                            $ins['price'] = $price;
                            $ins['status'] = 1;
                            $result = $this->md->my_update("tbl_hotel", $ins, $where);
                            if ($result == 1) {
                                redirect("Manage_hotel");
                            } else {
                                $data["error"] = "Something Is Wrong";
                            }
                        }
                        else
                        {
                            $data["error"] = 'something is Wrong.';
                        }
                    }
                    else
                    {
                        $ins['facility'] = $facility;
                        $ins['policy'] = $policy;
                        $ins['agent_id'] = $agent;
                        $ins['hotel_name'] = ucwords(strtolower($this->input->post('name')));
                        $ins['location_id'] = $this->input->post('city');
                        $ins['star'] = $this->input->post('star');
                        $ins['address'] = ucwords(strtolower($this->input->post('address')));
                        $ins['iframe'] = $this->input->post('map');
                        $ins['website'] = $this->input->post('website');
                        $ins['Discription'] = ucwords(strtolower($this->input->post('disp')));
                        $ins['contact'] = $this->input->post('contact');
                        $ins['status'] = 1;
                        $result = $this->md->my_update("tbl_hotel", $ins, $where);
                        if ($result == 1) {
                            redirect("Manage_hotel");
                        } else {
                            $data["error"] = "Something Is Wrong";
                        }
                    }
                }
            }
        }
        $this->load->view('Agent/Add_hotel', $data);
    }

}