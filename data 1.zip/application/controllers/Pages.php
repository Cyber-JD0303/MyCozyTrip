<?php

Class Pages extends CI_Controller {

    function __construct() {
        parent::__construct();
//        https://developer.paypal.com/developer/accounts/

        /*
         * PayPal and database configuration 
         */

// PayPal configuration 
        define('PAYPAL_ID', 'sb-wvvxt1944080@business.example.com');

        define('PAYPAL_SANDBOX', TRUE); //TRUE or FALSE 
        define('PAYPAL_RETURN_URL', 'http://localhost/MyCozy/payment_Success');
        define('PAYPAL_CANCEL_URL', 'http://localhost/MyCozy/payment_Failed');
        define('PAYPAL_NOTIFY_URL', 'http://localhost/MyCozy/Payment-Notify');

        define('PAYPAL_CURRENCY', 'USD');

// Change not required 
        define('PAYPAL_URL', (PAYPAL_SANDBOX == true) ? "https://www.sandbox.paypal.com/cgi-bin/webscr" : "https://www.paypal.com/cgi-bin/webscr");
        date_default_timezone_set("Asia/Kolkata");
    }

    public function security() {
        if (!$this->session->userdata('user')) {
            redirect('Login');
        }
    }

    public function Index() {
        $data = array();
        if ($this->input->post('go')) {
            $place = $this->md->my_select("tbl_place", "*", array('name' => $this->input->post('city')));
            if (!empty($place)) {
                redirect(base_url() . "View_place/" . $place[0]->place_id);
            } else {
                $data['error'] = 'Not Any place is Found';
            }
        }
        $data['place'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id");
        $data['hotel'] = $this->md->my_query("SELECT ct.name as city,h.*  FROM `tbl_location` AS ct,`tbl_hotel` AS h WHERE h.location_id = ct.location_id");
        $data['flights'] = $this->md->my_select('tbl_air_schedule', '*');
        $this->load->view("User/Index", $data);
    }

    // place

    public function favourite_place() {
        $this->security();
        $data = array();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        $where['type'] = 'place';
        $data['view'] = $this->md->my_select("tbl_wishlist", "*", $where);
        $this->load->view("User/favourite_place", $data);
    }

    public function Place() {
        $data = array();
        $data['view'] = $this->md->my_query("SELECT DISTINCT ct.name as city,c.name AS country, s.name AS state, p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id order by ct.name ASC");
        $this->load->view("User/Place", $data);
    }

    public function View_place() {
        $data = array();
        $wh['place_id'] = $this->uri->segment(2);
        $data["place_detail"] = $this->md->my_select("tbl_place", "*", $wh);
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        if ($this->input->post('add')) {
            $where['Rid'] = $record[0]->Rid;
            $where['type'] = 'place';
            $where['type_id'] = $this->uri->segment(2);
            $count = count($this->md->my_select("tbl_wishlist", "*", $where));
            if ($count != 0) {
                $city = $this->md->my_select("tbl_location", "*", array('location_id' => $data["place_detail"][0]->name));
                $data["error"] = $city[0]->name . " Is Already Exist In WishList.";
            } else {
                $ins['Rid'] = $record[0]->Rid;
                $ins['type'] = 'place';
                $ins['type_id'] = $this->uri->segment(2);
                $result = $this->md->my_insert("tbl_wishlist", $ins);
                if ($result == 1) {
                    $data["success"] = "Add To Wishlist Successfully";
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        if ($this->input->post('Send')) {
            $this->form_validation->set_rules('Review', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Review deatils."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Review'] = $this->input->post('Review');
                $ins['email'] = $this->input->post('email');
                $ins['datetime'] = date('Y-m-d h:i:s');
                $ins['type'] = 'place';
                $ins['type_id'] = $this->uri->segment(2);
                $ins['status'] = 1;
                $result = $this->md->my_insert("tbl_review", $ins);
                if ($result == 1) {
                    $data["success"] = "Review Are Give Successfully.";
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $data['review'] = $this->md->my_select("tbl_review", "*", array('type' => 'place', 'type_id' => $this->uri->segment(2),'status'=>'1'));
        $data['package'] = $this->md->my_select("tbl_trip_package", "*", array('To_location' => $data["place_detail"][0]->name));
        $this->load->view("User/Place_view", $data);
    }

    //Flight

    public function Flights() {
        $this->security();
        $data['view'] = $this->md->my_select('tbl_air_schedule', '*');
        $this->load->view("User/Flights", $data);
    }

    public function View_flight() {
        $this->security();
        $data = array();
        $wh['schedule_id'] = $this->uri->segment(2);
        $data["flight_detail"] = $this->md->my_select("tbl_air_schedule", "*", $wh);
        $this->load->view("User/Flight_view", $data);
    }

    public function Airport() {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,a.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_airport` AS a WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND a.location_id = ct.location_id order by a.air_name ASC");
        $this->load->view("User/Airport", $data);
    }

    public function Flight_book() {
        $data = array();
        $this->security();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        $data['view'] = $this->md->my_select("tbl_flight_book", "*", $where);
        $this->load->view("User/Flight_book", $data);
    }

    public function Flight_invoice() {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_select('tbl_flight_book', '*', array('booking_id' => $this->uri->segment(2)));
        $this->load->view("User/bill3", $data);
    }

    public function flight_booking() {
        $data = array();
        $this->security();
        $digits_needed = 4;
        $random_number = '2020'; // set up a blank string
        $count = 0;
        while ($count < $digits_needed) {
            $random_digit = mt_rand(0, 9);
            $random_number .= $random_digit;
            $count++;
        }
        $whe['email'] = $this->session->userdata('user');
        $data['user'] = $this->md->my_select('tbl_register', '*', $whe);
        $data["flight_detail"] = $this->md->my_select("tbl_air_schedule", "*", array('schedule_id' => $this->uri->segment(2)));
        if ($this->input->post('book')) {
            $this->form_validation->set_rules('firstDate', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Flight Trvelling date."));
            $this->form_validation->set_rules('person', '', 'required|regex_match[/^[0-9]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Number Of Person For the Flight Booking.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter valid Number Of Person For the Flight Booking."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Rid'] = $data['user'][0]->Rid;
                $ins['schedule_id'] = $this->uri->segment(2);
                $ins['book_date'] = date('Y-m-d', strtotime($this->input->post('firstDate')));
                $ins['booking_date'] = date('Y-m-d h:i:s');
                $ins['amount'] = (($data["flight_detail"][0]->price) * $this->input->post('person'));
                $ins['booking_id'] = $random_number;
                $ins['person'] = $this->input->post('person');
                $ins['status'] = 'pending';
                $result = $this->md->my_insert("tbl_flight_book", $ins);
                if ($result == 1) {
                    redirect(base_url() . "FlightBooking2/" . $ins['booking_id']);
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $this->load->view("User/f_Booking1", $data);
    }

    public function flight_booking2() {
        $data = array();
        $this->security();
        $data["booking_detail"] = $this->md->my_select("tbl_flight_book", "*", array('booking_id' => $this->uri->segment(2)));
        $this->load->view("User/f_Booking2", $data);
    }

    public function flight_booking3() {
        $data = array();
        $this->security();
        $data["booking_detail"] = $this->md->my_select("tbl_flight_book", "*", array('booking_id' => $this->uri->segment(2)));
        $this->load->view("User/f_Booking3", $data);
    }

    // Hotel

    public function Hotel() {
        $data = array();
        $data['view'] = $this->md->my_query("SELECT ct.name as city,h.*  FROM `tbl_location` AS ct,`tbl_hotel` AS h WHERE h.location_id = ct.location_id ORDER BY h.hotel_name ASC");
        $this->load->view("User/Hotel", $data);
    }

    public function View_hotel() {
        $data = array();
        $wh['hotel_id'] = $this->uri->segment(2);
        $data["hotel_detail"] = $this->md->my_select("tbl_hotel", "*", $wh);
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        if ($this->input->post('add')) {
            $where['Rid'] = $record[0]->Rid;
            $where['type'] = 'hotel';
            $where['type_id'] = $this->uri->segment(2);
            $count = count($this->md->my_select("tbl_wishlist", "*", $where));
            if ($count != 0) {
                $data["error"] = $data["hotel_detail"][0]->hotel_name . "Is Already Exist In WishList.";
            } else {
                $ins['Rid'] = $record[0]->Rid;
                $ins['type'] = 'hotel';
                $ins['type_id'] = $this->uri->segment(2);
                $result = $this->md->my_insert("tbl_wishlist", $ins);
                if ($result == 1) {
                    $data["success"] = "Add To Wishlist Successfully";
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        if ($this->input->post('Send')) {
            $this->form_validation->set_rules('Review', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Review details."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Review'] = $this->input->post('Review');
                $ins['email'] = $this->input->post('email');
                $ins['datetime'] = date('Y-m-d h:i:s');
                $ins['type'] = 'hotel';
                $ins['type_id'] = $this->uri->segment(2);
                $ins['status'] = 1;
                $result = $this->md->my_insert("tbl_review", $ins);
                if ($result == 1) {
                    $data["success"] = "Review Are Give Successfully.";
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $data['review'] = $this->md->my_select("tbl_review", "*", array('type' => 'hotel', 'type_id' => $this->uri->segment(2),'status'=>'1'));
        $this->load->view("User/Hotel_view", $data);
    }

    public function Hotel_book() {
        $data = array();
        $this->security();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        $data['view'] = $this->md->my_select("tbl_hotel_book", "*", $where);
        $this->load->view("User/Hotel_book", $data);
    }

    public function favourite_hotel() {
        $data = array();
        $this->security();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        $where['type'] = 'hotel';
        $data['view'] = $this->md->my_select("tbl_wishlist", "*", $where);
        $this->load->view("User/favourite_hotel", $data);
    }

    public function Hotel_invoice() {
        $data = array();
        $this->security();
        $data['view'] = $this->md->my_select('tbl_hotel_book', '*', array('booking_id' => $this->uri->segment(2)));
        $this->load->view("User/bill2", $data);
    }

    public function Hotel_Booking() {
        $data = array();
        $this->security();
        $digits_needed = 4;
        $random_number = '2020'; // set up a blank string
        $count = 0;
        while ($count < $digits_needed) {
            $random_digit = mt_rand(0, 9);
            $random_number .= $random_digit;
            $count++;
        }
        $whe['email'] = $this->session->userdata('user');
        $data['user'] = $this->md->my_select('tbl_register', '*', $whe);
        $wh['hotel_id'] = $this->uri->segment(2);
        $data["hotel_detail"] = $this->md->my_select("tbl_hotel", "*", $wh);
        if ($this->input->post('book')) {
            $this->form_validation->set_rules('firstDate', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Check In date."));
            $this->form_validation->set_rules('secondDate', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Check Out date."));
            $this->form_validation->set_rules('No_day', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Number Of day."));
            $this->form_validation->set_rules('person', '', 'required|regex_match[/^[0-9]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Number Of Person For the Hotel Booking.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter valid Number Of Person For the Hotel Booking."));
            $this->form_validation->set_rules('Room', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Number Of Room For the Booking."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Rid'] = $data['user'][0]->Rid;
                $ins['hotel_id'] = $this->uri->segment(2);
                $ins['checking_date'] = date('Y-m-d', strtotime($this->input->post('firstDate')));
                $ins['checkout_date'] = date('Y-m-d', strtotime($this->input->post('secondDate')));
                $ins['numberday'] = $this->input->post('No_day');
                $ins['Room'] = $this->input->post('Room');
                $ins['book_date'] = date('Y-m-d h:i:s');
                $ins['amount'] = (($data["hotel_detail"][0]->price) * $this->input->post('Room'));
                $ins['booking_id'] = $random_number;
                $ins['status'] = 'pending';
                $ins['person'] = $this->input->post('person');
                $result = $this->md->my_insert("tbl_hotel_book", $ins);
                if ($result == 1) {
                    redirect(base_url() . "HotelBooking2/" . $ins['booking_id']);
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $this->load->view("User/h_Booking1", $data);
    }

    public function Hotel_Booking2() {
        $data = array();
        $this->security();
        $wh['booking_id'] = $this->uri->segment(2);
        $data["booking_detail"] = $this->md->my_select("tbl_hotel_book", "*", $wh);
        $this->load->view("User/h_Booking2", $data);
    }

    // Package

    public function View_package() {
        $data = array();
        $wh['package_id'] = $this->uri->segment(2);
        $data["package_detail"] = $this->md->my_select("tbl_trip_package", "*", $wh);
        if ($this->input->post('Send')) 
        {
            $this->form_validation->set_rules('Review', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Review details."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Review'] = $this->input->post('Review');
                $ins['email'] = $this->input->post('email');
                $ins['datetime'] = date('Y-m-d h:i:s');
                $ins['type'] = 'package';
                $ins['type_id'] = $this->uri->segment(2);
                $ins['status'] = 1;
                $result = $this->md->my_insert("tbl_review", $ins);
                if ($result == 1) 
                {
                    $data["success"] = "Review Are Give Successfully.";
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $data['review'] = $this->md->my_select("tbl_review", "*", array('type' => 'package', 'type_id' => $this->uri->segment(2),'status'=>'1'));
        $this->load->view("User/package_view", $data);
    }

    public function Package_invoice() {
        $this->security();
        $data = array();
        $data['view'] = $this->md->my_select('tbl_booking', '*', array('booking_id' => $this->uri->segment(2)));
        $this->load->view("User/bill1", $data);
    }

    public function Package_book() {
        $this->security();
        $data = array();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        $data['view'] = $this->md->my_select("tbl_booking", "*", $where);
        $this->load->view("User/Package_book", $data);
    }

    public function Booking_page1() {
        $data = array();
        $this->security();
        $digits_needed = 4;
        $random_number = '2020'; // set up a blank string
        $count = 0;
        while ($count < $digits_needed) {
            $random_digit = mt_rand(0, 9);
            $random_number .= $random_digit;
            $count++;
        }
        $whe['email'] = $this->session->userdata('user');
        $data['user'] = $this->md->my_select('tbl_register', '*', $whe);
        $wh['package_id'] = $this->uri->segment(2);
        $data["package_detail"] = $this->md->my_select("tbl_trip_package", "*", $wh);
        if ($this->input->post('book')) {
            $this->form_validation->set_rules('booking_date', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Booking date."));
            $this->form_validation->set_rules('zip', '', 'required|regex_match[/^[0-9]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Pincode Code.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Pincode Code."));
            $this->form_validation->set_rules('person', '', 'required|regex_match[/^[0-9]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Number Of Person For the Package Booking.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter valid Number Of Person For the Package Booking."));
            if ($this->form_validation->run() == TRUE) {
                $ins['Rid'] = $data['user'][0]->Rid;
                $ins['package_id'] = $this->uri->segment(2);
                $ins['booked_date'] = date('Y-m-d', strtotime($this->input->post('booking_date')));
                $ins['book_date'] = date('Y-m-d h:i:s');
                $ins['amount'] = (($data["package_detail"][0]->price) * $this->input->post('person'));
                $ins['zipcode'] = $this->input->post('zip');
                $ins['booking_id'] = $random_number;
                $ins['status'] = 'pending';
                $ins['person'] = $this->input->post('person');
                if (strlen($this->input->post('discription')) != 0) {
                    $ins['descirption'] = $this->input->post('discription');
                }
                $result = $this->md->my_insert("tbl_booking", $ins);
                if ($result == 1) {
                    redirect(base_url() . "Booking2/" . $ins['booking_id']);
                } else {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $this->load->view("User/Booking1", $data);
    }

    public function Booking_page2() {
        $data = array();
        $this->security();
        $wh['booking_id'] = $this->uri->segment(2);
        $data["booking_detail"] = $this->md->my_select("tbl_booking", "*", $wh);
        $this->load->view("User/Booking2", $data);
    }

    // Genral Page

    public function contact() {
        $data = array();
        $count = 0;
        if ($this->input->post('submit')) {
            $this->form_validation->set_rules('Name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Name."));
            $this->form_validation->set_rules('Email', '', 'required|valid_email', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Email Address.", 'valid_email' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Email Address."));
            $this->form_validation->set_rules('msg', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter The Messsage."));
            if ($this->form_validation->run() == TRUE) {
                $wh["email"] = $this->input->post("Email");
                $count = count($this->md->my_select("tbl_contact_us", "*", $wh));
                if ($count == 0) {
                    $ins['cid'] = 0;
                    $ins['name'] = ucwords(strtolower($this->input->post('Name')));
                    $ins['email'] = ucwords(strtolower($this->input->post('Email')));
                    $ins['msg'] = $this->input->post('msg');
                    $result = $this->md->my_insert("tbl_contact_us", $ins);
                    if ($result == 1) {
                        $data["success"] = "Submit Your Data Successfully";
                    } else {
                        $data["error"] = "Somethis Is Wrong";
                    }
                } else {
                    $data["error"] = "Email Is Already Exist";
                }
            }
        }
        $this->load->view("User/Contact", $data);
    }

    public function about() {
        $this->load->view("User/About");
    }

    public function profile_success() {
        $this->security();
        if ($this->input->post('go')) {
           redirect('My_Profile');
        }
        $this->load->view("User/profile_success");
    }

    public function payment_faild() {
        $this->load->view("User/payment_faild");
    }

    public function payment_success() {
        $this->load->view("User/payment_success");
    }

    public function payment_notify() {

        /*
         * Read POST data 
          10
         * reading posted data directly from $_POST causes serialization 
          11
         * issues with array data in POST. 
          12
         * Reading raw POST data from input stream instead. 
          13
         */
        $raw_post_data = file_get_contents('php://input');
        $raw_post_array = explode('&', $raw_post_data);
        $myPost = array();
        foreach ($raw_post_array as $keyval) {
            $keyval = explode('=', $keyval);
            if (count($keyval) == 2)
                $myPost[$keyval[0]] = urldecode($keyval[1]);
        }
// Read the post from PayPal system and add 'cmd' 
        $req = 'cmd=_notify-validate';
        if (function_exists('get_magic_quotes_gpc')) {
            $get_magic_quotes_exists = true;
        }
        foreach ($myPost as $key => $value) {
            if ($get_magic_quotes_exists == true && get_magic_quotes_gpc() == 1) {
                $value = urlencode(stripslashes($value));
            } else {
                $value = urlencode($value);
            }
            $req .= "&$key=$value";
        }
        /*
          38
         * Post IPN data back to PayPal to validate the IPN data is genuine 
          39
         * Without this step, anyone can fake IPN data 
          40
         */
        $paypalURL = PAYPAL_URL;
        $ch = curl_init($paypalURL);
        if ($ch == FALSE) {
            return FALSE;
        }
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
        curl_setopt($ch, CURLOPT_SSLVERSION, 6);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
// Set TCP timeout to 30 seconds 
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Connection: Close', 'User-Agent: company-name'));
        $res = curl_exec($ch);
        /*
          61
         * Inspect IPN validation result and act accordingly 
          62
         * Split response headers and payload, a better way for strcmp 
          63
         */
        $tokens = explode("\r\n\r\n", trim($res));
        $res = trim(end($tokens));
        if (strcmp($res, "VERIFIED") == 0 || strcasecmp($res, "VERIFIED") == 0) {
// Retrieve transaction info from PayPal 
            $item_number = $_POST['item_number'];
            $txn_id = $_POST['txn_id'];
            $payment_gross = $_POST['mc_gross'];
            $currency_code = $_POST['mc_currency'];
            $payment_status = $_POST['payment_status'];
// Check if transaction data exists with the same TXN ID 
            $prevPayment = $this->md->my_query("SELECT payment_id FROM payments WHERE txn_id = '" . $txn_id . "'")->result();
            if ($prevPayment->num_rows > 0) {
                exit();
            } else {
// Insert transaction data into the database 
                $insert = $this->md->my_query("INSERT INTO payments(item_number,txn_id,payment_gross,currency_code,payment_status) VALUES('" . $item_number . "','" . $txn_id . "','" . $payment_gross . "','" . $currency_code . "','" . $payment_status . "')")->result();
            }
        }
    }
    
    public function FAQ() {
        $this->load->view("User/FAQ");
    }

    public function My_Profile() {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('user');
        if ($this->input->post('update')) {
            $this->form_validation->set_rules('name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Valid Name."));
            $this->form_validation->set_rules('email', '', 'required|valid_email', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Email Address.", 'valid_email' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Email Address."));
            $this->form_validation->set_rules('phone', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Phone Number."));
            $this->form_validation->set_rules('Gender', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Gender."));
            $this->form_validation->set_rules('bod', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Birthdate."));
            $this->form_validation->set_rules('country', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules('state', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules('city', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) {
                if (!empty($_FILES['profile']['name'])) {
                    $result = $this->md->my_select('tbl_register', 'Rid,profile', $wh);
                    $name = "User_" . $result[0]->Rid;
                    $config['upload_path'] = './Admin_Assets/images/user/';
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    $config['max_size'] = 1024 * 3;
                    $config['file_name'] = $name;
                    $config['overwrite'] = TRUE;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('profile')) {
                        $ins['name'] = $this->input->post('name');
                        $ins['gender'] = $this->input->post('gender');
                        $ins['dob'] = $this->input->post('bod');
                        $ins['location_id'] = $this->input->post('city');
                        $ins['profile'] = "Admin_Assets/images/user/" . $this->upload->data('file_name');
                        $result = $this->md->my_update('tbl_register', $ins, $wh);
                        if ($result == 1) {
                            $data["success"] = "Profile Update Successfully";
                        } else {
                            $data["error"] = "Somethis Is Wrong";
                        }
                    } else {
                        $data["error"] = $this->upload->display_errors();
                    }
                } else {
                    $ins['name'] = $this->input->post('name');
                    $ins['gender'] = $this->input->post('Gender');
                    $ins['dob'] = $this->input->post('bod');
                    $ins['location_id'] = $this->input->post('city');
                    $result = $this->md->my_update('tbl_register', $ins, $wh);
                    if ($result == 1) {
                        $data["success"] = "Profile Update Successfully";
                    } else {
                        $data["error"] = "Somethis Is Wrong";
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select('tbl_register', '*', $wh);
        $this->load->view("User/My_Profile", $data);
    }

    public function Passport() {
        $data = array();
        $this->security();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        $where['Rid'] = $record[0]->Rid;
        if ($this->input->post("add")) {
            $this->form_validation->set_rules('name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Name.", 'regex_match' => "Enter Valid Name."));
            $this->form_validation->set_rules('passportno', '', 'required|regex_match[/^[0-9]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Passport Number.", 'regex_match' => "Enter Valid Passport Number."));
            $this->form_validation->set_rules('issuedate', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter issue date."));
            $this->form_validation->set_rules('expirydate', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter expiry date."));
            $this->form_validation->set_rules('dob', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter date of Birth."));
            $this->form_validation->set_rules('country', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atlest One Country."));
            $this->form_validation->set_rules('Gender', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Select Atlest One Gender."));
            if ($this->form_validation->run() == TRUE) {
                $wh['Rid'] = $record[0]->Rid;
                $wh['name'] = ucwords(strtolower($this->input->post("name")));
                $count = count($this->md->my_select("tbl_passport", "*", $wh));
                if ($count != 0) {
                    $data["error"] = ucwords(strtolower($this->input->post("name"))) . " Passport Detalis Is Already Exist.";
                } else {
                    $result = $this->md->my_query("select max(passport_id) as mx from tbl_passport");
                    $c = $result[0]->mx;
                    if ($c == "") {
                        $name = "Passport_0";
                    } else {
                        $name = "Passport_" . $c;
                    }
                    $config['upload_path'] = './Admin_Assets/images/Upload/Passport/';
                    $config['allowed_types'] = 'jpg|png|jpeg';
                    $config['max_size'] = 1024 * 3;
                    $config['file_name'] = $name;
                    $config['overwrite'] = TRUE;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if ($this->upload->do_upload('Photo')) {
                        $ins['Rid'] = $record[0]->Rid;
                        $ins['name'] = ucwords(strtolower($this->input->post("name")));
                        $ins['gender'] = $this->input->post("Gender");
                        $ins['passport_no'] = $this->input->post("passportno");
                        $ins['issue_date'] = $this->input->post("issuedate");
                        $ins['expiry_date'] = $this->input->post("expirydate");
                        $ins['dob'] = $this->input->post("dob");
                        $ins['photo'] = "Admin_Assets/images/Upload/Passport/" . $this->upload->data('file_name');
                        $ins['location_id'] = $this->input->post("country");
                        $result = $this->md->my_insert("tbl_passport", $ins);
                        if ($result == 1) {
                            $data["success"] = ucwords(strtolower($this->input->post("name"))) . " Added Successfully .";
                        } else {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    } else {
                        $data['error'] = $this->upload->display_errors();
                    }
                }
            }
        }
        $data['view'] = $this->md->my_select("tbl_passport ", "*", $where);
        $this->load->view("User/Passport", $data);
    }

    public function Preview() 
    {
        $data = array();
        $this->security();
        $whe['email'] = $this->session->userdata('user');
        $record = $this->md->my_select('tbl_register', 'Rid', $whe);
        if($this->uri->segment(2))
        {
            $data['passport'] = $this->md->my_query("select * from tbl_passport where passport_id = ".$this->uri->segment(2))[0];
        }
        else
        {
            $data['passport'] = $this->md->my_query("select * from tbl_passport where Rid = ".$record[0]->Rid." order by passport_id DESC")[0];
        }
        $this->load->view("User/ppassport",$data);
    }

    public function Myreview() {
        $data = array();
        $this->security();
        $data['review'] = $this->md->my_select("tbl_review", "*", array('email' => $this->session->userdata('user'),'status'=>'1'));
        $this->load->view("User/MyReview", $data);
    }

    public function Feedback() {
        $count = 0;
        $data = array();
        if ($this->input->post('add')) {
            $this->form_validation->set_rules('Name', '', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Name."));
            $this->form_validation->set_rules('Email', '', 'required|valid_email', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Email Address.", 'valid_email' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Email Address."));
            $this->form_validation->set_rules('msg', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter The Messsage."));
            if ($this->form_validation->run() == TRUE) {
                $wh["email"] = $this->input->post("Email");
                $count = count($this->md->my_select("tbl_feedback", "*", $wh));
                if ($count == 0) {
                    $ins['fid'] = 0;
                    $ins['name'] = ucwords(strtolower($this->input->post('Name')));
                    $ins['email'] = ucwords(strtolower($this->input->post('Email')));
                    $ins['message'] = $this->input->post('msg');

                    $result = $this->md->my_insert("tbl_feedback", $ins);
                    if ($result == 1) {
                        $data["success"] = "Submit Your Feedback Successfully";
                    } else {
                        $data["error"] = "Somethis Is Wrong";
                    }
                } else {
                    $data["error"] = "Email Is Already Exist";
                }
            }
        }
        $this->load->view("User/Feedback", $data);
    }

    public function Terms() {
        $this->load->view("User/Terms");
    }

    public function Privacy() {
        $this->load->view("User/Privacy");
    }

    public function Login() {
        $data = array();
        if ($this->input->post('login')) {
            $wh['email'] = ucwords(strtolower($this->input->post('email')));
            $record = $this->md->my_select('tbl_register', '*', $wh);
            $count = count($record);
            if ($count == 1) {
                $st = $record[0]->status;
                if ($st == 1) {
                    $ps = $this->encryption->decrypt($record[0]->password);
                    if ($ps == $this->input->post('ps')) {

                        if ($this->input->post('svp')) {
                            $expire = 60 * 60 * 24 * 3;
                            set_cookie('user_email', $this->input->post('email'), $expire);
                            set_cookie('user_pass', $this->input->post('ps'), $expire);
                        } else {
                            if ($this->input->cookie('user_email')) {
                                set_cookie('user_email', '', -10);
                                set_cookie('user_pass', '', -10);
                            }
                        }
                        $email = $record[0]->email;
                        $time = date('Y-m-d h:i:s');
                        $this->session->set_userdata('user', $email);
                        $this->session->set_userdata('user_lastlogin', $time);
                        redirect('My_Profile');
                    } else {
                        $data['error'] = 'Username Or Password Is Incorrect.';
                    }
                } else {
                    $data['error'] = 'You Account Is Not Activated.';
                }
            } else {
                $data['error'] = 'Username Or Password Is Incorrect.';
            }
        }
        $this->load->view("User/Login", $data);
    }

    public function Logout() {
        $data['last_login'] = $this->session->userdata('user_lastlogin');
        $wh['email'] = $this->session->userdata('user');
        $this->md->my_update('tbl_register', $data, $wh);
        $this->session->unset_userdata('user');
        $this->session->unset_userdata('user_lastlogin');
        redirect('Home');
    }

    public function Forgot() {
        $count = 0;
        $data = array();
        if ($this->input->post('Forgot')) {
            $this->form_validation->set_rules('Email', 'Email', 'required|valid_email', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Enter Email.", 'valid_email' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Email."));
            if ($this->form_validation->run() == TRUE) {
                $wh["email"] = $this->input->post("Email");
                $count = count($this->md->my_select("tbl_register", "email", $wh));
                if ($count != 0) {
                    $record = $this->md->my_select('tbl_register', '*', $wh);
                    $ps = $this->encryption->decrypt($record[0]->password);
                    $nm = $record[0]->name;
                    $subject = "Forgot password";
                    $message = "Hi " . $nm . "Your Password is : " . $ps;
                    $recevier = $this->input->post("Email");
                    $c = $this->md->mailer($subject, $message, $recevier);
                    if ($c == 1) {
                        $data["success"] = "Your Password sent Your Email";
                    } else {
                        $data["error"] = "Check Your Internet Connection Or Internet Speed";
                    }
                } else {
                    $data["error"] = "Email Are Not Register.";
                }
            }
        }
        $this->load->view("User/Forgot", $data);
    }

    public function Registration() {
        $data = array();
        $count = 0;
        if ($this->input->post('Register')) {
            $this->form_validation->set_rules('Name', 'Name', 'required|regex_match[/^[a-zA-Z ]+$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Your Name.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Name."));
            $this->form_validation->set_rules('Email', 'Email', 'required|valid_email', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Email Address.", 'valid_email' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Email."));
            $this->form_validation->set_rules('Phone', 'Phone', 'required|numeric|max_length[10]|regex_match[/^[0-9]{10}$/]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Phone Number.", 'numeric' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Valid Phone Number.", 'max_length' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Phone Number Is Maximum 10.", 'regex_match' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Phone Number In Valid Pattern."));
            $this->form_validation->set_rules('ps', 'ps', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Password."));
            $this->form_validation->set_rules('cps', 'cps', 'required|matches[ps]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Enter Confirm Password.", 'matches' => "<i class='fa fa-info-circle animated flash infinite'></i> Confirm password doesn't match."));
            $this->form_validation->set_rules('Check', 'Check', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> accept all terms & conditions and privacy policy ."));
            if ($this->form_validation->run() == TRUE) {
                $wh["email"] = ucwords(strtolower($this->input->post("Email")));
                $count = count($this->md->my_select("tbl_register", "email", $wh));
                if ($count == 0) {
                    $ins['Rid'] = 0;
                    $ins['name'] = ucwords(strtolower($this->input->post('Name')));
                    $ins['email'] = ucwords(strtolower($this->input->post('Email')));
                    $ins['password'] = $this->encryption->encrypt($this->input->post('cps'));
                    $ins['phone'] = $this->input->post('Phone');
                    $ins['last_login'] = 0;
                    $ins['profile'] = 'Admin_Assets/images/U_img.jpg';
                    $ins['status'] = 1;
                    $result = $this->md->my_insert("tbl_register", $ins);
                    if ($result == 1) {
                        $email = $this->input->post('Email');
                        $time = date('Y-m-d h:i:s');
                        $this->session->set_userdata('user', $email);
                        $this->session->set_userdata('user_lastlogin', $time);
                        redirect('profile_success');
                    } else {
                        $data["error"] = "Somethis Is Wrong";
                    }
                } else {
                    $data["error"] = "Email Is Already Exist";
                }
            }
        }
        $this->load->view("User/Registration", $data);
    }

    public function Packages() {
        if ($this->session->userdata('agent')) {
            if ($this->session->userdata('user')) {
                $this->session->unset_userdata('user');
            }
            $wh['email'] = $this->session->userdata('agent');
            if ($this->uri->segment(2)) {
                $ins['package_id'] = $this->uri->segment(2);
                $result = $this->md->my_update('tbl_agent', $ins, $wh);
                redirect('Agent_Home');
            }
            $data["view"] = $this->md->my_select("tbl_package", "*");
            $this->load->view("User/Packages", $data);
        } else {
            $this->security();
        }
    }

    public function change_password() {
        $data = array();
        $this->security();
        if ($this->input->post('update')) {
            $this->form_validation->set_rules('old_pass', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Enter old Password."));
            $this->form_validation->set_rules('new_pass', '', 'required', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Enter new Password."));
            $this->form_validation->set_rules('confirm_pass', '', 'required|matches[new_pass]', array('required' => "<i class='fa fa-info-circle animated flash infinite'></i> Please Enter Confirm Password.", 'matches' => "<i class='fa fa-info-circle animated flash infinite'></i> Confirm password doesn't match."));
            if ($this->form_validation->run() == TRUE) {
                $wh['email'] = $this->session->userdata('user');
                $record = $this->md->my_select('tbl_register', '*', $wh);
                $ops = $this->encryption->decrypt($record[0]->password);
                $ps = $this->input->post('old_pass');
                if ($ps == $ops) {
                    $ins['password'] = $this->encryption->encrypt($this->input->post('confirm_pass'));
                    $result = $this->md->my_update('tbl_register', $ins, $wh);
                    if ($result == 1) {
                        $expire = 60 * 60 * 24 * 3;
                        set_cookie('user_pass', $this->input->post('confirm_pass'), $expire);
                        $data["success"] = "Password Change Succesfully";
                    } else {
                        $data["error"] = "Somethis Is Wrong!!";
                    }
                } else {
                    $data["error"] = "Password Doesn't match!!";
                }
            }
        }
        $this->load->view("User/ChangePassword", $data);
    }

    public function Delete() {
        $table = $this->uri->segment(2);
        if ($table == "place") {
            $wh['wish_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_wishlist", $wh);
            redirect("favorite_place");
        }
        if ($table == "Book_package") {
            $wh['booking_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_booking", $wh);
            redirect("My_package_booking");
        }
        if ($table == "Book_hotel") {
            $wh['booking_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_hotel_book", $wh);
            redirect("My_hotel_booking");
        }
        if ($table == "Book_flight") {
            $wh['booking_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_flight_book", $wh);
            redirect("My_Flight_booking");
        }
        if ($table == "hotel") {
            $wh['wish_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_wishlist", $wh);
            redirect("favorite_hotel");
        }
        if ($table == "Review") {
            $wh['review_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_review", $wh);
            redirect("Myreview");
        }
    }

}
