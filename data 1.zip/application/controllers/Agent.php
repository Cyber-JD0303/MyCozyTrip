<?php

Class Agent extends CI_Controller 
{
    public function __construct() 
    {
        parent::__construct();
        date_default_timezone_get('Asia/Kolkata');
    }
    public function security()
    {
        if( !$this->session->userdata('agent'))
        {
            redirect('Agent_Login');
        }
    }
    
    public function Login() 
    {
        $data = array();
        if ($this->input->post('login')) 
        {
            $wh['email'] = ucwords(strtolower($this->input->post('email')));
            $record = $this->md->my_select('tbl_agent', '*', $wh);
	    // $ps = $this->encryption->decrypt($record[0]->password);
	    // print($ps);
	    // exit();

            $count = count($record);
            if ($count == 1) 
            {
                if($record[0]->status == 1)
                {
                    $ps = $this->encryption->decrypt($record[0]->password);
                    if ($ps == $this->input->post('ps')) 
                    {
                        if ($this->input->post('svp')) 
                        {
                            $expire = 60 * 60 * 24 * 3;
                            set_cookie('agent_email', ucwords(strtolower($this->input->post('email'))), $expire);
                            set_cookie('agent_pass', $this->input->post('ps'), $expire);
                        } 
                        else 
                        {
                            if ($this->input->cookie('agent_email')) 
                            {
                                set_cookie('agent_email', '', -10);
                                set_cookie('agent_pass', '', -10);
                            }
                        }
                        $email = $record[0]->email;
                        $time = date('Y-m-d h:i:s');
                        $this->session->set_userdata('agent', $email);
                        $this->session->set_userdata('agent_lastlogin', $time);
                        if($record[0]->package_id == 0)
                        {   
                            redirect('Packages');
                        }
                        else
                        {
                            redirect('Agent_Home');
                        }
                    } 
                    else 
                    {
                        $data['error'] = 'Username or password is incorrect';
                    }
                }
                else
                {
                    $data['error'] = 'Account Will be Deactived By Authorized.';
                }
            } 
            else 
            {
                $data['error'] = 'Email Id Not Register To Agent.';
            }
        }
        $this->load->view("Agent/Login",$data);
    }
    
    public function Logout() 
    {
        $data['last_login']= $this->session->userdata('agent_lastlogin');
        $wh['email'] = $this->session->userdata('agent');
        $this->md->my_update('tbl_agent',$data,$wh);
        $this->session->unset_userdata('agent');
        $this->session->unset_userdata('agent_lastlogin');
        $this->session->unset_userdata('user');
        $this->session->unset_userdata('user_lastlogin');
        redirect('Home');
    }

    public function Add_Bank() 
    {
        $this->security();
        $data = array();
        $wh['email'] = $this->session->userdata('agent');
        if($this->input->post('add'))
        {   
            $this->form_validation->set_rules('name', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Account Holder Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Account Holder Name.")); 
            $this->form_validation->set_rules('bank', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Bank Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Bank Name.")); 
            $this->form_validation->set_rules('branch', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Bank branch Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Bank branch Name.")); 
            $this->form_validation->set_rules('ifsc', '','required|regex_match[/^[a-zA-Z0-9]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Bank IFSC Code.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Bank IFSC Code.")); 
            $this->form_validation->set_rules('Account', '','required|numeric|max_length[14]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Account Number.",'numeric' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Account Number.",'max_length' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Account Number Is Maximum 14.")); 
            if ($this->form_validation->run() == TRUE) 
            {
                $ins['bank_benificiary_name']= ucwords(strtolower($this->input->post('name')));
                $ins['bank_name']=ucwords(strtolower($this->input->post('bank')));
                $ins['branch_name']=$this->input->post('branch');
                $ins['IFSC_code']=$this->input->post('ifsc');
                $ins['AC_no']=$this->input->post('Account');
                $result = $this->md->my_update("tbl_agent", $ins,$wh);
                if ($result == 1) 
                {
                    $data["success"] = "Add bank Account Details Succesfully";
                } 
                else 
                {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $data['view'] = $this->md->my_select('tbl_agent','*',$wh);
        $this->load->view("Agent/Add_Bank",$data);
    }

    public function Register() 
    {
        $data = array();
        if($this->input->post('Register'))
        {
            $this->form_validation->set_rules('Name', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Name.")); 
            $this->form_validation->set_rules('Email', '','required|valid_email',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Email.",'valid_email' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Email.")); 
            $this->form_validation->set_rules('Phone', '','required|numeric|max_length[10]|regex_match[/^[0-9]{10}$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Phone Number.",'numeric' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Phone Number.",'max_length' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Phone Number Is Maximum 10.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Phone Number In Valid Pattern."));
            $this->form_validation->set_rules('ps', '','required|min_length[8]|max_length[20]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Password.",'min_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password minimum Length Is 8.",'max_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password maximum Length Is 20.")); 
            $this->form_validation->set_rules('cps', '','required|matches[ps]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Confirm Password.",'matches' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Confirm password doesn't match.")); 
            $this->form_validation->set_rules('Check', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Accept All Terms And Condition.")); 
            if ($this->form_validation->run() == TRUE) 
            { 
                $wh["email"] = ucwords(strtolower($this->input->post("Email")));
                $count = count($this->md->my_select("tbl_agent", "*", $wh));
                if ($count == 0) 
                {
                    $ins['company_name'] = ucwords(strtolower($this->input->post('Name')));
                    $ins['email'] = ucwords(strtolower($this->input->post('Email')));
                    $ins['phone'] = $this->input->post('Phone');
                    $ins['password'] = $this->encryption->encrypt($this->input->post('cps'));
                    $ins['last_login'] = 0;
                    $ins['profile_pic'] = 'Admin_Assets/images/U_img.jpg';
                    $ins['status'] = 0;
                    $result = $this->md->my_insert("tbl_agent", $ins);
                    if ($result == 1) 
                    {
                        redirect('Agent_Login');
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong";
                    }
                } 
                else 
                {
                    $data["error"] = "Email Is Already Exist";                
                }
            }
        }
        $this->load->view("Agent/Registration",$data);
    }

    public function Forget() 
    {
        $count=0;
        $data = array();
        if($this->input->post('Forgot'))
        {
            $this->form_validation->set_rules('Email', 'Email','required|valid_email',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Please Enter Email.",'valid_email' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Email.")); 
            if ($this->form_validation->run() == TRUE) 
            {
                $wh["email"] = $this->input->post("Email");
                $count = count($this->md->my_select("tbl_agent", "email", $wh));
                if ($count != 0) 
                {
                    $record= $this->md->my_select('tbl_agent','*',$wh);
                    $ps= $this->encryption->decrypt($record[0]->password);
                    $nm = $record[0]->company_name;
                    $subject  = "Forgot password";
                    $message  = "Hi ".$nm." Your Password is : ".$ps;
                    $recevier = ucwords(strtolower($this->input->post("Email")));
                    $c=$this->md->mailer($subject,$message,$recevier);
                    if ($c == 1) 
                    {
                        $data["success"] = "Your Password sent Your Email";
                    }
                    else
                    {
                        $data["error"] = "Check Your Internet Connection Or Internet Speed";
                    }
                }
                else 
                {
                    $data["error"] = "Email Are Not Register.";                
                }
            }
        }
        $this->load->view("Agent/Forgot",$data);
    }
    
    public function Edit_Profile() 
    {
        $data= array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        if($this->input->post('add'))
        {
            $this->form_validation->set_rules('address', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Your Address.")); 
            $this->form_validation->set_rules('name', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Your Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Name.")); 
            $this->form_validation->set_rules('pincode', '','required|regex_match[/^[0-9]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter pincode.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid pincode.")); 
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) 
            {
                $ins['company_name'] = ucwords(strtolower($this->input->post('name')));
                $ins['pincode'] = $this->input->post('pincode');
                $ins['address'] = ucwords(strtolower($this->input->post('address')));
                $ins['location_id'] = $this->input->post('city');
                $result = $this->md->my_update('tbl_agent',$ins,$wh);
                if ($result == 1) 
                {
                    $data["success"] = "Profile Update Successfully.";
                } 
                else 
                {
                    $data["error"] = "Somethis Is Wrong.";
                }
            }
        }
        
        if($this->input->post('upload'))
        {
            if(!empty($_FILES['profile_image']['name']))
            {
                $result = $this->md->my_select('tbl_agent','agent_id',$wh);
                $name= "Agent_".$result[0]->agent_id;
                $config['upload_path'] = './Admin_Assets/images/user/';
                $config['allowed_types'] = 'jpg|png|jpeg';
                $config['max_size'] = 1024*3;
                $config['file_name'] = $name;
                $config['overwrite'] = TRUE;
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                if($this->upload->do_upload('profile_image'))
                {
                    $ins['profile_pic']="Admin_Assets/images/user/".$this->upload->data('file_name');
                    $result = $this->md->my_update('tbl_agent',$ins,$wh);
                    if ($result == 1) 
                    {
                        $data["success"] = "Profile Update Successfully.";
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong.";
                    }
                }
                else
                {
                    $data["p_error"] = $this->upload->display_errors();
                }
            }
            else
            {
                $data["error"] = "photo are no selected.";
            }
        }
        $data['view'] = $this->md->my_select('tbl_agent','*',$wh);
        $this->load->view("Agent/Edit_Profile",$data);
    }
    
    public function Changepassword() 
    {
        $cnt=0;
        $data=array();
        if($this->input->post('update'))
        {
            $this->form_validation->set_rules('old_pass', '','required|min_length[8]|max_length[20]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter old Password.",'min_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password minimum Length Is 8.",'max_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password maximum Length Is 20.")); 
            $this->form_validation->set_rules('new_pass', '','required|min_length[8]|max_length[20]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter new Password.",'min_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password minimum Length Is 8.",'max_length'=>"<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Password maximum Length Is 20.")); 
            $this->form_validation->set_rules('confirm_pass', '','required|matches[new_pass]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Confirm Password.",'matches' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Confirm password doesn't match.")); 
            if ($this->form_validation->run() == TRUE) 
            {
                $wh['email'] = $this->session->userdata('agent');
                $record = $this->md->my_select('tbl_agent','*',$wh);
                $ops = $this->encryption->decrypt($record[0]->password);
                $ps = $this->input->post('old_pass');
                if($ps == $ops)
                {
                    $ins['password'] = $this->encryption->encrypt($this->input->post('confirm_pass'));
                    $result = $this->md->my_update('tbl_agent',$ins,$wh);
                    if ($result == 1) 
                    {
                        $expire = 60*60*24*3;
                        set_cookie('agent_pass', $this->input->post('confirm_pass') , $expire);
                        $data["success"] = "Password Change Succesfully";
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong!!";
                    }
                }
                else 
                {
                    $data["error"] = "Password Doesn't match!!";
                }
            }
        }
        $this->load->view("Agent/Changepassword",$data);
    }
    
    public function profile_success() 
    {
        $this->security();
        if($this->input->post('go'))
        {
            redirect('Agent_Login');
        }
        $this->load->view("User/profile_success");
    }
    
    public function Dashboard() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $data['Place'] = count($this->md->my_select("tbl_Place", "place_id"));
        $data['Facility'] = count($this->md->my_select("tbl_facility", "facility_id",array('agent_id'=>$record[0]->agent_id)));
        $data['Policy'] = count($this->md->my_select("tbl_policy", "policy_id",array('agent_id'=>$record[0]->agent_id)));
        $data['Packages'] = count($this->md->my_select("tbl_trip_package","package_id",array('agent_id'=>$record[0]->agent_id)));
        $data['Booking'] = count($this->md->my_select("tbl_booking", "b_id",array('status'=>'paid')));
        $data['h_Booking'] = count($this->md->my_select("tbl_hotel_book", "hb_id",array('status'=>'paid')));
        $data['A_review'] = count($this->md->my_select("tbl_review", "review_id",array("status" => 1)));
        $data['D_review'] = count($this->md->my_select("tbl_review", "review_id",array("status" => 0)));
        $data['Hotel'] = count($this->md->my_select("tbl_hotel", "hotel_id",array('agent_id'=>$record[0]->agent_id)));
        $this->load->view("Agent/Dashboard",$data);
    }

    public function Manage_place() 
    {
        $data= array();
        $this->security();
        if ($this->input->post('add')) 
        {
//            $this->form_validation->set_rules('Photo[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Place Photo.")); 
            $this->form_validation->set_rules('disp', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Place Description.")); 
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            if ($this->form_validation->run() == TRUE) 
            {
                $len = strlen($_FILES['Photo']['name'][0]);
                if($len > 0)
                {
                    $wh['name'] = $this->input->post('city');
                    $wh['description'] = ucwords(strtolower($this->input->post('disp')));
                    $result = count($this->md->my_select("tbl_place", "*", $wh));
                    if ($result == 0) 
                    {
                        $count = count($_FILES['Photo']['name']);
                        for ($i = 0; $i < $count; $i++) 
                        {
                            $_FILES['single']['name'] = $_FILES['Photo']['name'][$i];
                            $_FILES['single']['type'] = $_FILES['Photo']['type'][$i];
                            $_FILES['single']['size'] = $_FILES['Photo']['size'][$i];
                            $_FILES['single']['error'] = $_FILES['Photo']['error'][$i];
                            $_FILES['single']['tmp_name'] = $_FILES['Photo']['tmp_name'][$i];
                            $detail = $this->md->my_query("select max(place_id) as mx from `tbl_place`");
                            $id = $detail[0]->mx;
                            if($id == "")
                            {
                                $name = "Place_0-$i";
                            }
                            else
                            {
                                $name = "Place_$id-$i";
                            }
                            $config['upload_path'] = './Admin_Assets/images/Upload/Place/';
                            $config['allowed_types'] = 'jpg|png|jpeg';
                            $config['max_size'] = 1024 * 3;
                            $config['file_name'] = $name;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('single')) 
                            {
                                $j =1;
                            }
                            $path[] ="Admin_Assets/images/Upload/Place/".$this->upload->data('file_name');
                        }
                        $pname = implode(',',$path);
                        if($j == 1)
                        {
                            $ins['photo'] = $pname;
                            $ins['name'] = $this->input->post('city');
                            $ins['description'] = ucwords(strtolower($this->input->post('disp')));
                            $result = $this->md->my_insert("tbl_place", $ins);
                            if ($result == 1) 
                            {
                                $city = $this->md->my_select("tbl_location", "*",array('location_id' => $this->input->post('city')));
                                $data["success"] =  $city[0]->name . " Added Successfully .";
                            } 
                            else 
                            {
                                $data["error"] = "Something Is Wrong .";
                            }
                        }
                        else 
                        {
                            $data["error"] = "Something Is Wrong.";
                        }
                    }
                    else 
                    {
                        $city = $this->md->my_select("tbl_location", "*",array('location_id' => $this->input->post('city')));
                        $data["error"] =  $city[0]->name . " Is Already Exist.";
                    }
                }
                else
                {
                    $data['p_error'] = "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select At Least One Photo.";
                }
            }
        }
        $data['view'] = $this->md->my_query("SELECT c.name AS country, s.name AS state, ct.name as city,p.*  FROM `tbl_location` AS c, `tbl_location` AS s, `tbl_location` AS ct,`tbl_place` AS p WHERE ct.parent_id = s.location_id AND s.parent_id = c.location_id AND p.name = ct.location_id order by p.place_id DESC");
        $this->load->view("Agent/Manage_place",$data);
    }
    
    public function Facility() 
    {
        $data= array();
        $this->security();
        $count=0;
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $agent=$record[0]->agent_id;
        if($this->input->post('add'))
        {
            $this->form_validation->set_rules('Type', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Faclility Type.")); 
            $this->form_validation->set_rules('Facility', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Faclility Name.")); 
            if ($this->form_validation->run() == TRUE) 
            {
                $type = ucwords(strtolower($this->input->post('Type')));
                $facility = ucwords(strtolower($this->input->post('Facility')));
                $ins['agent_id'] = $agent;
                $ins['type'] = $type;
                $ins['facility'] = $facility;
                $recordset = $this->md->my_select("tbl_facility", "*", $ins);
                $count = count($recordset);
                if ($count != 0) 
                {
                   $data["error"] = $type." Is Already Exist In " . $facility;
                } 
                else 
                {
                    $result = $this->md->my_insert("tbl_facility",$ins);
                    if ($result == 1) 
                    {
                        $data["success"] = "Facility Added Successfully.";
                    } 
                    else 
                    {
                        $data["error"] = "Somethis Is Wrong";
                    }
               }
            }
        }
        $data['view'] = $this->md->my_query("select * from tbl_facility where agent_id = ".$agent ." order by facility_id DESC");
        $this->load->view("Agent/Facility",$data);
    }
    
    public function policy() 
    {
        $data= array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $agent = $record[0]->agent_id;
        if($this->input->post('add'))
        {
            $this->form_validation->set_rules('policy', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Policy.")); 
            $this->form_validation->set_rules('Type', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atlest One Policy Type.")); 
            if ($this->form_validation->run() == TRUE) 
            {
                $ins['agent_id']=$record[0]->agent_id;
                $ins['type'] = ucwords(strtolower($this->input->post('Type')));
                $ins['policy'] = ucwords(strtolower($this->input->post('policy')));
                $result = $this->md->my_insert("tbl_policy",$ins);
                if ($result == 1) 
                {
                    $data["success"] = "Policy Added Successfully.";
                } 
                else 
                {
                    $data["error"] = "Somethis Is Wrong";
                }
            }
        }
        $data['view'] = $this->md->my_query("select * from tbl_policy where agent_id = ".$agent ." order by policy_id DESC");
        $this->load->view("Agent/policy",$data);
    }
    
    public function Booking() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $data['view'] = $this->md->my_query("SELECT b.*,p.* from tbl_booking as b,tbl_trip_package as p where b.status = 'paid' and b.package_id = p.package_id and p.agent_id = ".$record[0]->agent_id ." order by b.b_id DESC");
        $this->load->view("Agent/Booking",$data);
    }
    
    public function hotel_Booking() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $data['view'] = $this->md->my_query("SELECT b.*,p.* from tbl_hotel_book as b,tbl_hotel as p where b.status = 'paid' and b.hotel_id = p.hotel_id and p.agent_id = ".$record[0]->agent_id." order by b.hb_id DESC");
        $this->load->view("Agent/hotel_Booking",$data);
    }
    
    public function Add_Package() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $agent=$record[0]->agent_id;
        if ($this->input->post('add')) 
        {
            $this->form_validation->set_rules('Package', '','required|regex_match[/^[a-zA-Z ]+$/]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Name.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Package Name.")); 
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules("t_country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("t_state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("t_city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('Type', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Traveller Type."));
            $this->form_validation->set_rules('Price', "", "required|regex_match[/^[0-9]+$/]", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Price.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Package Price."));
            $this->form_validation->set_rules('disp', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Package Discription."));
//            $this->form_validation->set_rules('package_pic[]', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Package Photo."));
            $this->form_validation->set_rules('hotel[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one hotel."));
            $this->form_validation->set_rules('Facility[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Facility."));
            $this->form_validation->set_rules('Policy[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Policy."));
            if($this->input->post('Type') == 'Flight')
            {
                $this->form_validation->set_rules('Air', "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast Plane."));
            }
            if ($this->form_validation->run() == TRUE) 
            {
                $count = count($this->md->my_select("tbl_trip_package","*",array('name'=> ucwords(strtolower($this->input->post('Package'))),'from_location'=> $this->input->post('city'),'To_location'=> $this->input->post('t_city'),'agent_id'=>$agent)));
                if ($count != 0) 
                {
                    $data["error"] = ucwords(strtolower($this->input->post('Package'))) . " Is Already Exist.";
                } 
                else 
                {
                    $len = strlen($_FILES['package_pic']['name'][0]);
                    if($len > 0)
                    {
                        $count = count($_FILES['package_pic']['name']);
                        for ($i = 0; $i < $count; $i++) 
                        {
                            $_FILES['single']['name'] = $_FILES['package_pic']['name'][$i];
                            $_FILES['single']['type'] = $_FILES['package_pic']['type'][$i];
                            $_FILES['single']['size'] = $_FILES['package_pic']['size'][$i];
                            $_FILES['single']['error'] = $_FILES['package_pic']['error'][$i];
                            $_FILES['single']['tmp_name'] = $_FILES['package_pic']['tmp_name'][$i];
                            $detail = $this->md->my_query("select max(hotel_id) as mx from `tbl_hotel`");
                            $id = $detail[0]->mx;
                            if($id == "")
                            {
                                $name = "Package_0-$i";
                            }
                            else
                            {
                                $name = "Package_$id-$i";
                            }
                            $config['upload_path'] = './Admin_Assets/images/Upload/Package/';
                            $config['allowed_types'] = 'jpeg|png|jpg';
                            $config['max_size'] = 1024 * 3;
                            $config['file_name'] = $name;
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            if ($this->upload->do_upload('single')) 
                            {
                                $j =1;
                            }
                            $path[] ="Admin_Assets/images/Upload/Package/" . $this->upload->data('file_name');
                        }
                        $pname = implode(',',$path);
                        $Facility = implode(',', $this->input->post('Facility'));
                        $Policy = implode(',', $this->input->post('Policy'));
                        $hotel = implode(',', $this->input->post('hotel'));
                        if($j == 1)
                        {
                            $ins['photo'] = $pname;
                            $ins['facility_id'] = $Facility;
                            $ins['policy_id'] = $Policy;
                            $ins['agent_id'] = $agent;
                            $ins['name'] = ucwords(strtolower($this->input->post('Package')));
                            $ins['From_location'] = $this->input->post('city');
                            $ins['To_location'] = $this->input->post('t_city');
                            $ins['price'] = $this->input->post('Price');
                            $ins['hotel_id'] = $hotel;
                            $ins['travel_type'] = ucwords(strtolower($this->input->post('Type')));
                            if($this->input->post('Type') == 'Flight')
                            {
                                $ins['travel_id'] = $this->input->post('Air');
                            }
                            $ins['description'] = ucwords(strtolower($this->input->post('disp')));
                            $result = $this->md->my_insert("tbl_trip_package", $ins);
                            if ($result == 1) 
                            {
                                $data["success"] = $this->input->post('Package') . " Added Successfully .";
                            } 
                            else 
                            {
                                $data["error"] = "Somethis Is Wrong .";
                            }
                        }
                        else
                        {
                            $data["error"] = 'something is Wrong.';
                        }
                    }
                    else
                    {
                        $data['p_error'] = "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select At Least One Photo.";
                    }
                }
            }
        }
        $this->load->view("Agent/Add_Package",$data);
    }

    public function View_Package() 
    {
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $where['agent_id']= $record[0]->agent_id;
        $data['view'] = $this->md->my_select('tbl_trip_package','*',$where);
        $this->load->view("Agent/View_Package",$data);
    }
    
    public function Active_Review() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $data['package_detail'] = $this->md->my_query("SELECT pc.name as name,re.* FROM tbl_trip_package as pc,tbl_review as re WHERE pc.agent_id= ".$record[0]->agent_id." and re.type='package' and pc.package_id=re.type_id and re.status=1 order by re.review_id DESC");
        $data['hotel_detail'] = $this->md->my_query("SELECT pc.hotel_name as name,re.* FROM tbl_hotel as pc,tbl_review as re WHERE pc.agent_id= ".$record[0]->agent_id." and re.type='hotel' and pc.hotel_id=re.type_id and re.status=1 order by re.review_id DESC");  
        $data['place_detail'] = $this->md->my_query("SELECT lc.name as name,re.* FROM tbl_place as pc,tbl_location as lc,tbl_review as re WHERE pc.name = lc.location_id and re.type='place' and pc.place_id=re.type_id and re.status=1 order by re.review_id DESC");  
        $this->load->view("Agent/Active_Review",$data);
    }

    public function Deactive_Review() 
    {
        $data = array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $data['package_detail'] = $this->md->my_query("SELECT pc.name as name,re.* FROM tbl_trip_package as pc,tbl_review as re WHERE pc.agent_id= ".$record[0]->agent_id." and re.type='package' and pc.package_id=re.type_id and re.status=0 order by re.review_id DESC");
        $data['hotel_detail'] = $this->md->my_query("SELECT pc.hotel_name as name,re.* FROM tbl_hotel as pc,tbl_review as re WHERE pc.agent_id= ".$record[0]->agent_id." and re.type='hotel' and pc.hotel_id=re.type_id and re.status=0 order by re.review_id DESC");  
        $data['place_detail'] = $this->md->my_query("SELECT lc.name as name,re.* FROM tbl_place as pc,tbl_location as lc,tbl_review as re WHERE pc.name = lc.location_id and re.type='place' and pc.place_id=re.type_id and re.status=0 order by re.review_id DESC");  
        $this->load->view("Agent/Deactive_Review",$data);
    }

    public function Add_hotel() 
    {
        $data= array();
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $agent=$record[0]->agent_id;
        if ($this->input->post('add')) 
        {
            $this->form_validation->set_rules('name', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Name.")); 
            $this->form_validation->set_rules('address', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel address.")); 
            $this->form_validation->set_rules('star', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atlest One Star.")); 
            $this->form_validation->set_rules("country", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One Country."));
            $this->form_validation->set_rules("state", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One State."));
            $this->form_validation->set_rules("city", "", "required", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast One City."));
            $this->form_validation->set_rules('contact', '','required|max_length[15]',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter contact Number.",'max_length' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Contact Number Is Maximum 15.")); 
            $this->form_validation->set_rules('Facility[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one Facility.")); 
            $this->form_validation->set_rules('policy[]', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select Atleast one policy.")); 
            $this->form_validation->set_rules('website', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Website.")); 
            $this->form_validation->set_rules('map', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel map location.")); 
            $this->form_validation->set_rules('disp', '','required',array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Discription.")); 
            $this->form_validation->set_rules('Price', "", "required|regex_match[/^[0-9]+$/]", array('required' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Hotel Price.",'regex_match' => "<i class='fa fa-exclamation-circle animated flash infinite'></i> Enter Valid Hotel Price."));
            if ($this->form_validation->run() == TRUE) 
            {
                $len = strlen($_FILES['hotel_pic']['name'][0]);
                if($len > 0)
                {
                    $count = count($_FILES['hotel_pic']['name']);
                    for ($i = 0; $i < $count; $i++) 
                    {
                        $_FILES['single']['name'] = $_FILES['hotel_pic']['name'][$i];
                        $_FILES['single']['type'] = $_FILES['hotel_pic']['type'][$i];
                        $_FILES['single']['size'] = $_FILES['hotel_pic']['size'][$i];
                        $_FILES['single']['error'] = $_FILES['hotel_pic']['error'][$i];
                        $_FILES['single']['tmp_name'] = $_FILES['hotel_pic']['tmp_name'][$i];
                        $detail = $this->md->my_query("select max(hotel_id) as mx from `tbl_hotel`");
                        $id = $detail[0]->mx;
                        if($id == "")
                        {
                            $name = "Hotel_0-$i";
                        }
                        else
                        {
                            $name = "Hotel_$id-$i";
                        }
                        $config['upload_path'] = './Admin_Assets/images/Upload/Hotel/';
                        $config['allowed_types'] = 'jpeg|png|jpg';
                        $config['max_size'] = 1024 * 3;
                        $config['file_name'] = $name;
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        if ($this->upload->do_upload('single')) 
                        {
                            $j =1;
                        }
                        $path[] ="Admin_Assets/images/Upload/Hotel/" . $this->upload->data('file_name');
                    }
                    $pname = implode(',',$path);
                    $Facility = implode(',', $this->input->post('Facility'));
                    $Policy = implode(',', $this->input->post('policy'));
                    if($j == 1)
                    {
                        $ins['photo'] = $pname;
                        $ins['facility'] = $Facility;
                        $ins['policy'] = $Policy;
                        $ins['agent_id'] = $agent;
                        $ins['hotel_name'] = $this->input->post('name');
                        $ins['location_id'] = $this->input->post('city');
                        $ins['star'] = $this->input->post('star');
                        $ins['address'] = $this->input->post('address');
                        $ins['iframe'] = $this->input->post('map');
                        $ins['website'] = $this->input->post('website');
                        $ins['Discription'] = $this->input->post('disp');
                        $ins['contact'] = $this->input->post('contact');
                        $ins['price'] = $this->input->post('Price');
                        $ins['status'] = 1;
                        $result = $this->md->my_insert("tbl_hotel", $ins);
                        if ($result == 1) 
                        {
                            $data["success"] = $this->input->post('name') . " Added Successfully .";
                        } 
                        else 
                        {
                            $data["error"] = "Somethis Is Wrong .";
                        }
                    }
                    else
                    {
                        $data["error"] = 'something is Wrong.';
                    }
                }
                else
                {
                    $data['p_error'] = "<i class='fa fa-exclamation-circle animated flash infinite'></i> Select At Least One Photo.";
                }
            }
        }
        $this->load->view("Agent/Add_hotel",$data);
    }
    
    public function Manage_hotel() 
    {
        $this->security();
        $wh['email'] = $this->session->userdata('agent');
        $record=$this->md->my_select('tbl_agent','agent_id',$wh);
        $agent=$record[0]->agent_id;
        $where['agent_id']= $agent;
        $data['view'] = $this->md->my_select('tbl_hotel','*',$where);
        $this->load->view("Agent/Manage_hotel",$data);
    }
    
    public function Delete() {
        $table = $this->uri->segment(2);
        if ($table == "place") 
        {
            $wh['place_id'] = $this->uri->segment(3); 
            $photo = $this->md->my_select("tbl_place",'photo',$wh);
            $pic = explode(',',$photo[0]->photo);
            foreach ($pic as $p)
            {
                unlink($p);
            }
            $this->md->my_delete("tbl_place", $wh);
            redirect("Manage_place");
        }
        if ($table == "package") 
        {
            $wh['package_id'] = $this->uri->segment(3);
            $photo = $this->md->my_select("tbl_trip_package",'photo',$wh);
            $pic = explode(',',$photo[0]->photo);
            foreach ($pic as $p)
            {
                unlink($p);
            }
            $this->md->my_delete("tbl_trip_package", $wh);
            redirect("View_Package");
        }
        if ($table == "hotel") 
        {
            $wh['hotel_id'] = $this->uri->segment(3);
            $photo = $this->md->my_select("tbl_hotel",'photo',$wh);
            $pic = explode(',',$photo[0]->photo);
            foreach ($pic as $p)
            {
                unlink($p);
            }
            $this->md->my_delete("tbl_hotel", $wh);
            redirect("Manage_hotel");
        }
        if ($table == "policy") 
        {
            $wh['policy_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_policy", $wh);
            redirect("Agent_policy");
        }
        if ($table == "Facility") 
        {
            $wh['facility_id'] = $this->uri->segment(3);
            $this->md->my_delete("tbl_facility", $wh);
            redirect("Agent_Facility");
        }
    }
}
